#include "pch.h"
#pragma hdrstop
//---------------------------------------------------------------------------
//
// $Workfile:: VehTruth.cpp                                          $
//
// $Revision:: 3                                                     $
//
// $History:: VehTruth.cpp                                           $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 7/23/02    Time: 8:09p
//Updated in $/TapMsec
//Added Source Safe keywords
//
//
//
//---------------------------------------------------------------------------

#ifndef VehTruthH
#include "VehTruth.h"
#endif


