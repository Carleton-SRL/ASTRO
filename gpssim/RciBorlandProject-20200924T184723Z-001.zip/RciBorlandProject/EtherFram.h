//---------------------------------------------------------------------------


#ifndef EtherFramH
#define EtherFramH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TEtherFrame : public TFrame
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
   __fastcall TEtherFrame(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TEtherFrame *EtherFrame;
//---------------------------------------------------------------------------
#endif
