NOTE:

The enclosed file "RciDriver.txt" is actually "RciDriver.exe".  Rename RciDriver.txt to RciDriver.exe - This was renamed where it could be
sent through email systems without being flaged as a virus.

