#include "pch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
// ClassExplorer Pro generated source file
// Created by Michael Wade on 2/15/2002, 11:55:15 PM
//---------------------------------------------------------------------------
#include "PowerCalc.h"
#include "RfCtl.h"
#include "ScenIniFile.h"
#include "PowerCalIni.h"

//---------------------------------------------------------------------------

TPowerCalc::TPowerCalc
   (
   )
{

   SetNewPowerCal();

}

void
TPowerCalc::SetNewPowerCal()
{
   TPowerCalIni *PowerCalIni = new TPowerCalIni();
   L1MaxPower = PowerCalIni->GetL1MaxPower();
   L2MaxPower = PowerCalIni->GetL2MaxPower();
   ExtAtten   = PowerCalIni->GetExtAtten();
   delete PowerCalIni;

}

TPowerCalc::TPowerCalc
   (
   const double InL1MaxPower,
   const double InL2MaxPower,
   const double InExtAtten,
   const double InRFGain
   ) :
   L1MaxPower( InL1MaxPower ),
   L2MaxPower( InL2MaxPower ),
   ExtAtten( InExtAtten )
{
}

double const
TPowerCalc::GetPower
   (
   const double Atten,
   const double RFGain,
   const double MaxPower
   ) const
{

   double Power = MaxPower - ( MAX_RF_GAIN - RFGain ) - Atten - ExtAtten;

   return( Power );

}

double const
TPowerCalc::GetL2Power
   (
   const double L2Atten,
   const double RFGain
   ) const
{

   return( GetPower( L2Atten, RFGain, L2MaxPower ) );

}


double const
TPowerCalc::GetL1Atten
   (
   const double L1Power,
   const double RFGain
   ) const
{
   return( GetAtten( L1Power, RFGain, L1MaxPower ) );
}

double const
TPowerCalc::GetAtten
   (
   const double Power,
   const double RFGain,
   const double MaxPower
   ) const
{

   double ChanAtten = MaxPower - ( MAX_RF_GAIN - RFGain ) - Power - ExtAtten;

   if ( ChanAtten < 0 ) ChanAtten = 0.0;

   return( ChanAtten );

}

double const
TPowerCalc::GetL2Atten
   (
   const double L2Power,
   const double RFGain
   ) const
{
   return( GetAtten( L2Power, RFGain, L2MaxPower ) );
}

double const
TPowerCalc::GetL1Power
   (
   const double L1Atten,
   const double RFGain
   ) const
{
   return( GetPower( L1Atten, RFGain, L1MaxPower ) );
}

