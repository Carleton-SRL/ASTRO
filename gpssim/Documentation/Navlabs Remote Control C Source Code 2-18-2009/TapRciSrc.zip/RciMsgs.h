#ifndef RciMsgsH
#define RciMsgsH

//---------------------------------------------------------------------------
//
// $Workfile:: RciMsgs.h                                             $
//
// $Revision:: 7                                                     $
//
// $History:: RciMsgs.h                                              $
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:13p
//Updated in $/TapRci
//Add floating point power/attenuation
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Add StartScen based on start pulse.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 1/16/04    Time: 10:43p
//Updated in $/TapRci
//Add "SetL2Atten" message.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:26p
//Updated in $/TapRci
//Add TimeSetPulse external to sim message.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:53p
//Updated in $/TapRci
//Add RF Gain/Atten.
//Add REGENSCEN.
//
//
//---------------------------------------------------------------------------


#ifndef InMsgH
#include "InMsg.h"
#endif

#ifndef OutMsgH
#include "OutMsg.h"
#endif

#ifndef TapBitH
#include "TapBit.h"
#endif

#ifndef TapMsecRciH
#include "TapMsecRci.h"
#endif

//-----------------------------------------------------------------------------
// From external to simulator
//
static const AnsiString StartScenMsgId( "STARTSCEN" );
static const AnsiString InitGeoMsgId( "INITGEO" );
static const AnsiString StartLocalMsgId( "STARTLOCAL" );
static const AnsiString SetSvidMsgId( "SETSVID" );
static const AnsiString SetPowerMsgId( "SETPOWER" );
static const AnsiString StopMsgId( "STOP" );
static const AnsiString ShutdownMsgId( "SHUTDOWN" );
static const AnsiString QueryMsgId( "QUERY" );
static const AnsiString SetRfGainMsgId( "SETRFGAIN" );
static const AnsiString AdjustRfGainMsgId( "ADJUSTRFGAIN" );
static const AnsiString SetRfAttenMsgId( "SETRFATTEN" );
static const AnsiString AdjustRfAttenMsgId( "ADJUSTRFATTEN" );
static const AnsiString ResetMsgId( "RESET" );
static const AnsiString RegenScenMsgId( "REGENSCEN" );
static const AnsiString TimeSetPulseMsgId( "TIMESETPULSE" );
static const AnsiString StartScenStartPulseMsgId( "STARTSCENSTARTPULSE" );
static const AnsiString SetL1AttenMsgId( "SETL1ATTEN" );
static const AnsiString SetL2AttenMsgId( "SETL2ATTEN" );
static const AnsiString ExecMsgId( "EXEC" );

//-----------------------------------------------------------------------------
// From simulator to external
//
static const AnsiString SimModeMsgId( "SIMMODE" );
static const AnsiString ChanStatMsgId( "CHANSTAT" );
static const AnsiString BitResultsMsgId( "BITRESULTS" );
static const AnsiString AckMsgId( "ACK" );
static const AnsiString SysCfgMsgId( "SYSCFG" );
static const AnsiString SimTimeMsgId( "SIMTIME" );

//-----------------------------------------------------------------------------
// External to Simulator Base
//
class TExtToSim {
protected:

   TStringList             * Fields;
   bool                      Valid_;

   bool const                GetValid() const               { return( Valid_ ); }
   void                      SetValid( const bool InValid ) { Valid_ = InValid; }

public:

   TExtToSim( const TInMsg &InMsg );
   TExtToSim & operator=( const TInMsg &InMsg );
   virtual ~TExtToSim();

   __property bool     Valid      = { read = GetValid,     write = SetValid     };


};



//-----------------------------------------------------------------------------
// StartScen
//
class TStartScenMsg : public TExtToSim {
private:
   AnsiString ScenName;
public:
   TStartScenMsg( const TInMsg &InMsg );
   TStartScenMsg & operator=( const TInMsg &InMsg );
   AnsiString const GetScenName() { return( ScenName ); }

};

//-----------------------------------------------------------------------------
// StartScenStartPulse
//
class TStartScenStartPulseMsg : public TExtToSim {
private:
   AnsiString                ScenName;
public:
   TStartScenStartPulseMsg( const TInMsg &InMsg );
   TStartScenStartPulseMsg & operator=( const TInMsg &InMsg );
   AnsiString const GetScenName() { return( ScenName ); }

};


//-----------------------------------------------------------------------------
// RegenScen
//
class TRegenScenMsg : public TExtToSim {
private:
   AnsiString ScenName;
public:
   TRegenScenMsg( const TInMsg &InMsg );
   TRegenScenMsg & operator=( const TInMsg &InMsg );
   AnsiString const GetScenName() { return( ScenName ); }

};

//-----------------------------------------------------------------------------
// Exec
//
class TExecMsg : public TExtToSim {
private:
   AnsiString                ExecParams;
public:
   TExecMsg( const TInMsg &InMsg );
   TExecMsg & operator=( const TInMsg &InMsg );
   AnsiString const GetExecParams() { return( ExecParams ); }

};


//-----------------------------------------------------------------------------
// InitGeo
//
class TInitGeoMsg : public TExtToSim {
private:

   double                    Lat_;
   double                    Lon_;
   double                    Alt_;
   TDateTime                 Date_;
   TDateTime                 Time_;

   double const              GetLat() const  { return( Lat_ ); }
   double const              GetLon() const  { return( Lon_ ); }
   double const              GetAlt() const  { return( Alt_ ); }
   TDateTime const           GetDate() const { return( Date_ ); }
   TDateTime const           GetTime() const { return( Time_ ); }

   void                      SetLat( const double InLat )   { Lat_  = InLat;  }
   void                      SetLon( const double InLon )   { Lon_  = InLon;  }
   void                      SetAlt( const double InAlt )   { Alt_  = InAlt;  }
   void                      SetDate( const double InDate ) { Date_ = InDate; }
   void                      SetTime( const double InTime ) { Time_ = InTime; }

public:

   TInitGeoMsg( const TInMsg &InMsg );
   TInitGeoMsg & operator=( const TInMsg &InMsg );

   __property double    Lat       = { read = GetLat,      write = SetLat    };
   __property double    Lon       = { read = GetLon,      write = SetLon    };
   __property double    Alt       = { read = GetAlt,      write = SetAlt    };
   __property double    Date      = { read = GetDate,     write = SetDate   };
   __property double    Time      = { read = GetTime,     write = SetTime   };

};

//-----------------------------------------------------------------------------
// TimeSetPulse
//
class TTimeSetPulseMsg : public TExtToSim {
private:

   double                    Lat_;
   double                    Lon_;
   double                    Alt_;
   TDateTime                 Date_;
   TDateTime                 Time_;

   double const              GetLat() const  { return( Lat_ ); }
   double const              GetLon() const  { return( Lon_ ); }
   double const              GetAlt() const  { return( Alt_ ); }
   TDateTime const           GetDate() const { return( Date_ ); }
   TDateTime const           GetTime() const { return( Time_ ); }

   void                      SetLat( const double InLat )   { Lat_  = InLat;  }
   void                      SetLon( const double InLon )   { Lon_  = InLon;  }
   void                      SetAlt( const double InAlt )   { Alt_  = InAlt;  }
   void                      SetDate( const double InDate ) { Date_ = InDate; }
   void                      SetTime( const double InTime ) { Time_ = InTime; }

public:

   TTimeSetPulseMsg( const TInMsg &InMsg );
   TTimeSetPulseMsg & operator=( const TInMsg &InMsg );

   __property double    Lat       = { read = GetLat,      write = SetLat    };
   __property double    Lon       = { read = GetLon,      write = SetLon    };
   __property double    Alt       = { read = GetAlt,      write = SetAlt    };
   __property double    Date      = { read = GetDate,     write = SetDate   };
   __property double    Time      = { read = GetTime,     write = SetTime   };

};

//-----------------------------------------------------------------------------
// SetSvid
//
class TChanSvid {
private:

   int Chan;
   int Svid;
public:

   TChanSvid( const int InChan=-1, const int InSvid=0 ) : Chan( InChan ), Svid( InSvid ) {}
   int const GetChan() const { return( Chan ); }
   int const GetSvid() const { return( Svid ); }

};

typedef std::vector<TChanSvid> TChanSvidArray;

class TSetSvidMsg : public TExtToSim {
private:

   TChanSvidArray ChanSvidArray;

public:

   TSetSvidMsg( const TInMsg &InMsg );
   TSetSvidMsg & operator=( const TInMsg &InMsg );
   TChanSvidArray const GetChanSvidArray() const { return( ChanSvidArray ); }

};

//-----------------------------------------------------------------------------
// SetPower
//
class TChanPower {
public:
   int    Chan;
   double Power;
public:
   TChanPower( const int InChan=-1, const double InPower=0 ) : Chan( InChan ), Power( InPower ) {}
   int    const GetChan() const { return( Chan ); }
   double const GetPower() const { return( Power ); }

};

typedef std::vector<TChanPower> TChanPowerArray;

class TSetPowerMsg : public TExtToSim {
private:
   TChanPowerArray ChanPowerArray;
public:
   TSetPowerMsg( const TInMsg &InMsg );
   TSetPowerMsg & operator=( const TInMsg &InMsg );
   TChanPowerArray const GetChanPowerArray() const { return( ChanPowerArray ); }

};

//-----------------------------------------------------------------------------
// Query
//
typedef enum { eQUERY_SIM_MODE, eQUERY_CHAN_STAT, eQUERY_BIT_RESULTS, eQUERY_SYS_CFG, eQUERY_SIMTIME } eQUERYTYPE;
typedef enum { eQUERY_OFF=-2, eQUERY_ONCE=-1, eQUERY_ON_CHANGE=0, eQUERY_RATE, } eQUERYTRANS;
class TExtQuery {
public:
   eQUERYTYPE   QueryType;
   eQUERYTRANS  QueryTransRate;
   int          Interval;
public:
   TExtQuery( const eQUERYTYPE InQueryType=eQUERY_SIM_MODE, const eQUERYTRANS InQueryTransRate=eQUERY_OFF, const int InInterval=0 ) :
      QueryType( InQueryType ), QueryTransRate( InQueryTransRate ), Interval( InInterval ) {}

};


class TQueryMsg : public TExtToSim {
private:
   TExtQuery  ExtQuery;
public:
   TQueryMsg( const TInMsg &InMsg );
   TQueryMsg & operator=( const TInMsg &InMsg );
   TExtQuery const GetExtQuery() const { return( ExtQuery ); }

};

//-----------------------------------------------------------------------------
// SetRfGain
//

class TSetRfGainMsg : public TExtToSim {
private:

   double                    RfGain_;

public:

   TSetRfGainMsg( const TInMsg & InMsg );
   TSetRfGainMsg & operator=( const TInMsg & InMsg );

   __property double    RfGain       = { read = RfGain_,    write = RfGain_    };

};

//-----------------------------------------------------------------------------
// AdjustRfGain
//

class TAdjustRfGainMsg : public TExtToSim {
private:

   double                    AdjustRfGain_;

public:

   TAdjustRfGainMsg( const TInMsg & InMsg );
   TAdjustRfGainMsg & operator=( const TInMsg & InMsg );

   __property double    AdjustRfGain       = { read = AdjustRfGain_,    write = AdjustRfGain_    };

};

//-----------------------------------------------------------------------------
// SetRfAtten
//

class TSetRfAttenMsg : public TExtToSim {
private:

   double                    RfAtten_;

public:

   TSetRfAttenMsg( const TInMsg & InMsg );
   TSetRfAttenMsg & operator=( const TInMsg & InMsg );

   __property double    RfAtten       = { read = RfAtten_,    write = RfAtten_    };

};

//-----------------------------------------------------------------------------
// AdjustRfAtten
//

class TAdjustRfAttenMsg : public TExtToSim {
private:

   double                    AdjustRfAtten_;

public:

   TAdjustRfAttenMsg( const TInMsg & InMsg );
   TAdjustRfAttenMsg & operator=( const TInMsg & InMsg );

   __property double    AdjustRfAtten       = { read = AdjustRfAtten_,    write = AdjustRfAtten_    };

};

//-----------------------------------------------------------------------------
// SetL1Atten
//

class TChanL1Atten {
private:

   int                       Chan_;
   double                    L1Atten_;

   int const                 GetChan() const { return( Chan_ ); }
   void                      SetChan( const int InChan ) { Chan_ = InChan; }

   double const              GetL1Atten() const { return( L1Atten_ ); }
   void                      SetL1Atten( const double InL1Atten ) { L1Atten_ = InL1Atten; }

public:

   TChanL1Atten( const int InChan=-1, const double InL1Atten=0 ) : Chan_( InChan ), L1Atten_( InL1Atten ) {}

   TChanL1Atten( const TChanL1Atten & Source )
   {
      ( *this )            = Source;
   }

   TChanL1Atten & operator=( const TChanL1Atten & Source )
   {

      if ( this == &Source ) return( *this );

      Chan_                = Source.Chan_;
      L1Atten_             = Source.L1Atten_;

      return( *this );

   }

   __property int    Chan    = { read = GetChan,     write = SetChan        };
   __property double L1Atten = { read = GetL1Atten,  write = SetL1Atten     };

};

typedef std::vector<TChanL1Atten> TChanL1AttenArray;

class TSetL1AttenMsg : public TExtToSim {
private:

   TChanL1AttenArray         ChanL1AttenArray_;

   TChanL1AttenArray const   GetChanL1AttenArray() const { return( ChanL1AttenArray_ ); }
   void                      SetChanL1AttenArray( const TChanL1AttenArray & InChanL1AttenArray ) { ChanL1AttenArray_ = InChanL1AttenArray; }

public:

   TSetL1AttenMsg( const TInMsg & InMsg );
   TSetL1AttenMsg & operator=( const TInMsg & InMsg );

   __property TChanL1AttenArray ChanL1AttenArray       = { read = GetChanL1AttenArray,    write = SetChanL1AttenArray    };

};

//-----------------------------------------------------------------------------
// SetL2Atten
//

class TChanL2Atten {
private:

   int                       Chan_;
   double                    L2Atten_;

   int const                 GetChan() const { return( Chan_ ); }
   void                      SetChan( const int InChan ) { Chan_ = InChan; }

   double const              GetL2Atten() const { return( L2Atten_ ); }
   void                      SetL2Atten( const double InL2Atten ) { L2Atten_ = InL2Atten; }

public:

   TChanL2Atten( const int InChan=-1, const double InL2Atten=0 ) : Chan_( InChan ), L2Atten_( InL2Atten ) {}

   TChanL2Atten( const TChanL2Atten & Source )
   {
      ( *this )            = Source;
   }

   TChanL2Atten & operator=( const TChanL2Atten & Source )
   {

      if ( this == &Source ) return( *this );

      Chan_                = Source.Chan_;
      L2Atten_             = Source.L2Atten_;

      return( *this );

   }

   __property int    Chan    = { read = GetChan,     write = SetChan        };
   __property double L2Atten = { read = GetL2Atten,  write = SetL2Atten     };

};

typedef std::vector<TChanL2Atten> TChanL2AttenArray;

class TSetL2AttenMsg : public TExtToSim {
private:

   TChanL2AttenArray         ChanL2AttenArray_;

   TChanL2AttenArray const   GetChanL2AttenArray() const { return( ChanL2AttenArray_ ); }
   void                      SetChanL2AttenArray( const TChanL2AttenArray & InChanL2AttenArray ) { ChanL2AttenArray_ = InChanL2AttenArray; }

public:

   TSetL2AttenMsg( const TInMsg & InMsg );
   TSetL2AttenMsg & operator=( const TInMsg & InMsg );

   __property TChanL2AttenArray ChanL2AttenArray       = { read = GetChanL2AttenArray,    write = SetChanL2AttenArray    };

};

//-----------------------------------------------------------------------------
// Ack
//
class TAckMsg : public TOutMsg {
private:
   const AnsiString MsgId;
public:
   TAckMsg( const AnsiString MsgAcked, const bool MsgValid, const bool SimModeValid );

};

//-----------------------------------------------------------------------------
// BitResults
//
class TBitResultsMsg : public TOutMsg {
private:
   const AnsiString MsgId;
public:
   TBitResultsMsg( const TTapBitResults & TapBitResults );

};

//-----------------------------------------------------------------------------
// Sim Mode
//
class TSimModeMsg : public TOutMsg {
private:
   const AnsiString MsgId;
public:
   TSimModeMsg( const eRciSimMode SimMode );

};

//-----------------------------------------------------------------------------
// Channel Status
//

class TChanStat {
private:
   int                       Svid;
   double                    L1Power;
   double                    L2Power;
public:
   TChanStat( const int InSvid=0, const int InL1Power=0, const int InL2Power = 0 ) :
      Svid( InSvid ), L1Power( InL1Power ), L2Power( InL2Power ) {}
   int const GetSvid()    const { return( Svid ); }
   double const GetL1Power() const { return( L1Power ); }
   double const GetL2Power() const { return( L2Power ); }

   friend bool const operator==( const TChanStat &cp1, const TChanStat &cp2 )
   {
      bool Same = true;
      if ( ( cp1.Svid != cp2.Svid ) || ( NINT( cp1.L1Power*10) != NINT( cp2.L1Power*10 ) ) || ( NINT( cp1.L2Power*10 ) != NINT( cp2.L2Power*10 ) ) )
      {
         Same = false;
      }
      return( Same );
   }
   friend bool const operator!=( const TChanStat &cp1, const TChanStat &cp2 )
   {
      return( !( cp1 == cp2 ) );
   }
};

typedef std::vector<TChanStat> TChanStatArray;

class TChanStatMsg : public TOutMsg {
private:
   const AnsiString MsgId;
public:
   TChanStatMsg( const TChanStatArray & ChanStatArray );

};

//-----------------------------------------------------------------------------
// System Configuration (SYSCFG)
//
class TSysCfg {
public:
   int  NumChans;
   bool L2Capable;
   int  MinPower;
   int  MaxPower;

public:
   TSysCfg( ) : NumChans( 0 ), L2Capable( false ), MinPower( 0 ), MaxPower( 0 ) {}
};

class TSysCfgMsg : public TOutMsg {
private:
   const AnsiString MsgId;
public:
   TSysCfgMsg( const TSysCfg & SysCfg );

   friend bool const operator==( const TSysCfg &cp1, const TSysCfg &cp2 )
   {
      bool Same = true;
      if (
         ( cp1.NumChans != cp2.NumChans ) || ( cp1.L2Capable != cp2.L2Capable ) ||
         ( cp1.MinPower != cp2.MinPower ) || ( cp1.MaxPower != cp2.MaxPower ) )
      {
         Same = false;
      }
      return( Same );
   }
   friend bool const operator!=( const TSysCfg &cp1, const TSysCfg &cp2 )
   {
      return( !( cp1 == cp2 ) );
   }
};

class TSimTime {
public:

   int                       StartWeek;
   double                    StartSeconds;
   double                    SecondsIntoSim;
   double                    SecondsRemaining;
   int                       CurWeek;
   double                    CurSeconds;

public:

   TSimTime() : StartWeek( 0 ), StartSeconds( 0 ), SecondsIntoSim( 0 ), SecondsRemaining( 0 ), CurWeek( 0 ), CurSeconds( 0 ) {}

   TSimTime & operator=( const TTapMsecStat & TapMsecStat )
   {

      StartWeek            = TapMsecStat.StartWeek;
      StartSeconds         = TapMsecStat.StartSeconds;
      SecondsIntoSim       = TapMsecStat.SecondsIntoSim;
      SecondsRemaining     = TapMsecStat.SecondsRemaining;
      CurWeek              = TapMsecStat.CurWeek;
      CurSeconds           = TapMsecStat.CurSeconds;

      return( *this );

   }

   TSimTime( const TTapMsecStat & TapMsecStat )
   {
      ( *this )            = TapMsecStat;
   }

   friend bool const operator==( const TSimTime &t1, const TSimTime &t2 )
   {
      bool Same = true;
      if (
         ( t1.StartWeek                    != t2.StartWeek                    ) ||
         ( NINT( t1.StartSeconds*10)       != NINT( t2.StartSeconds*10 )      ) ||
         ( NINT( t1.SecondsIntoSim*10 )    != NINT( t2.SecondsIntoSim*10 )    ) ||
         ( NINT( t1.SecondsRemaining*10 )  != NINT( t2.SecondsRemaining*10 )  ) ||
         ( t1.CurWeek                      != t2.CurWeek                      ) ||
         ( NINT( t1.CurSeconds*10)         != NINT( t2.CurSeconds*10 )        )
         )
      {
         Same              = false;
      }

      return( Same );
   }

   friend bool const operator!=( const TSimTime &t1, const TSimTime &t2 )
   {
      return( !( t1 == t2 ) );
   }

};

class TSimTimeMsg : public TOutMsg {
private:
   const AnsiString          MsgId;
public:
   TSimTimeMsg( const TSimTime & SimTime );

};


#endif