//---------------------------------------------------------------------------

#ifndef AboutDlgH
#define AboutDlgH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: AboutDlg.h                                            $
//
// $Revision:: 1                                                     $
//
// $History:: AboutDlg.h                                             $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 1:47p
//Created in $/TapRci
//Initial checkin.
//
//
//---------------------------------------------------------------------------

//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "RzAnimtr.hpp"
#include "RzLabel.hpp"
#include "StVInfo.hpp"
#include <ImgList.hpp>
#include "StBase.hpp"
#include "EXPANDABLEDLG.h"
#include "RzButton.hpp"
#include <Graphics.hpp>
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef ExpandableDlgH
#include "EXPANDABLEDLG.h"
#endif

//---------------------------------------------------------------------------
class TAboutDialog : public TExpandableDialog
{
__published:
   TRzLabel *FileNameLbl;
   TRzLabel *DateLbl;
   TRzLabel *VersionLbl;
   TRzLabel *RzLabel1;
   TRzLabel *RzLabel2;
   TRzLabel *DateLabel;
   TStVersionInfo *CurVersionInfo;
   TImage *Image1;
private:


public:

   __fastcall TAboutDialog(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TAboutDialog *AboutDialog;
//---------------------------------------------------------------------------
#endif
