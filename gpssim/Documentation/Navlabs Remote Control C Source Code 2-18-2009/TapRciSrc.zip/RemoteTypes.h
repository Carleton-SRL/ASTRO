#ifndef RemoteTypesH
#define RemoteTypesH

//---------------------------------------------------------------------------
//
// $Workfile:: RemoteTypes.h                                         $
//
// $Revision:: 4                                                     $
//
// $History:: RemoteTypes.h                                          $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Add local/scenario external reset pulse modes.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:27p
//Updated in $/TapRci
//Add External Time Reset mode (eSimModeExtResetPulseWait).
//SimModeStr, SimModeColor.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:54p
//Updated in $/TapRci
//Add std:: to STL items.
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------


#define NUM_DISP_CHANS ( 14 )

static const int NumSimModes = 6;
typedef enum { eSimIdle = 0x01, eSimLocal          = 0x02,  eSimScen   = 0x03,  eSimRegen = 0x04, eSimExtResetPulseWaitLocal = 0x05, eSimExtResetPulseWaitScen = 0x06 } eRciSimMode;
typedef enum { eIntGpib = 0,    eIntEthernet       = 1,     eIntSerial = 2    } eIntType;

const AnsiString SimModeStrings[NumSimModes] =
   {
   AnsiString( "Idle" ),
   AnsiString( "Local" ),
   AnsiString( "Scenario" ),
   AnsiString( "Regenerate" ),
   AnsiString( "Wait for External Reset Pulse - Local" ),
   AnsiString( "Wait for External Reset Pulse - Scenario" )
   };

AnsiString const
GetSimModeString
   (
   const eRciSimMode         Mode
   )
{
   return( ( (int)Mode >= eSimIdle && (int)Mode < NumSimModes ) ? SimModeStrings[ ( (int) Mode-1 ) ] : AnsiString ( "" ) );
}

TColor const
GetSimModeColor
   (
   const eRciSimMode         Mode
   )
{

   TColor ModeColor = clBlack;

   if ( Mode == eSimLocal                  ) ModeColor = clBlue;
   if ( Mode == eSimScen                   ) ModeColor = clLime;
   if ( Mode == eSimExtResetPulseWaitLocal ) ModeColor = clYellow;
   if ( Mode == eSimExtResetPulseWaitScen  ) ModeColor = clYellow;

   return( ModeColor );

}

typedef std::vector<int>           TIntArr;
typedef std::vector<double>        TDoubleArr;
typedef std::vector<bool>          TBoolArr;
typedef std::vector<unsigned char> TUCharArr;
typedef std::vector<char>          TCharArr;

typedef std::set<int>              TIntSet;

typedef techsoft::matrix<double>   TMatrix;

typedef std::valarray<double>      TValArray;

typedef TUCharArr                  TMsgData;
typedef std::queue<TMsgData>       TMsgDataQueue;
typedef TUCharArr                  TMsgData;
typedef std::vector<TThread *>     TThreadArray;

#endif
 