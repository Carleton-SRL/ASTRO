#ifndef TapRciPchH
#define TapRciPchH


//---------------------------------------------------------------------------
//
// $Workfile:: TapRciPch.h                                           $
//
// $Revision:: 1                                                     $
//
// $History:: TapRciPch.h                                            $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 3:20p
//Created in $/TapRci
//Initial checkin.
//
//
//---------------------------------------------------------------------------




#include "cmatrix"

#ifndef BStreamH
#include "BStream.h"
#endif

#ifndef RemoteTypesH
#include "RemoteTypes.h"
#endif


#define NINT(X)         ((long int)(((X) < 0.0) ? ((X) - 0.5) : ((X) + 0.5)))


#endif

