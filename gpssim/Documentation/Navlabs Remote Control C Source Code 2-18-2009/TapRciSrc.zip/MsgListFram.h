//---------------------------------------------------------------------------


#ifndef MsgListFramH
#define MsgListFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: MsgListFram.h                                         $
//
// $Revision:: 3                                                     $
//
// $History:: MsgListFram.h                                          $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:21p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:44p
//Updated in $/TapRci
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------

//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "RzLabel.hpp"
#include "RzLstBox.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "RzPanel.hpp"
#include <Classes.hpp>
#include "RzStatus.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef RemoteTypesH
#include "RemoteTypes.h"
#endif


class TMsgDispData {
public:

   double                    UserTime;
   TMsgData                  MsgData;

public:

   TMsgDispData() : UserTime( 0.0 ) {}
   TMsgDispData( const double & InUserTime, const TMsgData & InMsgData ) :
      UserTime( InUserTime ), MsgData( InMsgData ) {}

};

//---------------------------------------------------------------------------
class TMsgListFrame : public TFrame
{
__published:
   TPanel *MsgListPanel;
   TRzTabbedListBox *MsgListBox;
   TRzPanel *MsgListPnl;
   TRzLabel *RzLabel1;
   TRzLabel *RzLabel3;
   TRzLabel *RzLabel2;
   TRzStatusBar *RzStatusBar1;
   TRzStatusPane *RzStatusPane1;
   TRzStatusPane *RzStatusPane2;
private:


public:

   __fastcall TMsgListFrame( TComponent * Owner );

   void AddMsg( const TMsgDispData & MsgDispData );

};
//---------------------------------------------------------------------------
extern PACKAGE TMsgListFrame *MsgListFrame;
//---------------------------------------------------------------------------
#endif
