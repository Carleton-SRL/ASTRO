#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: VerifyOperationFrm.cpp                                $
//
// $Revision:: 6                                                     $
//
// $History:: VerifyOperationFrm.cpp                                 $
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:33p
//Updated in $/TapRci
//New TpMapInterface from TapMsec has properties.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 2/01/03    Time: 4:42p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:20p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:05p
//Updated in $/TapRci
//Add interface types.
//Add WinVpg.
//
//
//---------------------------------------------------------------------------


#ifndef VerifyOperationFrmH
#include "VerifyOperationFrm.h"
#endif

#ifndef TpMapInterfaceH
#include "TpMapInterface.h"
#endif

#ifndef GpibIntOptionsFramH
#include "GpibIntOptionsFram.h"
#endif

#ifndef EthernetIntOptionsFramH
#include "EthernetIntOptionsFram.h"
#endif

#ifndef SerialIntOptionsFramH
#include "SerialIntOptionsFram.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ovclabel"
#pragma link "RzBorder"
#pragma link "RzPanel"
#pragma link "RzSplit"
#pragma link "RzButton"
#pragma link "BitResultsFram"
#pragma link "GpibIntOptionsFram"
#pragma link "RzDlgBtn"
#pragma link "SsBase"
#pragma link "StBrowsr"
#pragma link "InterfaceAcceptFram"
#pragma link "o32flxbn"
#pragma link "RzCmboBx"
#pragma link "BitResultsFram"
#pragma link "RzCommon"
#pragma resource "*.dfm"
TVerifyOperationForm *VerifyOperationForm;
//---------------------------------------------------------------------------
__fastcall
TVerifyOperationForm::TVerifyOperationForm
   (
   TComponent* Owner
   ) :
   TForm(Owner),
   OperationError_( false ),
   TapRciProfile( NULL ),
   Vdp( NULL ),
   IntOptionsFrame( NULL )
{

   // Get the ini files
   //
   TapRciProfile = new TTapRciProfile();
   Vdp           = new VoyDefProfile();

   if ( TapRciProfile->Gpib )
   {
      InterfaceSelectcbox->ItemIndex = (int) eIntGpib;
      SetIntType( eIntGpib );
   }
   else if ( TapRciProfile->Ethernet )
   {
      InterfaceSelectcbox->ItemIndex = (int) eIntEthernet;
      SetIntType( eIntEthernet );
   }
   else if ( TapRciProfile->Serial )
   {
      InterfaceSelectcbox->ItemIndex = (int) eIntSerial;
      SetIntType( eIntSerial );
   }

   SetDisp();

}
//---------------------------------------------------------------------------

__fastcall
TVerifyOperationForm::~TVerifyOperationForm
   (

   )
{
   delete TapRciProfile;
   delete Vdp;
}

void
TVerifyOperationForm::SetDisp
   (
   )
{

   CheckStatus( RciStatus, TapBitResults );

   TapMsecPathLbl->Caption = TapRciProfile->TapMsecPath;
   WinVpgPathLbl->Caption  = TapRciProfile->WinVpgPath;
   RemoteScnLbl->Caption   = TapRciProfile->RemoteScn;

   SetPassFail( RciStatus.DriverValid,      SimDrvrValidLbl     );
   SetPassFail( RciStatus.TapMsecPathValid, TapMsecPathValidLbl );
   SetPassFail( RciStatus.WinVpgPathValid,  WinVpgPathValidLbl  );
   SetPassFail( RciStatus.RemoteScnValid,   RemoteScnValidLbl   );

   BitResultsFrame->SetBitResults( TapBitResults );

   if ( !TapRciProfile->WinVpgRequired )
   {
      WinVpgPathValidLbl->Caption = "Not Rqrd";
      WinVpgPathValidLbl->Font->Color = clBlue;
   }

}

void
TVerifyOperationForm::SetPassFail
   (
   const bool                Passed,
   TOvcLabel               * Lbl
   )
{

   if ( Passed )
   {
      Lbl->Caption     = "Passed";
      Lbl->Font->Color = clGreen;
   }
   else
   {
      Lbl->Caption     = "Failed";
      Lbl->Font->Color = clRed;
   }

}

void
TVerifyOperationForm::CheckStatus
   (
   TRciStatus              & CurRciStatus,
   TTapBitResults          & CurTapBitResults
   )
{

   AnsiString TapMsecPath = TapRciProfile->TapMsecPath;
   ifstream TapMsecStream( TapMsecPath.c_str(), ios::binary );
   if ( !TapMsecStream )
   {
      CurRciStatus.TapMsecPathValid = false;
   }
   else
   {
      CurRciStatus.TapMsecPathValid = true;
   }
   TapMsecStream.close();

   bool WinVpgRequired   = TapRciProfile->WinVpgRequired;
   if ( WinVpgRequired )
   {
      AnsiString WinVpgPath = TapRciProfile->WinVpgPath;
      ifstream WinVpgStream( WinVpgPath.c_str(), ios::binary );
      if ( !WinVpgStream )
      {
         CurRciStatus.WinVpgPathValid = false;
      }
      else
      {
         CurRciStatus.WinVpgPathValid = true;
      }
      WinVpgStream.close();
   }

   // Check for valid driver
   //
   TTpMapInterface *TpMapInterface    = new TTpMapInterface();
   CurRciStatus.DriverValid           = TpMapInterface->Valid;
   CurTapBitResults                   = TpMapInterface->RunBit();
   CurRciStatus.BitResultsValid       = true;
   delete TpMapInterface;

   // Check for valid remote scenario
   //
   AnsiString RemoteScnPath           = TapRciProfile->RemoteScn;
   CurRciStatus.RemoteScnValid        = IsValidScenario( RemoteScnPath );

   bool WinVpgOperationError          = WinVpgRequired && !CurRciStatus.WinVpgPathValid;

   OperationError_                    = !CurRciStatus.RemoteScnValid || !CurRciStatus.TapMsecPathValid || !CurRciStatus.DriverValid || !CurTapBitResults.BitPassed()
                                        || WinVpgOperationError;

}

bool const
TVerifyOperationForm::IsValidScenario
   (
   const AnsiString & ScenarioRoot
   )
{
   char CurrentDir[MAX_PATH];
   bool CurrentDirValid = ( getcwd( CurrentDir, MAX_PATH ) != NULL );
   chdir( ScenarioRoot.c_str() );
   ifstream ValidBuild( "ValidBld.scn" );
   int ValidScen = 0;
   ValidBuild >> ValidScen;
   if ( CurrentDirValid )
   {
      chdir(CurrentDir);
   }
   ValidBuild.close();
   return(ValidScen != 0 && ValidBuild.good());
}

void __fastcall
TVerifyOperationForm::TapMsecPathBtnClick
   (
   TObject                 * Sender
   )
{

   TOpenDialog * pFileOpen  = new TOpenDialog( this );
   pFileOpen->Options       << ofFileMustExist;
   pFileOpen->Filter        = "Exe files (*.exe)|*.EXE";
   pFileOpen->Title         = "Select TapMsec Executable";
   pFileOpen->InitialDir    = JustPathnameL( TapRciProfile->TapMsecPath );

   if ( pFileOpen->Execute() )
   {
      TapRciProfile->TapMsecPath = pFileOpen->FileName;
   }
   delete pFileOpen;

   SetDisp();

}
//---------------------------------------------------------------------------

void __fastcall
TVerifyOperationForm::WinVpgPathBtnClick
   (
   TObject                 * Sender
   )
{

   TOpenDialog*  pFileOpen  = new TOpenDialog( this );
   pFileOpen->Options       << ofFileMustExist;
   pFileOpen->Filter        = "Exe files (*.exe)|*.EXE";
   pFileOpen->Title         = "Select WinVpg Executable";
   pFileOpen->InitialDir    = JustPathnameL( TapRciProfile->WinVpgPath );

   if ( pFileOpen->Execute() )
   {
      TapRciProfile->WinVpgPath = pFileOpen->FileName;
   }

   delete pFileOpen;

   SetDisp();

}
//---------------------------------------------------------------------------

void __fastcall
TVerifyOperationForm::RemoteScnBtnClick
   (
   TObject                 * Sender
   )
{

   StBrowserRemoteDir->RootFolder = Vdp->GetRunsDir();

   if ( StBrowserRemoteDir->Execute() )
   {

      TapRciProfile->RemoteScn = StBrowserRemoteDir->Path;

   }

   SetDisp();

}
//---------------------------------------------------------------------------

void __fastcall
TVerifyOperationForm::RzDialogButtons1ClickOk
   (
   TObject * Sender
   )
{

   ModalResult = mrOk;

}
//---------------------------------------------------------------------------

eIntType const
TVerifyOperationForm::GetIntTypeFromItem
   (
   const int                 ItemIndex
   ) const
{
   return( (eIntType) ItemIndex );
}

void
TVerifyOperationForm::SetIntType
   (
   const eIntType            NewIntType
   )
{

   TapRciProfile->IntType  = NewIntType;

   IntType                 = NewIntType;

   delete IntOptionsFrame;

   IntOptionsFrame         = NULL;

   AnsiString IntName;

   if ( NewIntType == eIntGpib )
   {
      TGpibIntOptionsFrame *GpibFrame            = new TGpibIntOptionsFrame( this );
      IntOptionsFrame                            = GpibFrame;
      AcceptOptions                              = GpibFrame;
      InterfaceAccept->AcceptInterfaceOptions    = AcceptOptions;
      IntName                                    = "Gpib";
   }
   else if ( NewIntType == eIntEthernet )
   {
      TEthernetIntOptionsFrame * EthernetFrame   = new TEthernetIntOptionsFrame( this );
      IntOptionsFrame                            = EthernetFrame;
      AcceptOptions                              = EthernetFrame;
      InterfaceAccept->AcceptInterfaceOptions    = AcceptOptions;
      IntName                                    = "Ethernet";
   }
   else if ( NewIntType == eIntSerial )
   {
      TSerialIntOptionsFrame * SerialFrame       = new TSerialIntOptionsFrame( this );
      IntOptionsFrame                            = SerialFrame;
      AcceptOptions                              = SerialFrame;
      InterfaceAccept->AcceptInterfaceOptions    = AcceptOptions;
      IntName                                    = "Serial";
   }

   if ( IntOptionsFrame )
   {
      IntOptionsFrame->Parent  = InterfacePnl;
      IntOptionsFrame->Visible = true;
      IntOptionsFrame->Align   = alClient;
      IntOptionsFrame->Name    = IntName + AnsiString( "IntOptions" );
   }
   else
   {
      CodeSite->SendInteger( csmError, AnsiString( "TVerifyOperationForm::SetIntType invalid type " ), NewIntType );
   }

}

//---------------------------------------------------------------------------

void __fastcall
TVerifyOperationForm::InterfaceSelectcboxChange
   (
   TObject                 * Sender
   )
{

   eIntType NewIntType = GetIntTypeFromItem( InterfaceSelectcbox->ItemIndex );

   SetIntType( NewIntType );

}
//---------------------------------------------------------------------------

