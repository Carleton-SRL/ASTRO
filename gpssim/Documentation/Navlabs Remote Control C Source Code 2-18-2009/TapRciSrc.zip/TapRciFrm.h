//---------------------------------------------------------------------------

#ifndef TapRciFrmH
#define TapRciFrmH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: TapRciFrm.h                                           $
//
// $Revision:: 9                                                     $
//
// $History:: TapRciFrm.h                                            $
//
//*****************  Version 9  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:13p
//Updated in $/TapRci
//Remove CodeSite 3.
//
//*****************  Version 8  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:02p
//Updated in $/TapRci
//TapMsecStatFrame LED to standard text.
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:32p
//Updated in $/TapRci
//Add Time Pulse Reset for LM Garrett.  Reset Stat.  Cancel.  Tab.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 2/04/03    Time: 11:01a
//Updated in $/TapRci
//Add popup to tray icon.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 2/01/03    Time: 4:41p
//Updated in $/TapRci
//Make application tray.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:24p
//Updated in $/TapRci
//Change to XP style.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:00p
//Updated in $/TapRci
//Add OperationError.
//
//
//---------------------------------------------------------------------------

//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include "RzPanel.hpp"
#include "RzSplit.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include "SsBase.hpp"
#include "StBrowsr.hpp"
#include "RzLabel.hpp"
#include "CSIntf.hpp"
#include "MsgListFram.h"
#include "TapMsecStatFram.h"
#include "RzStatus.hpp"
#include "RzTabs.hpp"
#include "RzTray.hpp"
#include <ActnList.hpp>
#include <ActnMan.hpp>
#include <ImgList.hpp>
#include "RzButton.hpp"
#include "RzRadChk.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef MsgListFramH
#include "MsgListFram.h"
#endif

#ifndef TapMsecStatFramH
#include "TapMsecStatFram.h"
#endif

#ifndef TapMsecRciH
#include "TapMsecRci.h"
#endif

#ifndef RciControlH
#include "RciControl.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef MsgListFramH
#include "MsgListFram.h"
#endif

#ifndef TapMsecStatFramH
#include "TapMsecStatFram.h"
#endif

//---------------------------------------------------------------------------
class TTapRciForm : public TForm
{
__published:
   TRzPanel *MainClientPnl;
   TRzSizePanel *LeftSizePnl;
   TMsgListFrame *MsgListFrame;
   TTimer *RciTimer;
   TMainMenu *MainMenu;
   TMenuItem *FileMenu;
   TMenuItem *PowerDisp;
   TMenuItem *FindTapMsec;
   TStBrowser *StBrowserRemoteDir;
   TMenuItem *SetRemoteScn;
   TMenuItem *Commands1;
   TMenuItem *VerifyOperationMenu;
   TRzStatusBar *StatusBar;
   TRzStatusPane *RzStatusPane1;
   TRzVersionInfoStatus *VerInfoStatus;
   TRzClockStatus *RzClockStatus1;
   TRzVersionInfo *TapRciVersionInfo;
   TRzStatusPane *RzStatusPane2;
   TRzPageControl *MainPageControl;
   TRzTabSheet *TapMsecStatSheet;
   TTapMsecStatFrame *TapMsecStatusFrame;
   TRzTrayIcon *TrayIcon;
   TImageList *TrayIconImages;
   TPopupMenu *TrayPopup;
   TMenuItem *AboutPopup;
   TMenuItem *RestorePopup;
   TMenuItem *ExitPopup;
   TActionManager *ActionMgr;
   TAction *AboutAction;
   TAction *RestoreAction;
   TAction *ExitAction;
   TMenuItem *Help1;
   TMenuItem *About2;
   TImageList *MenuImages;
   TAction *PowerDispAction;
   TAction *TapMsecPathAction;
   TAction *RemoteScenAction;
   TAction *VerifyOperationAction;
   TMenuItem *ExitFile;
   TAction *MinimizeAction;
   TMenuItem *MinimizeFile;
   TRzPanel *TapRciStatusPnl;
   TRzLabel *TapRciStatusLbl;
   TRzLabel *TapRciStatusVal;
   TRzSizePanel *TopSizePnl;
   TRzSizePanel *TopMainLeftSizePnl;
   TRzSizePanel *TopLeftSizeMsgStatPnl;
   TRzPanel *TopLeftMsgStatPnl;
   TRzPanel *MessageStatusTitlePnl;
   TOvcLabel *IntLbl;
   TRzPanel *MessageStatusPnl;
   TOvcLabel *NumMsgsSentDescLbl;
   TOvcLabel *NumMsgsSentLbl;
   TOvcLabel *NumMsgsRcvdDescLbl;
   TOvcLabel *NumMsgsRcvdLbl;
   TRzLabel *OperationErrorLbl;
   TRzPanel *TopRightPnl;
   TRzPanel *InterfaceStatusTitlePnl;
   TOvcLabel *InterfaceStatusTitleLbl;
   TRzPanel *InterfaceStatusPnl;
   TRzPanel *RciRightPnl;
   TRzPanel *RciStatusTitlePnl;
   TOvcLabel *RciStatusLbl;
   TRzPanel *RciStatusPnl;
   TRzPageControl *RciStatusPageCtrl;
   TRzTabSheet *SimCountersSheet;
   TRzLabel *PPSCounterLbl;
   TRzLabel *PPSCounterVal;
   TRzLabel *MsCounterLbl;
   TRzLabel *MsCounterVal;
   TRzCheckBox *CounterStoppedcb;
   TRzBitBtn *ResetCountersBtn;
   TImageList *ButtonImages;
   TActionManager *RciActionManager;
   TAction *ResetCountersAction;
   TRzLabel *SimHWCountersSimCountersWaitForResetLbl;
   TRzTabSheet *ResetPulseSheet;
   TRzBitBtn *CancelExtResetBtn;
   TRzLabel *ExtResetSheetSimCountersWaitForResetLbl;
   TAction *CancelArmExternalPulseResetAction;
   void __fastcall RciTimerTimer(TObject *Sender);
   void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   void __fastcall AboutActionExecute(TObject *Sender);
   void __fastcall RestoreActionExecute(TObject *Sender);
   void __fastcall ExitActionExecute(TObject *Sender);
   void __fastcall PowerDispActionExecute(TObject *Sender);
   void __fastcall TapMsecPathActionExecute(TObject *Sender);
   void __fastcall RemoteScenActionExecute(TObject *Sender);
   void __fastcall VerifyOperationActionExecute(TObject *Sender);
   void __fastcall MinimizeActionExecute(TObject *Sender);
   void __fastcall TapRciStatusPnlResize(TObject *Sender);
   void __fastcall ResetCountersActionExecute(TObject *Sender);
   void __fastcall ResetCountersActionUpdate(TObject *Sender);
   void __fastcall CancelArmExternalPulseResetActionExecute(
          TObject *Sender);
   void __fastcall CancelArmExternalPulseResetActionUpdate(
          TObject *Sender);
private:

   TRciControl             * RciControl;
   IInterfaceStatusFrame   * InterfaceStatusFrame;
   bool                      InTimer;
   bool                      OperationError;
   eRciSimMode               SimMode;
   TMsgTrafficArray          MsgTrafficArray;
   TTapRciProfile          * TapRciProfile;
   bool                      Stopped;
   int                       CurPPSCount_;
   int                       CurIntCount_;
   int                       PrevPPSCount_;
   int                       PrevIntCount_;

   bool const                VerifyOperation();
   void                      ProcessMsgTrafficArray( TMsgTrafficArray & Msgs );
   void                      DispOperationError();
   void                      StopRci();
   void                      SetRciStatusDisplay( TRciControl * RciCtl );
   void                      SetRciStatusResetPulseDisplay( TRciControl * RciCtl );
   void                      SetRciStatusCountersDisplay( TRciControl * RciCtl );
   void                      SetTapRciStatusLbls();
   void                      SetDisplay();

public:

   __fastcall                TTapRciForm( TComponent* Owner );
   __fastcall               ~TTapRciForm();

};
//---------------------------------------------------------------------------
extern PACKAGE TTapRciForm *TapRciForm;
//---------------------------------------------------------------------------
#endif
