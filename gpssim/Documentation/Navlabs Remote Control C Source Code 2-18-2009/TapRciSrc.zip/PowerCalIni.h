//---------------------------------------------------------------------------
// ClassExplorer Pro generated header file
// Created by Michael Wade on 2/12/2002, 7:42:34 PM
//---------------------------------------------------------------------------
#ifndef PowerCalIniH
#define PowerCalIniH


//---------------------------------------------------------------------------
class TPowerCalIni : public TIniFile  {
private:
protected:
public:
   TPowerCalIni();
   void SetL1MaxPower(const double L1MaxPowerdBm);
   void SetL2MaxPower(const double L2MaxPowerdBm);
   void SetExtAtten(const double ExtAttendB);
   double const GetExtAtten();
   double const GetL1MaxPower();
   double const GetL2MaxPower();
};

//---------------------------------------------------------------------------
#endif
