#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: EthernetInterfaceStatusFram.cpp                       $
//
// $Revision:: 4                                                     $
//
// $History:: EthernetInterfaceStatusFram.cpp                        $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:40p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:18p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:31p
//Updated in $/TapRci
//Initial release.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/04/02   Time: 10:25a
//Created in $/RciDriver
//Add ethernet
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/02/02   Time: 9:48a
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------

#ifndef EthernetInterfaceStatusFramH
#include "EthernetInterfaceStatusFram.h"
#endif

#ifndef EthernetH
#include "Ethernet.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ovclabel"
#pragma link "RzButton"
#pragma link "RzRadChk"
#pragma resource "*.dfm"
TEthernetInterfaceStatusFrame *EthernetInterfaceStatusFrame;
//---------------------------------------------------------------------------
__fastcall
TEthernetInterfaceStatusFrame::TEthernetInterfaceStatusFrame
   (
   TComponent                    * Owner,
   const TEthernetServer   * const InEthernetServer
   ) :
   TFrame( Owner ),
   EthernetServer( InEthernetServer ),
   EthernetClient( NULL ),
   Title_( AnsiString( "Ethernet Server Interface Status" ) )
{
}
//---------------------------------------------------------------------------
__fastcall
TEthernetInterfaceStatusFrame::TEthernetInterfaceStatusFrame
   (
   TComponent                    * Owner,
   const TEthernetClient   * const InEthernetClient
   ) :
   TFrame( Owner ),
   EthernetClient( InEthernetClient ),
   EthernetServer( NULL ),
   Title_( AnsiString( "Ethernet Client Interface Status" ) )
{
}
//---------------------------------------------------------------------------

void
TEthernetInterfaceStatusFrame::UpdateDisplay()
{

   if ( Server )
   {
      Connectedrb->Caption      = AnsiString( "Client " ) + ( EthernetServer->ActiveClient ? AnsiString( "" ) : AnsiString( "NOT " ) ) + AnsiString( "Connected" );
      Connectedrb->Checked      = EthernetServer->ActiveClient;
      PortLbl->Caption          = EthernetServer->PortNum;
   }
   else
   {
      Connectedrb->Caption      = AnsiString( "Server " ) + ( EthernetClient->Active ? AnsiString( "" ) : AnsiString( "NOT " ) ) + AnsiString( " Connected" );
      Connectedrb->Checked      = EthernetClient->Active;
      PortLbl->Caption          = EthernetClient->PortNum;
   }

}
