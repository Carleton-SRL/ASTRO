#ifndef UserQueryH
#define UserQueryH

//---------------------------------------------------------------------------
//
// $Workfile:: UserQuery.h                                           $
//
// $Revision:: 2                                                     $
//
// $History:: UserQuery.h                                            $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:02p
//Updated in $/TapRci
//Add properties.
//
//
//---------------------------------------------------------------------------


template<class T>
class TUserQuery {
private:
   bool                      SendInterval_;
   bool                      SendChange_;
   int                       IntervalMillisec_;
   int                       LastTimeSentMillisec_;
   bool                      SendOnceOverride_;
   T                         SentT_;
public:
   TUserQuery( ) : IntervalMillisec_( 0 ), SendInterval_( false ),
      SendChange_( false ), LastTimeSentMillisec_(0), SendOnceOverride_( false ) {}

   void ProcessExtQuery( const TExtQuery & ExtQuery )
   {
      if ( ExtQuery.QueryTransRate == eQUERY_ON_CHANGE )
      {
         SetSendInterval( false );
         SetSendChange( true );
      }
      else if ( ExtQuery.QueryTransRate == eQUERY_RATE )
      {
         SetSendChange( false );
         SetSendInterval( true, ExtQuery.Interval*1000 );
      }
      else if ( ExtQuery.QueryTransRate == eQUERY_ONCE )
      {
         SetSendChange( false );
         SetSendInterval( false );
         SetSendOnce( true );
      }
      else
      {
         SetSendChange( false );
         SetSendInterval( false );
         SetSendOnce( false );
      }
   }

   void SetSendInterval( const bool InSendInterval, const int InIntervalTimeMillisec=0 )
   {

      SendInterval_                = InSendInterval;

      if ( SendInterval_ )
      {
         SendChange_               = false;
         LastTimeSentMillisec_     = 0;  // Will trigger immediately
         IntervalMillisec_         = InIntervalTimeMillisec;
         SendOnceOverride_         = true;
      }
      else
      {
         IntervalMillisec_         = 0;
      }
   }

   int  const      GetSendInterval() const { return( SendInterval_ ); }

   void SetSendChange( const bool InSendChange )
   {
      SendChange_ = InSendChange;
      if ( SendChange_ )
      {
         SendInterval_             = false;
         IntervalMillisec_         = 0;
         LastTimeSentMillisec_     = 0;
         SendOnceOverride_         = true;
      }
   }

   bool const      GetSendChange() const { return( SendChange_ ); }

   void SetSendOnce( const bool InSendOnce )
   {
      if ( InSendOnce )
      {
         SendOnceOverride_         = true;
      }
   }

   bool const      GetSendOnce() const { return( SendOnceOverride_ ); }

   bool const ShouldSend( const int CurTimeMillisec, const T &CurT )
   {
      bool Send = false;
      if ( SendOnceOverride_ )
      {
         Send                      = true;
         SendOnceOverride_         = false;
      }
      else if ( SendInterval_ )
      {
         Send                      = ( ( CurTimeMillisec - LastTimeSentMillisec_ ) > IntervalMillisec_ );
      }
      else if ( SendChange_ )
      {
         Send                      = ( SentT_ != CurT );
      }

      if ( Send )
      {
         LastTimeSentMillisec_     = CurTimeMillisec;
         SentT_                    = CurT;
      }

      return( Send );

   }

   __property bool           SendInterval           = { read = GetSendInterval                              };
   __property bool           SendChange             = { read = GetSendChange,         write = SetSendChange };
   __property bool           SendOnce               = { read = GetSendOnce,           write = SetSendOnce   };
   __property int            IntervalMillisec       = { read = IntervalMillisec_                            };
   __property int            LastTimeSentMillisec   = { read = LastTimeSentMillisec_                        };
   __property T              SentT                  = { read = SentT_                                       };

};


#endif
