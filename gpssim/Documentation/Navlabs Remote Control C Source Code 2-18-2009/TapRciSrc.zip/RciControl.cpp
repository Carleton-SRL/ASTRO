#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: RciControl.cpp                                        $
//
// $Revision:: 10                                                    $
//
// $History:: RciControl.cpp                                         $
//
//*****************  Version 10  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:13p
//Updated in $/TapRci
//Only open TpMapInterface required to avoid conflict w/ TapMsec.
//
//*****************  Version 9  *****************
//User: Michael Wade Date: 1/19/05    Time: 8:55a
//Updated in $/TapRci
//Handle case where TapMsec does not shut down.
//
//*****************  Version 8  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Add ScenarioSetPulseMsg
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 1/16/04    Time: 10:41p
//Updated in $/TapRci
//Add "SetL2Atten" message.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 1/05/04    Time: 11:23a
//Updated in $/TapRci
//Allow SetPower in local and scenario modes.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:25p
//Updated in $/TapRci
//Add Time Set Pulse message processing.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:32p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:51p
//Updated in $/TapRci
//Add REGENSCEN.
//
//
//---------------------------------------------------------------------------


#ifndef RciControlH
#include "RciControl.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef RciMsgsH
#include "RciMsgs.h"
#endif

#ifndef UtilitiesH
#include "Utilities.h"
#endif

#ifndef TpMapInterfaceH
#include "TpMapInterface.h"
#endif

#ifndef PowerCalIniH
#include "PowerCalIni.h"
#endif

#ifndef EthernetH
#include "Ethernet.h"
#endif

#ifndef ComPortInterfaceH
#include "ComPortInterface.h"
#endif

#ifndef ThreadInfH
#include "ThreadInf.h"
#endif


#pragma package(smart_init)

static const int             RciControlUpdateRate              = 10;
static const int             RCICONTROL_EXECUTE_TIMER_MS       = 1000;
AnsiString                   TRciControl::EventReceiveDataName = AnsiString( "TRciControlReceiveDataEvent" );


__fastcall
TRciControl::TRciControl
   (
   TComponent * InOwner
   ) :
   TThread( true ),
   Valid_( false ),
   Interface( NULL ),
   TapMsecStatMem( NULL ),
   AckEvery( false ),
   TapRciProfile( NULL ),
   TapMsecProfile( NULL ),
   SimMode( eSimIdle ),
   CurTimeMillisec( 0 ),
   Owner( InOwner ),
   hTimer( NULL ),
   EventReceiveData( NULL ),
   TpMapInterface_( NULL ),
   TapMsecShutdown_( false )
{

   TpMapInterface_           = new TTpMapInterface();

   ClearTapMsecProcInfo();
   ClearWinVpgProcInfo();

   GetSysCfg();

   TapRciProfile             = new TTapRciProfile();
   AckEvery                  = TapRciProfile->AckEvery;
   TapRciProfile->AckEvery   = AckEvery;

   TapMsecProfile            = new TTapMsecProfile();
   Vdp                       = new VoyDefProfile();
   RunsDir                   = Vdp->GetRunsDir();

   TapMsecStatMem            = new TTapMsecStatMem();
   TapMsecCommandMem         = new TTapMsecCommandMem();

   EventReceiveData          = new TEvent( NULL, false, false, TRciControl::GetEventReceiveDataName() );

   Valid_                    = !InitializeInterface();

   if ( !Valid_ )
   {
      CodeSite->SendMsg( csmError, "TRciControl::TRciControl InitializeInterface Error" );
      Application->MessageBox( " TRciControl::InitializeInterface failed.", "Fatal Error", MB_OK );
      Application->Terminate();
      Application->ProcessMessages();
   }

   SetupTimer();

   ScheduleSignal            = new TScheduleSignal();
   ScheduleSignal->Resume();

   SimModeQuery.SendChange   = TapRciProfile->MsgSimModeOnChange;
   ChanStatQuery.SendChange  = TapRciProfile->MsgChanStatOnChange;

}

void
TRciControl::SetupTimer
   (
   )
{

   hTimer                  = CreateWaitableTimer( NULL, FALSE,  NULL );

   __int64 qwDueTime       = -5;

   // Copy the relative time into a LARGE_INTEGER.
   //
   LARGE_INTEGER   liDueTime;
   liDueTime.LowPart       = (DWORD) ( qwDueTime & 0xFFFFFFFF );
   liDueTime.HighPart      = (LONG)  ( qwDueTime >> 32 );

   SetWaitableTimer
   (
      hTimer,                                              // Handle to the timer object.
      &liDueTime,                                          // When timer will become signaled.
      RCICONTROL_EXECUTE_TIMER_MS,                         // Periodic timer interval millisecs.
      NULL,                                                // Completion routine.
      NULL,                                                // Argument to the completion routine.
      FALSE                                                // Do not restore a suspended system.
   );

}



__fastcall
TRciControl::~TRciControl()
{

   CloseHandle( hTimer );
   delete Interface;
   delete TapMsecStatMem;
   delete TapRciProfile;
   delete TapMsecProfile;
   delete Vdp;
   delete ScheduleSignal;
   delete TapMsecCommandMem;
   delete EventReceiveData;
   delete TpMapInterface_;

}

//---------------------------------------------------------------------------
void __fastcall
TRciControl::Execute
   (
   )
{

   TThreadInf TThreadInf( "RciControl" );

   HANDLE SyncObjects[2];
   int NumSyncObjects            = 0;
   SyncObjects[NumSyncObjects++] = hTimer;
   SyncObjects[NumSyncObjects++] = (void *) EventReceiveData->Handle;

   while ( !Terminated )
   {

      const int WaitResult  = WaitForMultipleObjects( NumSyncObjects, SyncObjects, FALSE, RCICONTROL_EXECUTE_TIMER_MS*2 );

      WaitDebugProcessing( WaitResult );

      if ( Terminated ) break;

      CurTimeMillisec = TScheduleSignal::GetCurTimeMillisec();

      GetControlData();

      TOutMsgQueue OutMsgs;
      TInMsgArray  InMsgArray;

      Interface->GetInputMsgs( InMsgArray );

      ProcessInputMsgs( InMsgArray, OutMsgs );

      ProcessQueries( OutMsgs );

      Interface->QueueMsgs( OutMsgs );

      ProcessTapMsecCommands();

   }

   if ( Interface )
   {
      Interface->Terminate();
      Interface->WaitFor();
   }
}

void
TRciControl::GetControlData
   (
   )
{

   TapMsecStat_    = CurrentTapMsecStat;
   SimMode         = SetCurrentSimMode();

   ChanStatArray.clear();

   for ( int i=0; i<NUM_CHANS_IN_STAT; ++i )
   {
      if ( SimMode != eSimIdle )
      {
         if ( TapMsecStat_.ChanStat[i].Chan >= 0 )
         {
            TChanStat ChanStat( TapMsecStat_.ChanStat[i].Svid, NINT( TapMsecStat_.ChanStat[i].L1Power ), NINT( TapMsecStat_.ChanStat[i].L2Power ) );
            ChanStatArray.push_back( ChanStat );
         }
      }
      else
      {
         ChanStatArray.push_back( TChanStat( 0, 0 ) );
      }
   }
}

void
TRciControl::ProcessQueries
   (
   TOutMsgQueue            & OutMsgs
   )
{

   if ( SimModeQuery.ShouldSend( CurTimeMillisec, SimMode ) )
   {
      SendSimMode( OutMsgs );
   }

   if ( ( SimMode != eSimIdle ) && ChanStatQuery.ShouldSend( CurTimeMillisec, ChanStatArray ) )
   {
      SendChanStat( OutMsgs );
   }

   if ( BitResultsQuery.ShouldSend( CurTimeMillisec, TapBitResults ) )
   {
      if ( SimMode == eSimIdle )
      {
         PerformBit();
      }
      SendBitResults( OutMsgs );
   }

   if ( SysCfgQuery.ShouldSend( CurTimeMillisec, SysCfg ) )
   {
      SendSysCfg( OutMsgs );
   }

   if ( SimTimeQuery.ShouldSend( CurTimeMillisec, TapMsecStat_ ) )
   {
      AnsiString TmpStr;
      TmpStr.sprintf( "TapMsecStat_->SecondsIntoSim %lf", TapMsecStat_.SecondsIntoSim); 
      CodeSite->SendMsg( TmpStr );
      SendSimTime( OutMsgs );
   }

}

void
TRciControl::SendSimMode
   (
   TOutMsgQueue            & OutMsgs
   )
{
   OutMsgs.push( TSimModeMsg( SimMode ) );
}

void
TRciControl::SendSysCfg
   (
   TOutMsgQueue            & OutMsgs
   )
{
   OutMsgs.push( TSysCfgMsg( SysCfg ) );
}

void
TRciControl::SendSimTime
   (
   TOutMsgQueue            & OutMsgs
   )
{
   TSimTime SimTime        = TapMsecStat_;
   OutMsgs.push( TSimTimeMsg( SimTime ) );
}

void
TRciControl::SendChanStat
   (
   TOutMsgQueue            & OutMsgs
   )
{
   OutMsgs.push( TChanStatMsg( ChanStatArray ) );
}

eRciSimMode const
TRciControl::GetCurrentSimMode
   (
   )
{
   return( SimMode );
}

eRciSimMode const
TRciControl::SetCurrentSimMode
   (
   )
{
   eRciSimMode lCurSimMode = eSimIdle;

   // If started TapMsec, check if it is still running...
   //
   if ( SimMode == eSimLocal || SimMode == eSimScen )
   {
      if ( TapMsecProcInfo.hProcess )
      {
         DWORD ExitCode;

         if ( GetExitCodeProcess( TapMsecProcInfo.hProcess, &ExitCode ) )
         {
            if ( ExitCode == STILL_ACTIVE )
            {
               lCurSimMode = SimMode;
               if ( TapMsecShutdown_ )
               {
                  CodeSite->SendMsg( "TerminateProcess TapMsec" );
                  TerminateProcess( TapMsecProcInfo.hProcess, 0 );
                  TapMsecShutdown_ = false;
               }
            }
            else
            {
               ClearTapMsecProcInfo();
            }

         }
         else
         {
            ReportErrorAndTerminate( "Error getting exit code for TapMsec" );
         }
      }
   }

   // If started WinVpg, check if it is still running...
   //
   if ( SimMode == eSimRegen )
   {
      if ( WinVpgProcInfo.hProcess )
      {
         DWORD ExitCode;

         if ( GetExitCodeProcess( WinVpgProcInfo.hProcess, &ExitCode ) )
         {
            if ( ExitCode == STILL_ACTIVE )
            {
               lCurSimMode = SimMode;
            }
            else
            {
               ClearWinVpgProcInfo();
            }

         }
         else
         {
            ReportErrorAndTerminate( "Error getting exit code for WinVpg" );
         }
      }
   }

   // If waiting for Reset Pulse, just say so...
   //
   if ( ( SimMode == eSimExtResetPulseWaitLocal ) || ( SimMode == eSimExtResetPulseWaitScen ) )
   {

      if ( TpMapInterface->ExtResetPulseRcvd )
      {

         CodeSite->SendMsg( "GetCurrentSimMode. ExtResetPulseRcvd." );

         ProcessExtResetPulseRcvd();

         lCurSimMode       = eSimIdle;
         if ( SimMode == eSimExtResetPulseWaitLocal )
         {

            if ( StartRemoteScenario() )
            {
               lCurSimMode = eSimLocal;
            }

         }
         else if ( SimMode == eSimExtResetPulseWaitScen )
         {

            lCurSimMode = eSimScen;

            CodeSite->SendMsg( "GetCurrentSimMode. Starting scenario after pulse received." );
            
            AnsiString Parameters   = ExtResetPulseScenarioPath_ + AnsiString( " 1 0 " );
            RunStartScen( Parameters );

         }
         else
         {
            lCurSimMode = eSimIdle;
         }
      }
      else
      {
         lCurSimMode = SimMode;
      }
   }

   return( lCurSimMode );

}

void
TRciControl::ProcessExtResetPulseRcvd
   (
   )
{


}

bool const
TRciControl::GetWaitForExtResetPulseArmed
   (
   )
{
   return( ( SimMode == eSimExtResetPulseWaitLocal ) || ( SimMode == eSimExtResetPulseWaitScen ) );
}


void
TRciControl::ProcessInputMsgs
   (
   TInMsgArray             & InMsgArray,
   TOutMsgQueue            & OutMsgs
   )
{

   for ( unsigned int i=0; i<InMsgArray.size(); ++i )
   {
      ProcessInputMsg( InMsgArray[i], OutMsgs );
   }

}

void
TRciControl::ProcessInputMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   AnsiString MsgId = ( InMsg.GetMsgId() ).UpperCase();

   CodeSite->SendMsg( AnsiString( "Received external message: " ) + MsgId );
   if ( MsgId == InitGeoMsgId )
   {
      ProcessInitGeoMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == TimeSetPulseMsgId )
   {
      ProcessTimeSetPulseMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == StartScenMsgId )
   {
      ProcessStartScenMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == StartScenStartPulseMsgId )
   {
      ProcessStartScenStartPulseMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == RegenScenMsgId )
   {
      ProcessRegenScenMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == ExecMsgId )
   {
      ProcessExecMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == StartLocalMsgId )
   {
      ProcessStartLocalMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == SetSvidMsgId )
   {
      ProcessSetSvidMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == SetPowerMsgId )
   {
      ProcessSetPowerMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == SetL1AttenMsgId )
   {
      ProcessSetL1AttenMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == SetL2AttenMsgId )
   {
      ProcessSetL2AttenMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == StopMsgId )
   {
      ProcessStopMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == ShutdownMsgId )
   {
      ProcessShutdownMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == ResetMsgId )
   {
      ProcessResetMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == QueryMsgId )
   {
      ProcessQueryMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == SetRfGainMsgId )
   {
      ProcessSetRfGainMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == AdjustRfGainMsgId )
   {
      ProcessAdjustRfGainMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == SetRfAttenMsgId )
   {
      ProcessSetRfAttenMsg( InMsg, OutMsgs );
   }
   else if ( MsgId == AdjustRfAttenMsgId )
   {
      ProcessAdjustRfAttenMsg( InMsg, OutMsgs );
   }
   else
   {
      ProcessUnknownMsg( InMsg, OutMsgs );
   }

}

void
TRciControl::ProcessUnknownMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{
   try
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), false, true ) );
   }
   catch(...)
   {
   }
}

void
TRciControl::ProcessInitGeoMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TInitGeoMsg InitGeoMsg  = InMsg;

   bool ShouldSendAck      = !InitGeoMsg.Valid || AckEvery;

   if ( InitGeoMsg.Valid )
   {
      TapMsecProfile->SetPos( InitGeoMsg.Lat, InitGeoMsg.Lon, InitGeoMsg.Alt );
      TapMsecProfile->SetDate( InitGeoMsg.Date );
      TapMsecProfile->SetTime( InitGeoMsg.Time );
   }

   AnsiString CsStr;
   if ( InitGeoMsg.Valid )
   {
      CsStr.sprintf("InitGeo: Lat = %lf Lon = %lf, Alt = %d ", InitGeoMsg.Lat, InitGeoMsg.Lon, InitGeoMsg.Alt );
      CsStr += AnsiString( " D = " ) + InitGeoMsg.Date + AnsiString( "T = " ) + InitGeoMsg.Time;
      CodeSite->SendMsg( CsStr );
   }
   else
   {
      CodeSite->SendMsg( "InitGeo: Invalid Message ");
   }

   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), InitGeoMsg.Valid, true ) );
   }

}

void
TRciControl::ProcessTimeSetPulseMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TTimeSetPulseMsg TimeSetPulseMsg  = InMsg;

   bool MsgValid                 = TimeSetPulseMsg.Valid;
   bool SimModeValid             = ( SimMode == eSimIdle );

   if ( SimModeValid )
   {

      if ( TimeSetPulseMsg.Valid )
      {

         TapMsecProfile->SetPos( TimeSetPulseMsg.Lat, TimeSetPulseMsg.Lon, TimeSetPulseMsg.Alt );
         TapMsecProfile->SetDate( TimeSetPulseMsg.Date );
         TapMsecProfile->SetTime( TimeSetPulseMsg.Time );

         TpMapInterface->ArmExtResetPulse = true;

         SimMode                 = eSimExtResetPulseWaitLocal;

      }

      AnsiString CsStr;
      if ( TimeSetPulseMsg.Valid )
      {
         CsStr.sprintf("TimeSetPulse: Lat = %lf Lon = %lf, Alt = %d ", TimeSetPulseMsg.Lat, TimeSetPulseMsg.Lon, TimeSetPulseMsg.Alt );
         CsStr += AnsiString( " D = " ) + TimeSetPulseMsg.Date + AnsiString( "T = " ) + TimeSetPulseMsg.Time;
         CodeSite->SendMsg( CsStr );
      }
      else
      {
         CodeSite->SendMsg( "TimeSetPulse: Invalid Message ");
      }

   }

   bool ShouldSendAck            = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessStartScenStartPulseMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{


   TStartScenStartPulseMsg ScenarioSetPulseMsg  = InMsg;

   bool MsgValid                 = ScenarioSetPulseMsg.Valid;
   bool SimModeValid             = ( SimMode == eSimIdle );

   if ( SimModeValid )
   {
      ExtResetPulseScenName_     = ScenarioSetPulseMsg.GetScenName();

      ExtResetPulseScenarioPath_ = RunsDir + AnsiString( "\\" ) + ExtResetPulseScenName_;

      if ( IsValidScenario( ExtResetPulseScenarioPath_ ) )
      {

         TpMapInterface->ArmExtResetPulse = true;

         SimMode                 = eSimExtResetPulseWaitScen;

      }
      else
      {
         MsgValid = false;
      }

      AnsiString CsStr;
      if ( ScenarioSetPulseMsg.Valid )
      {
         CsStr.sprintf( "ProcessScenarioSetPulse: %s ", ScenarioSetPulseMsg.GetScenName() );
         CodeSite->SendMsg( CsStr );
      }
      else
      {
         CodeSite->SendMsg( "ProcessScenarioSetPulse: Invalid Message ");
      }
   }

   bool ShouldSendAck            = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}


bool const
TRciControl::InitializeInterface
   (
   )
{

   delete Interface;

   Interface                     = NULL;

   bool iError                   = true;

   if ( TapRciProfile->Gpib )
   {
      Interface                  = new TGpib( Owner );
   }
   else if ( TapRciProfile->Ethernet && TapRciProfile->EthernetServer )
   {
      Interface                  = new TEthernetServer( Owner );
   }
   else if ( TapRciProfile->Serial )
   {
      Interface                  = new TComPortInterface( Owner );
   }

   if ( Interface && Interface->ValidInterface )
   {
      Interface->Resume();
      iError                     = false;
   }

   return( iError );

}

TTapMsecStat const
TRciControl::GetCurrentTapMsecStat
   (
   )
{
   if ( ( SimMode == eSimScen ) || ( SimMode == eSimLocal ) )
   {
      return( TapMsecStatMem->GetCurrent() );
   }
   else
   {
      return( TTapMsecStat() );
   }
}

void
TRciControl::ProcessStartScenMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TStartScenMsg StartScenMsg    = InMsg;

   bool MsgValid                 = StartScenMsg.Valid;
   bool SimModeValid             = ( SimMode == eSimIdle );

   if ( SimMode == eSimIdle )
   {
      AnsiString ScenName        = StartScenMsg.GetScenName();

      AnsiString ScenarioPath    = RunsDir + AnsiString( "\\" ) + ScenName;

      if ( IsValidScenario( ScenarioPath ) )
      {

         AnsiString Parameters   = ScenarioPath + AnsiString( " 1 0 " );
         RunStartScen( Parameters );
         SimMode                 = eSimScen;

      }
      else
      {
         MsgValid = false;
      }
   }

   bool ShouldSendAck            = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessStartLocalMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{


   bool MsgValid                 = true;
   bool SimModeValid             = ( SimMode == eSimIdle );

   if ( SimMode == eSimIdle )
   {

      if ( StartRemoteScenario() )
      {
         SimMode                 = eSimLocal;
      }
      else
      {
         MsgValid                = false;
      }
   }

   bool ShouldSendAck            = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

bool const
TRciControl::StartRemoteScenario
   (
   )
{

   bool Started               = false;

   AnsiString ScenarioPath    = TapRciProfile->RemoteScn;

   if ( IsValidScenario( ScenarioPath ) )
   {

      AnsiString Parameters   = ScenarioPath + AnsiString( " 1 0 " );

      RunStartScen( Parameters );

      Started                 = true;

   }

   return( Started );

}

void
TRciControl::RunStartScen
   (
   const AnsiString & Parameters
   )
{

   AnsiString TapMsecPath = TapRciProfile->TapMsecPath;
   AnsiString ExecStr     = TapMsecPath + AnsiString( " " ) + Parameters;

   CodeSite->SendMsg( AnsiString( "StartScen: " ) + ExecStr );
   char cmd[1000];
   strcpy( cmd, ExecStr.c_str() );
   STARTUPINFO Start;
   GetStartupInfo( &Start );

   CreateProcess
      (
      NULL,
      cmd,
      NULL,               // Sec
      NULL,               // Thread
      FALSE,              // Inherit
      CREATE_NEW_CONSOLE, // Creating flags
      NULL,               // Environment
      NULL,               // Current directory
      &Start,             // Startup info
      &TapMsecProcInfo    // Process info
      );

}

void
TRciControl::ProcessRegenScenMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TRegenScenMsg RegenScenMsg    = InMsg;

   bool MsgValid                 = RegenScenMsg.Valid;
   bool SimModeValid             = ( SimMode == eSimIdle );

   if ( SimMode == eSimIdle )
   {
      AnsiString ScenName        = RegenScenMsg.GetScenName();

      AnsiString ScenarioPath    = RunsDir + AnsiString( "\\" ) + ScenName;

      if ( IsValidScenario( ScenarioPath ) )
      {

         AnsiString Parameters   = AnsiString( " 11 " ) + ScenarioPath;
         RunRegenScen( Parameters );
         SimMode                 = eSimRegen;

      }
      else
      {
         MsgValid                = false;
      }
   }

   bool ShouldSendAck            = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void TRciControl::RunRegenScen
   (
   const AnsiString        & Parameters
   )
{

   AnsiString WinVpgPath  = TapRciProfile->WinVpgPath;
   AnsiString ExecStr     = WinVpgPath + AnsiString( " " ) + Parameters;

   CodeSite->SendMsg( AnsiString( "RegenScen: " ) + ExecStr );
   char cmd[1000];
   strcpy( cmd, ExecStr.c_str() );
   STARTUPINFO Start;
   GetStartupInfo( &Start );

   CreateProcess
      (
      NULL,
      cmd,
      NULL,               // Sec
      NULL,               // Thread
      FALSE,              // Inherit
      CREATE_NEW_CONSOLE, // Creating flags
      NULL,               // Environment
      NULL,               // Current directory
      &Start,             // Startup info
      &WinVpgProcInfo     // Process info
      );

}

void
TRciControl::ProcessExecMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TExecMsg ExecMsg              = InMsg;

   bool MsgValid                 = ExecMsg.Valid;
   bool SimModeValid             = ( SimMode == eSimIdle );

   if ( SimMode == eSimIdle )
   {

      AnsiString ExecParams      = ExecMsg.GetExecParams();

      CodeSite->SendMsg( AnsiString( "Exec: " ) + ExecParams );
      char cmd[1000];
      strcpy( cmd, ExecParams.c_str() );
      STARTUPINFO Start;
      PROCESS_INFORMATION       ProcInfo;
      GetStartupInfo( &Start );

      CreateProcess
         (
         NULL,
         cmd,
         NULL,               // Sec
         NULL,               // Thread
         FALSE,              // Inherit
         CREATE_NEW_CONSOLE, // Creating flags
         NULL,               // Environment
         NULL,               // Current directory
         &Start,             // Startup info
         &ProcInfo           // Process info
         );

   }

   bool ShouldSendAck            = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessSetSvidMsg
   (
   const TInMsg &InMsg,
   TOutMsgQueue &OutMsgs
   )
{

   TSetSvidMsg SetSvidMsg = InMsg;

   bool MsgValid     = SetSvidMsg.Valid;
   bool SimModeValid = ( SimMode == eSimLocal );

   if ( SimMode == eSimLocal )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command       = TTapMsecCommand::eCommandSvid;

      TChanSvidArray ChanSvidArray = SetSvidMsg.GetChanSvidArray();

      int NumChans = min( (int) ChanSvidArray.size(), NUM_CHANS_IN_COMMAND );
      for ( int i=0; i<NumChans; ++i )
      {
         TapMsecCommand.CommandSvid[i] = TTapMsecCommandSvid( ChanSvidArray[i].GetChan(), ChanSvidArray[i].GetSvid() );
      }

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   bool ShouldSendAck = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessSetPowerMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TSetPowerMsg SetPowerMsg = InMsg;

   const bool MsgValid      = SetPowerMsg.Valid;
   const bool SimModeValid  = ( ( SimMode == eSimLocal ) || ( SimMode == eSimScen ) );

   if ( SimModeValid )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command         = TTapMsecCommand::eCommandPower;

      TChanPowerArray ChanPowerArray = SetPowerMsg.GetChanPowerArray();

      int NumChans = min( (int) ChanPowerArray.size(), NUM_CHANS_IN_COMMAND );
      for ( int i=0; i<NumChans; ++i )
      {
         TapMsecCommand.CommandPower[i] = TTapMsecCommandPower( ChanPowerArray[i].GetChan(), ChanPowerArray[i].GetPower() );
      }

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   bool ShouldSendAck = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessSetL1AttenMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TSetL1AttenMsg SetL1AttenMsg           = InMsg;

   const bool MsgValid                    = SetL1AttenMsg.Valid;
   const bool SimModeValid                = ( ( SimMode == eSimLocal ) || ( SimMode == eSimScen ) );

   if ( SimModeValid )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command              = TTapMsecCommand::eCommandL1Atten;

      // Clear all L1Atten commands.
      //

      for ( int i=0; i<NUM_CHANS_IN_COMMAND; ++i )
      {
         TapMsecCommand.CommandL1Atten[i] = TTapMsecCommandL1Atten( -1, 0 );
      }

      TChanL1AttenArray ChanL1AttenArray  = SetL1AttenMsg.ChanL1AttenArray;

      const int NumChans                  = min( (int) ChanL1AttenArray.size(), NUM_CHANS_IN_COMMAND );
      for ( int i=0; i<NumChans; ++i )
      {
         TapMsecCommand.CommandL1Atten[i] = TTapMsecCommandL1Atten( ChanL1AttenArray[i].Chan, ChanL1AttenArray[i].L1Atten );
      }

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   bool ShouldSendAck                     = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessSetL2AttenMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TSetL2AttenMsg SetL2AttenMsg           = InMsg;

   const bool MsgValid                    = SetL2AttenMsg.Valid;
   const bool SimModeValid                = ( ( SimMode == eSimLocal ) || ( SimMode == eSimScen ) );

   if ( SimModeValid )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command              = TTapMsecCommand::eCommandL2Atten;

      // Clear all L2Atten commands.
      //

      for ( int i=0; i<NUM_CHANS_IN_COMMAND; ++i )
      {
         TapMsecCommand.CommandL2Atten[i] = TTapMsecCommandL2Atten( -1, 0 );
      }

      TChanL2AttenArray ChanL2AttenArray  = SetL2AttenMsg.ChanL2AttenArray;

      const int NumChans                  = min( (int) ChanL2AttenArray.size(), NUM_CHANS_IN_COMMAND );
      for ( int i=0; i<NumChans; ++i )
      {
         TapMsecCommand.CommandL2Atten[i] = TTapMsecCommandL2Atten( ChanL2AttenArray[i].Chan, ChanL2AttenArray[i].L2Atten );
      }

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   bool ShouldSendAck                     = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessStopMsg
   (
   const TInMsg &InMsg,
   TOutMsgQueue &OutMsgs
   )
{

   bool MsgValid     = true;
   bool SimModeValid = true;

   if ( SimMode != eSimIdle )
   {

      if ( ( SimMode == eSimExtResetPulseWaitLocal ) || ( SimMode == eSimExtResetPulseWaitScen ) )
      {

         CancelExtResetPulse();
      }
      else
      {

         TTapMsecCommand  TapMsecCommand;
         TapMsecCommand.Command         = TTapMsecCommand::eCommandStop;

         TapMsecCommandQueue.push( TapMsecCommand );
         TapMsecShutdown_               = true;

      }

   }

   bool ShouldSendAck = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

   CodeSite->SendMsg( "Sending STOP message TRciControl::ProcessStopMsg" );

}

void
TRciControl::ProcessShutdownMsg
   (
   const TInMsg &InMsg,
   TOutMsgQueue &OutMsgs
   )
{
   HANDLE hToken;
   TOKEN_PRIVILEGES tkp;

   // Get a token for this process.
   //
   if (!OpenProcessToken( GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken ) )
   {
      ReportErrorAndTerminate( "OpenProcessToken" );
   }

   // Get the LUID for the shutdown privilege.
   //
   LookupPrivilegeValue( NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid );

   tkp.PrivilegeCount = 1;  // one privilege to set
   tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

   // Get the shutdown privilege for this process.
   //
   AdjustTokenPrivileges( hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0 );

   // Cannot test the return value of AdjustTokenPrivileges.
   //
   if ( GetLastError() != ERROR_SUCCESS )
   {
      ReportErrorAndTerminate( "AdjustTokenPrivileges" );
   }

   // Shut down the system and force all applications to close.
   //
   if ( !ExitWindowsEx(EWX_POWEROFF | EWX_FORCE, 0 ) )
   {
      ReportErrorAndTerminate( "ExitWindowsEx" );
   }
}

void
TRciControl::ProcessResetMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   HANDLE hToken;
   TOKEN_PRIVILEGES tkp;

   // Get a token for this process.
   //
   if (!OpenProcessToken( GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken ) )
   {
      ReportErrorAndTerminate( "OpenProcessToken" );
   }

   // Get the LUID for the shutdown privilege.
   //
   LookupPrivilegeValue( NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid );

   tkp.PrivilegeCount = 1;  // one privilege to set
   tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

   // Get the shutdown privilege for this process.
   //
   AdjustTokenPrivileges( hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0 );

   // Cannot test the return value of AdjustTokenPrivileges.
   //
   if ( GetLastError() != ERROR_SUCCESS )
   {
      ReportErrorAndTerminate( "AdjustTokenPrivileges" );
   }

   // Shut down the system and force all applications to close.
   //
   if ( !ExitWindowsEx(EWX_REBOOT | EWX_FORCE, 0 ) )
   {
      ReportErrorAndTerminate( "ExitWindowsEx" );
   }
}

void
TRciControl::ProcessQueryMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TQueryMsg QueryMsg      = InMsg;
   bool MsgValid           = QueryMsg.Valid;
   bool SimModeValid       = true;

   TExtQuery ExtQuery      = QueryMsg.GetExtQuery();


   if ( ExtQuery.QueryType == eQUERY_SIM_MODE )
   {
      SimModeQuery.ProcessExtQuery( ExtQuery );
   }
   else if ( ExtQuery.QueryType == eQUERY_CHAN_STAT )
   {
      ChanStatQuery.ProcessExtQuery( ExtQuery );
   }
   else if ( ExtQuery.QueryType == eQUERY_BIT_RESULTS )
   {
      BitResultsQuery.ProcessExtQuery( ExtQuery );
   }
   else if ( ExtQuery.QueryType == eQUERY_SYS_CFG )
   {
      SysCfgQuery.ProcessExtQuery( ExtQuery );
   }
   else if ( ExtQuery.QueryType == eQUERY_SIMTIME )
   {
      if ( ( CurSimMode == eSimLocal ) || ( CurSimMode == eSimScen ) )
      {
         SimTimeQuery.ProcessExtQuery( ExtQuery );
      }
      else
      {
         SimModeValid      = false;
      }
   }
   else
   {
      MsgValid = false;
   }


   bool ShouldSendAck = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessSetRfGainMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TSetRfGainMsg SetRfGainMsg = InMsg;

   const bool MsgValid        = SetRfGainMsg.Valid;
   const bool SimModeValid    = ( ( SimMode == eSimLocal ) || ( SimMode == eSimScen ) );

   if ( SimModeValid )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command                    = TTapMsecCommand::eCommandSetRfAtten;
      TapMsecCommand.CommandSetRfAtten.RfAtten  = MAX_RF_GAIN - SetRfGainMsg.RfGain;

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   const bool ShouldSendAck   = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessAdjustRfGainMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TAdjustRfGainMsg AdjustRfGainMsg = InMsg;

   const bool MsgValid              = AdjustRfGainMsg.Valid;
   const bool SimModeValid          = ( ( SimMode == eSimLocal ) || ( SimMode == eSimScen ) );

   if ( SimModeValid )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command                             = TTapMsecCommand::eCommandAdjustRfAtten;
      TapMsecCommand.CommandAdjustRfAtten.AdjustRfAtten  = -( AdjustRfGainMsg.AdjustRfGain );

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   const bool ShouldSendAck   = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}


void
TRciControl::ProcessSetRfAttenMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TSetRfAttenMsg SetRfAttenMsg = InMsg;

   const bool MsgValid        = SetRfAttenMsg.Valid;
   const bool SimModeValid    = ( ( SimMode == eSimLocal ) || ( SimMode == eSimScen ) );

   if ( SimModeValid )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command                    = TTapMsecCommand::eCommandSetRfAtten;
      TapMsecCommand.CommandSetRfAtten.RfAtten  = SetRfAttenMsg.RfAtten;

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   const bool ShouldSendAck   = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::ProcessAdjustRfAttenMsg
   (
   const TInMsg            & InMsg,
   TOutMsgQueue            & OutMsgs
   )
{

   TAdjustRfAttenMsg AdjustRfAttenMsg = InMsg;

   const bool MsgValid                = AdjustRfAttenMsg.Valid;
   const bool SimModeValid            = ( ( SimMode == eSimLocal ) || ( SimMode == eSimScen ) );

   if ( SimModeValid )
   {

      TTapMsecCommand  TapMsecCommand;
      TapMsecCommand.Command                             = TTapMsecCommand::eCommandAdjustRfAtten;
      TapMsecCommand.CommandAdjustRfAtten.AdjustRfAtten  = AdjustRfAttenMsg.AdjustRfAtten;

      TapMsecCommandQueue.push( TapMsecCommand );

   }

   const bool ShouldSendAck   = !MsgValid || AckEvery || !SimModeValid;
   if ( ShouldSendAck )
   {
      OutMsgs.push( TAckMsg( InMsg.GetMsgId(), MsgValid, SimModeValid ) );
   }

}

void
TRciControl::PerformBit()
{

   TapBitResults                      = TpMapInterface->RunBit();

}

void
TRciControl::SendBitResults
   (
   TOutMsgQueue &OutMsgs
   )
{

   OutMsgs.push( TBitResultsMsg( TapBitResults ) );

}


void
TRciControl::ReportErrorAndTerminate
   (
   const AnsiString & ErrorStr
   )
{
   CodeSite->SendMsg( ErrorStr );
   Application->MessageBox( ErrorStr.c_str(), "Fatal Error", MB_OK );
   Application->Terminate();
}

void
TRciControl::ClearTapMsecProcInfo()
{
   TapMsecProcInfo.hProcess    = 0;
   TapMsecProcInfo.hThread     = 0;
   TapMsecProcInfo.dwProcessId = 0;
   TapMsecProcInfo.dwThreadId  = 0;
   TapMsecShutdown_            = false;
}

void
TRciControl::ClearWinVpgProcInfo()
{
   WinVpgProcInfo.hProcess     = 0;
   WinVpgProcInfo.hThread      = 0;
   WinVpgProcInfo.dwProcessId  = 0;
   WinVpgProcInfo.dwThreadId   = 0;
}

TMsgTrafficArray const
TRciControl::GetMsgTrafficArray()
{
   return( Interface->GetMsgTrafficArray() );
}

void
TRciControl::GetSysCfg()
{

   TPowerCalIni *PowerCalIni = new TPowerCalIni();

   SysCfg.NumChans  = 12;
   SysCfg.L2Capable = false;
   SysCfg.MinPower  = NINT( PowerCalIni->GetL1MaxPower() - PowerCalIni->GetExtAtten() - TP_MAX_ATTEN_DB );
   SysCfg.MaxPower  = NINT( PowerCalIni->GetL1MaxPower() - PowerCalIni->GetExtAtten() );

   delete PowerCalIni;

}

void
TRciControl::ProcessTapMsecCommands
   (
   )
{

   if ( !TapMsecCommandQueue.empty() )
   {

      if ( !TapMsecCommandMem->IsSet() )
      {

         AnsiString Str;
         Str.sprintf("TapMsecCommand: %d", TapMsecCommandQueue.front().Command );
         CodeSite->SendMsg( Str );
         TapMsecCommandMem->SetCurrent( TapMsecCommandQueue.front() );
         TapMsecCommandQueue.pop();

      }

   }

}

bool const
TRciControl::GetResetPulseRcvd
   (
   )
{

   const bool TpMapExtResetPulseRcvd  = TpMapInterface->ExtResetPulseRcvd;

   return( TpMapExtResetPulseRcvd );
}

int const
TRciControl::GetIntCount
   (
   ) const
{
   return( ( TpMapInterface_ != NULL ) ? TpMapInterface_->IntCount : 0 );
}

int const
TRciControl::GetPPSCount
   (
   ) const
{
   return( ( TpMapInterface_ != NULL ) ? TpMapInterface_->PPSCount : 0 );
}

void
TRciControl::CancelExtResetPulse
   (
   )
{

   TpMapInterface->ArmExtResetPulse = false;
   SimMode                          = eSimIdle;
   CodeSite->SendMsg( "Cancel Wait For Reset Pulse" );

}




void
TRciControl::WaitDebugProcessing
   (
   const int WaitResult
   )
{
#if(0)
   if ( WaitResult == WAIT_TIMEOUT )
   {
      CodeSite->WriteInteger( "TInterface::WaitTimeout", ++WaitTimeout );
   }
   else if ( ( WaitResult >= WAIT_ABANDONED_0 ) && ( WaitResult <= ( WAIT_ABANDONED_0 + 3 - 1 ) ) )
   {
      CodeSite->WriteInteger( "TInterface::WaitAbandoned", ++WaitAbandoned );
      AnsiString Str;
      Str.sprintf( "TInterface::WaitAbandoned.  WaitResult = %d, AbandonedIndex = %d", WaitResult, WaitResult - WAIT_ABANDONED_0 );
      CodeSite->SendMsg( Str );
   }
   else if ( ( WaitResult >= WAIT_OBJECT_0 ) && ( WaitResult <= ( WAIT_OBJECT_0 + 3 - 1 ) ) )
   {

      const int WaitIndex = WaitResult - WAIT_OBJECT_0;
      if ( WaitIndex == 0 ) ++WaitTimer;
      if ( WaitIndex == 1 ) ++WaitSendEvent;
      if ( WaitIndex == 2 ) ++WaitReceiveEvent;

      if ( ( WaitDebugProcessingCount % 10 ) == 0 )
      {
         if ( WaitIndex == 0 )
         {
            CodeSite->WriteInteger( "TInterface::WaitTimer", WaitTimer );
         }
         else if ( WaitIndex == 1 )
         {
            CodeSite->WriteInteger( "TInterface::WaitSendEvent", WaitSendEvent );
         }
         else if ( WaitIndex == 2 )
         {
            CodeSite->WriteInteger( "TInterface::WaitReceiveEvent", WaitReceiveEvent );
         }
      }

   }

   if ( ++WaitDebugProcessingCount > WAIT_DEBUG_PROCESSING_MIN )
   {
      MinExecuteIntervalms = std::min( ExecuteInterval.TimeIntervalms, MinExecuteIntervalms );
      MaxExecuteIntervalms = std::max( ExecuteInterval.TimeIntervalms, MaxExecuteIntervalms );
   }
   if ( ( WaitDebugProcessingCount % 10 ) == 0 )
   {
      CodeSite->WriteFloat( "TInterface::ExecuteMinms", MinExecuteIntervalms );
      CodeSite->WriteFloat( "TInterface::ExecuteMaxms", MaxExecuteIntervalms );
      ExecuteInterval.Reportms( "TInterfaceExecutems" );
   }
   ExecuteInterval.ResetStart();
#endif
}

