#ifndef InterfaceStatusFrameH
#define InterfaceStatusFrameH

//---------------------------------------------------------------------------
//
// $Workfile:: InterfaceStatusFrame.h                                $
//
// $Revision:: 1                                                     $
//
// $History:: InterfaceStatusFrame.h                                 $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 3:25p
//Created in $/TapRci
//Initial checkin.
//
//
//---------------------------------------------------------------------------

__interface IInterfaceStatusFrame {
protected:

   virtual TFrame          * GetFrame() const                       = 0;
   virtual AnsiString const  GetTitle() const                       = 0;
   virtual void              SetTitle( const AnsiString & )         = 0;


public:

   virtual void UpdateDisplay()                                     = 0;

   __property TFrame *     Frame       = { read = GetFrame                       };
   __property AnsiString   Title       = { read = GetTitle,   write = SetTitle   };          

};

#endif

 