#ifndef PchH
#define PchH

//---------------------------------------------------------------------------
//
// $Workfile:: pch.h                                                 $
//
// $Revision:: 4                                                     $
//
// $History:: pch.h                                                  $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 4:40p
//Updated in $/TapRci
//Add more includes.
//Remove Abakus.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:24p
//Updated in $/TapRci
//Add Raize 3 components.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:47p
//Updated in $/TapRci
//Added various includes.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/29/02    Time: 9:14a
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------

// VCL
//
#include <vcl.h>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include <ImgList.hpp>
#include <inifiles.hpp>
#include <Buttons.hpp>
#include <syncobjs.hpp>
#include <system.hpp>
#include <ScktComp.hpp>
#include <Sockets.hpp>
#include <ActnList.hpp>
#include <ActnMan.hpp>


// TeeChart
//
#include <Chart.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include <Series.hpp>
#define BUILDERINCLUDES

#include <fstream>
#include <iostream>

#include <vector>
#include <set>
#include <map>
#include <string>
#include <queue>
#include <strstream>
#include <iomanip>
#include <dstring.h>
#include <cstring.h>
#include <math.h>
#include <valarray>

#include <stdio.h>
#include <dir.h>
#include <syncobjs.hpp>
#include <system.hpp>

// Raize
//
#include "RzPanel.hpp"
#include "RzSplit.hpp"
#include "RzSpnEdt.hpp"
#include "RzStatus.hpp"
#include "RzLstBox.hpp"
#include "RzChkLst.hpp"
#include "RzAnimtr.hpp"
#include "RzButton.hpp"
#include "RzLabel.hpp"
#include "RzBorder.hpp"
#include "RzRadGrp.hpp"
#include "RzDlgBtn.hpp"
#include "RzCmboBx.hpp"
#include "RzTabs.hpp"
#include "RzBckgnd.hpp"
#include "RzTray.hpp"


// Raize Codesite
//
#include "CsIntf.hpp"

// Turbopower
//
#include "StBase.hpp"
#include "StShlCtl.hpp"
#include "SsBase.hpp"
#include "StBrowsr.hpp"
#include "StUtils.hpp"
#include "StSystem.hpp"
#include "StVInfo.hpp"
#include "ststrl.hpp"
#include "ovcbase.hpp"
#include "OvcLabel.hpp"
#include "ovcdrpvw.hpp"
#include "ovcrptvw.hpp"
#include "ovcrvidx.hpp"
#include "ovcspeed.hpp"
#include "ovcef.hpp"
#include "ovcpb.hpp"
#include "ovcpf.hpp"
#include "ovcnf.hpp"
#include "o32flxbn.hpp"

#endif

