#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//
// $Workfile:: ComPortInterface.cpp                                  $
//
// $Revision:: 2                                                     $
//
// $History:: ComPortInterface.cpp                                   $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//
//
//---------------------------------------------------------------------------

#ifndef ComPortInterfaceH
#include "ComPortInterface.h"
#endif

//---------------------------------------------------------------------------

#pragma package(smart_init)


TComPortInterface::TComPortInterface
   (
   TComponent              * InOwner
   ) :
   PortDisp_( NULL ),
   Valid_( false )
{

   CodeSite->EnterMethod( "TComPortInterface::TComPortInterface" );

   TapRciPf_               = new TTapRciProfile();

   Valid_                  = OpenComPort();

   ComPortInterfaceFrame_  = new TComPortInterfaceStatusFrame( InOwner, *PortDisp_, this );
   InterfaceStatusFrame      = dynamic_cast<IInterfaceStatusFrame *>( ComPortInterfaceFrame_ );

   CodeSite->ExitMethod( "TComPortInterface::TComPortInterface" );
}

__fastcall
TComPortInterface::~TComPortInterface
   (
   )
{

   delete PortDisp_;

}

bool const
TComPortInterface::OpenComPort
   (
   )
{

   bool ValidComPort       = false;

   COMMTIMEOUTS Timeout;


   Port_                     = TapRciPf_->SerialComPort;
   Baud_                     = TapRciPf_->SerialBaud;
   StopBits_                 = TapRciPf_->SerialStopBits;
   Parity_                   = TapRciPf_->SerialParity;
   DataBits_                 = TapRciPf_->SerialDataBits;
   HWFlow_                   = TapRciPf_->SerialHWFlow;
   SWFlow_                   = TapRciPf_->SerialSWFlow;

   PortDisp_                 = new TPortDisp( Port_, Baud_, StopBits_, DataBits_, Parity_, HWFlow_, SWFlow_ );

   // Write params back out

   TapRciPf_->SerialComPort  = Port_;
   TapRciPf_->SerialBaud     = Baud_;
   TapRciPf_->SerialStopBits = StopBits_;
   TapRciPf_->SerialParity   = Parity_;
   TapRciPf_->SerialDataBits = DataBits_;
   TapRciPf_->SerialHWFlow   = HWFlow_;
   TapRciPf_->SerialSWFlow   = SWFlow_;


   SECURITY_ATTRIBUTES Security; // Security data for comm
   DCB dcb;                      // Device control block for comm
   char ComStr[6];

   Security.nLength              = sizeof( SECURITY_ATTRIBUTES );
   Security.lpSecurityDescriptor = NULL;
   Security.bInheritHandle       = FALSE;  // Don't let chid threads access

   sprintf( ComStr,"COM%1d", Port_ );
   ComHandle = CreateFile
      (
      ComStr,
      GENERIC_READ | GENERIC_WRITE,
      0,
      &Security,
      OPEN_EXISTING,
      FILE_ATTRIBUTE_NORMAL,
      NULL
      );

   if ( ComHandle != INVALID_HANDLE_VALUE )
   {
      if ( GetCommState(ComHandle,&dcb) )
      {
         dcb.BaudRate                              = Baud_;
         dcb.Parity                                = Parity_;
         dcb.StopBits                              = StopBits_;
         dcb.ByteSize                              = DataBits_;
         dcb.fOutX                                 = 0;
         dcb.fInX                                  = 0;
         if ( HWFlow_ )
         {
            dcb.fOutxCtsFlow                       = 1; // CTS output flow control
            dcb.fOutxDsrFlow                       = 1; // DSR output flow control
         }
         else
         {
            dcb.fOutxCtsFlow                       = 0; // CTS output flow control
            dcb.fOutxDsrFlow                       = 0; // DSR output flow control
         }
         if ( SetCommState( ComHandle, &dcb ) )
         {
            if ( GetCommTimeouts( ComHandle, &Timeout ) )
            {
               Timeout.ReadIntervalTimeout         = MAXDWORD;
               Timeout.ReadTotalTimeoutMultiplier  = MAXDWORD;
               Timeout.ReadTotalTimeoutConstant    = 100;
               Timeout.WriteTotalTimeoutMultiplier = 500;
               Timeout.WriteTotalTimeoutConstant   = 500;
               if ( SetCommTimeouts( ComHandle, &Timeout ) )
               {
                  ValidComPort                     = true;
               }
            }
         }
      }
   }


   return( ValidComPort );
}

bool const
TComPortInterface::SendMsg
   (
   const TMsgData          & MsgData
   )
{

   DWORD NumWritten = 0;

   WriteFile( ComHandle, &MsgData[0], (DWORD) MsgData.size(), &NumWritten, NULL );

   BytesXmtd_              += NumWritten;

   return( NumWritten != MsgData.size() );

}

void
TComPortInterface::ReadMsg
   (
   TMsgData               & MsgData
   )
{
//Sleep( 100 );
//return;
   unsigned char            Byte;
   DWORD                    BytesRead;

   do
   {
      ReadFile( ComHandle, &Byte, 1, &BytesRead, NULL );

      BytesRcvd_           += BytesRead;

      if ( BytesRead )
      {
         MsgData.push_back( Byte );
      }
   }
   while( BytesRead != 0 );

}


