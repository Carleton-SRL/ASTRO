#ifndef TpMapH
#define TpMapH

//---------------------------------------------------------------------------
//
// $Workfile:: tpmap.h                                               $
//
// $Revision:: 3                                                     $
//
// $History:: tpmap.h                                                $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:32p
//Updated in $/TapRci
//Add Cancel Ext Reset.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 2/01/03    Time: 3:35p
//Updated in $/TapRci
//Copied TpMap.h from TapMsec.
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------


// This is the memory map for the simulator
//


#pragma pack(push,1)

#define NUM_MAP_CHANS  (61)
#define TP_MAX_ATTEN_HEX   (0x3f)
#define TP_MAX_ATTEN_DB    (36.2)
#define TP_MAX_RF_ATTEN1   ( 15 )
#define TP_MAX_RF_ATTEN2   ( 15 )
#define MAX_RF_GAIN ( 29 )

#define MAX_RFS            ( 12 )

typedef struct tagHW_DOPREC {
   long           L1CarDoppler;        // 1, 2, 3, 4
   long           L1CarDopRate;        // 5, 6, 7, 8
   short          L1CarDopAcc;         // 9, 10
   short          L1PadCarDopAcc;      // 11, 12
   long           L1CodeDoppler;       // 13, 14, 15, 16
   long           L1CodeDopRate;       // 17, 18, 19, 20
   short          L1CodeDopAcc;        // 21, 22
   unsigned char  L1ClearAccum;        // 23
   unsigned char  L1CodeDither;        // 24
   unsigned short L1Atten;             // 25, 26
   unsigned char  L1NavBits1;          // 27
   unsigned char  L1NavBits2;          // 28
   unsigned char  L1NavBitsReqAck;     // 29
   long           L2CarDoppler;        // 30, 31, 32, 33
   long           L2CarDopRate;        // 34, 35, 36, 37
   short          L2CarDopAcc;         // 38, 39
   short          PadCarDopAcc;        // 40, 41
   long           L2CodeDoppler;       // 42, 43, 44, 45
   long           L2CodeDopRate;       // 46, 47, 48, 49
   short          L2CodeDopAcc;        // 50, 51
   unsigned char  L2ClearAccum;        // 52
   unsigned char  L2CodeDither;        // 53
   unsigned short L2Atten;             // 54, 55
   unsigned char  L2NavBits1;          // 56
   unsigned char  L2NavBits2;          // 57
   unsigned char  L2NavBitsReqAck;     // 58
} HW_DOPREC;

typedef struct tagCODECTRL {
   unsigned char CACodeEnabled   : 1;
   unsigned char PCodeEnabled    : 1;
   unsigned char NavBitsEnabled  : 1;
   unsigned char CarEnabled      : 1;
   unsigned char WaasEnabled     : 1;
} CODECTRL;

typedef struct tagHW_CTLREC {
   unsigned char  Svid;                   // 59
   unsigned char  BitPos;                 // 60
   unsigned char  PadCtl1[5];             // 61, 62, 63, 64, 65
   unsigned short X1AEpochs;              // 66, 67
   unsigned short ChipsIntoX1A;           // 68, 69
   unsigned short X1BEpochs;              // 70, 71
   unsigned short ChipsIntoX1B;           // 72, 73
   unsigned short X2AEpochs;              // 74, 75
   unsigned short ChipsIntoX2A;           // 76, 77
   unsigned short X2BEpochs;              // 78, 79
   unsigned short ChipsIntoX2B;           // 80, 81
   unsigned short CAChipDelay;            // 82, 83
   unsigned char  NumPChipsToCAStart;     // 84
   unsigned short CACodePreset;           // 85, 86
   CODECTRL       L1CodeCtrl;             // 87
   CODECTRL       L2CodeCtrl;             // 88
   unsigned long  ZCount;                 // 89, 90, 91, 92
} HW_CTLREC;

typedef struct tagHW_FEEDBACK {
   unsigned char ReadPad[4];              // 100, 101, 102, 103
   unsigned char BitReq;                  // 104
   unsigned long L1CodeDop;               // 105, 106, 107, 108
   unsigned long L1CodeNco;               // 109, 110, 111, 112
   unsigned short CodeCounts;             // 113, 114
} HW_FEEDBACK;

typedef struct tagHW_PULSECTL {
   unsigned char         PulseDelay;      // 115
   unsigned short        PulseWidth;      // 116, 117
   unsigned short        PulseHiWidth;    // 118, 119
} HW_PULSECTL;



#define SIZE_SEG   (0x80)

//#define PADCHANMAP3 ( SIZE_SEG - \\
//   ( 5*sizeof(char) + sizeof(HW_DOPREC) + sizeof(HW_CTLREC) + sizeof(HW_FEEDBACK) + sizeof(char) + sizeof(short) ) )

#define PADCHANMAP3 ( SIZE_SEG - \
   ( \
   sizeof(char) +        \
   sizeof(HW_DOPREC) +   \
   sizeof(HW_CTLREC) +   \
   sizeof(char) +        \
   sizeof(short) +       \
   sizeof(char)*4 +      \
   sizeof(HW_FEEDBACK) + \
   sizeof(HW_PULSECTL)   \
   ) )

typedef struct tagCHANMAP {
   unsigned char       PadChanMap;               // 0
   HW_DOPREC           Dop;                      // 1 - 58
   HW_CTLREC           Ctl;                      // 59 - 92
   unsigned char       ClearChannel;             // 93
   unsigned short      StartChannel;             // 94, 95
   unsigned char       DopIntegrationUsed;       // 96 (units are 2ms.  Intcount when value used.  For 10Hz, this number is 49)
   unsigned char       DopIntegrationClocked;    // 97 (units are 2ms.  Intcount when new values clocked in.  Always 1 less than DopIntegrationUsed.  For 10Hz, this number is 48)
   unsigned char       PadChanMap1[2];           // 98, 99
   HW_FEEDBACK         Feedback;                 // 100 - 114
   HW_PULSECTL         PulseCtl;                 // 115 - 120
   unsigned char       PadChanMap3[PADCHANMAP3];
} CHANMAP;

#define TPMAP_ENABLE_RESET_ON_NEXT_PULSE     ( 0x01 )
#define TPMAP_DISABLE_RESET_ON_NEXT_PULSE    ( 0x03 )

typedef struct tagBOARDCTL {
   unsigned char     ResetOnNext1PPS;     // 0
   unsigned short    InterruptCount;      // 1, 2
   unsigned char     PPSDelay;            // 3
   unsigned char     PPSWidth;            // 4
   unsigned char     Gpio;                // 5
   unsigned char     Reserved;            // 6 clear interrupt for device driver
   unsigned char     IntEnable;           // 7 Interrupt Enable
   unsigned char     ResetCounters;       // 8 Clear 500Hz and 1 PPS counters
   unsigned char     Pad[SIZE_SEG - 7*sizeof(unsigned char) - sizeof(unsigned short)];
} BOARDCTL;

typedef struct tagRFCTL {
   unsigned char     RFAtten1;
   unsigned char     RFAtten2;
   unsigned char     PllCtl;
   unsigned char     ExtOscEnable;
   unsigned char     Pad[13];
   unsigned char     CancelExtReset;       // Byte 17 = 0x11 (from 0) Once armed, this is only method to awaken hw without an external pulse.
} RFCTL;

typedef struct tagRFCTLALL {
   RFCTL             RfCtl[MAX_RFS];
   unsigned char     Pad[SIZE_SEG - MAX_RFS*sizeof(RFCTL)];
} RFCTLALL;


typedef struct tagBOARDPROG {
   unsigned char     XlnxCtl;
   unsigned char     XlnxProg;
   unsigned char     PadBoardProg1[62];
   unsigned char     X1ProgStatus;
   unsigned char     X2ProgStatus;
   unsigned char     X3ProgStatus;
   unsigned char     Pad[SIZE_SEG - 5*sizeof(unsigned char) - 62*sizeof(unsigned char)];
} BOARDPROG;

typedef struct tagTPMAP {

   CHANMAP            ChanData[NUM_MAP_CHANS];
   BOARDCTL           BoardCtl;
   RFCTLALL           RfCtlAll;
   BOARDPROG          BoardProg;

} TPMAP;

#define MAX_PPS_COUNT ( 127 )


#pragma pack(pop)

#endif

