//---------------------------------------------------------------------------

#ifndef EthernetH
#define EthernetH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: Ethernet.h                                            $
//
// $Revision:: 2                                                     $
//
// $History:: Ethernet.h                                             $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:30p
//Updated in $/TapRci
//Initial release.
//
//
//---------------------------------------------------------------------------


#ifndef InterfaceH
#include "Interface.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef EthernetInterfaceStatusFramH
#include "EthernetInterfaceStatusFram.h"
#endif


//---------------------------------------------------------------------------
class TEthernetClient : public TInterface  {
private:

   TEthernetInterfaceStatusFrame       * EthernetStatusFrame;
   TTapRciProfile                      * TapRciPf;
   TClientSocket                       * ClientSocket;
   TWinSocketStream                    * WinSocketStream;
   int                                   PortNum_;
   AnsiString                            HostAddr_;
   TComponent                          * Owner;

   bool const                            GetActive() const;

   bool                                  ValidInterface_;
   bool const                            GetValidInterface() const { return( ValidInterface_ ); }

protected:

   bool const                SendMsg( const TMsgData &MsgData );
   void                      ReadMsg( TMsgData &MsgData );

public:

   TEthernetClient( TComponent * InOwner );
   virtual __fastcall ~TEthernetClient();

   __property int            PortNum         = { read = PortNum_,   write = PortNum_  };
   __property AnsiString     HostAddr        = { read = HostAddr_,  write = HostAddr_ };
   __property bool           Active          = { read = GetActive                     };

};

//---------------------------------------------------------------------------

class TEthernetServerClientThread : public TServerClientThread {
private:

   TServerClientWinSocket      * ServerClientWinSocket;
   TWinSocketStream            * WinSocketStream;
   bool                          ActiveClient_;
   TMsgData                      QueuedOutMsgData;
   TMsgData                      QueuedInMsgData;

protected:

   void __fastcall               ClientExecute();
   bool const                    WriteQueuedMsgData();
   bool const                    ReadMsgData( TMsgData & );
   bool const                    SendMsgData( const TMsgData & );
   void                          AddInMsgDataQueue( TMsgData & );
   void                          SendInactiveClientMsg();
   void                          SetActiveClient( const bool InActiveClient ) { ActiveClient_ = InActiveClient; }
   bool const                    GetActiveClient() const { return( ActiveClient_ ); }

   static TCriticalSection     * ReadCriticalSection;
   static TCriticalSection     * WriteCriticalSection;
   static bool                   CriticalSectionInitialized;

public:

   TEthernetServerClientThread( TServerClientWinSocket * ServerClientWinSocket );
   virtual __fastcall ~TEthernetServerClientThread();

   bool const                QueueMsgData( const TMsgData & Msg );
   bool const                GetMsgData( TMsgData & Msg );

   __property bool       ActiveClient     = { read = GetActiveClient,    write = SetActiveClient       };



};

typedef vector<TEthernetServerClientThread *> TEthernetServerClientThreadArray;

//---------------------------------------------------------------------------

class TEthernetServer : public TInterface {
private:

   TTapRciProfile                      * TapRciPf;
   TServerSocket                       * ServerSocket;
   TEthernetServerClientThread         * ActiveClientThread;
   TEthernetServerClientThreadArray      ClientThreadArray;
   TEthernetInterfaceStatusFrame       * EthernetStatusFrame;
   TComponent                          * Owner;
   int                                   PortNum_;
   bool                                  ValidInterface_;

   bool const                            GetActiveClient() const { return( ActiveClientThread != NULL ); }
   bool const                            GetValidInterface() const { return( ValidInterface_ ); }

   void __fastcall GetThread
      (
      TObject                  *   Sender,
      TServerClientWinSocket   *   ClientSocket,
      TServerClientThread      * & SocketThread
      );

   void __fastcall ThreadEnd
      (
      TObject                  * Sender,
      TServerClientThread      * Thread
      );

   void __fastcall ClientDisconnect
      (
      TObject                  * Sender,
      TCustomWinSocket         * Socket
      );

protected:

   bool const                SendMsg( const TMsgData &MsgData );
   void                      ReadMsg( TMsgData &MsgData );

public:

   TEthernetServer( TComponent * Owner );
   virtual __fastcall ~TEthernetServer();

   __property bool           ActiveClient    = { read = GetActiveClient              };
   __property int            PortNum         = { read = PortNum_,   write = PortNum_ };

};


#endif
