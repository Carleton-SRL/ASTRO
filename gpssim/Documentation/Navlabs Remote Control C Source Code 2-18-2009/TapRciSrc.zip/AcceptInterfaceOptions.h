#ifndef AcceptInterfaceOptionsH
#define AcceptInterfaceOptionsH

//---------------------------------------------------------------------------
//
// $Workfile:: AcceptInterfaceOptions.h                              $
//
// $Revision:: 2                                                     $
//
// $History:: AcceptInterfaceOptions.h                               $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 9:48p
//Updated in $/TapRci
//Add GetOptionsChanged to virtual functions of interface
//IAcceptInterfaceOptions.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/29/02    Time: 9:34p
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------


__interface IAcceptInterfaceOptions {

public:

   virtual void              DoNewOptions( const bool Accept )             = 0;
   virtual bool const        GetOptionsChanged()                           = 0;

   __property bool           OptionsChanged    = { read = GetOptionsChanged         };

};


#endif
