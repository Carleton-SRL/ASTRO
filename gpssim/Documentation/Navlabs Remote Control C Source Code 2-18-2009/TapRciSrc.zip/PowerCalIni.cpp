#include "pch.h"
#pragma hdrstop
//---------------------------------------------------------------------------
// ClassExplorer Pro generated source file
// Created by Michael Wade on 2/12/2002, 7:42:34 PM
//---------------------------------------------------------------------------
#include "PowerCalIni.h"
#include "VoyDefPf.h"
//---------------------------------------------------------------------------
// Sections
//
static const AnsiString PowerSection( "POWER" );
static const AnsiString L1MaxPowerKey( "L1MaxPowerdBm" );
static const AnsiString L1MaxPowerStrDef( "-80.0" );

static const AnsiString L2MaxPowerKey( "L2MaxPowerdBm" );
static const AnsiString L2MaxPowerStrDef( "-80.0" );

static const AnsiString ExtAttenKey( "ExtAttendB" );
static const AnsiString ExtAttenStrDef( "30" );




//---------------------------------------------------------------------------

static AnsiString const
GetPowerCalIniDir()
{
   VoyDefProfile *Vdp = new VoyDefProfile();
   AnsiString RunsDir = Vdp->GetRunsDir();
   delete Vdp;
   return( RunsDir );
}
static const AnsiString PowerCalIniFileName("\\PowerCal.ini");

TPowerCalIni::TPowerCalIni
   (

   ) :
   TIniFile( GetPowerCalIniDir() + PowerCalIniFileName )
{
}


void
TPowerCalIni::SetL1MaxPower
   (
   const double L1MaxPowerdBm
   )
{
   AnsiString L1MaxPowerStr = FloatToStrF
      (
         L1MaxPowerdBm,
         ffFixed,
         6,
         2
      );
   WriteString( PowerSection, L1MaxPowerKey, L1MaxPowerStr );
}

void
TPowerCalIni::SetL2MaxPower
   (
   const double L2MaxPowerdBm
   )
{
   AnsiString L2MaxPowerStr = FloatToStrF
      (
         L2MaxPowerdBm,
         ffFixed,
         6,
         2
      );
   WriteString( PowerSection, L2MaxPowerKey, L2MaxPowerStr );
}


void
TPowerCalIni::SetExtAtten
   (
   const double ExtAttendB
   )
{
   AnsiString ExtAttenStr = FloatToStrF
      (
         ExtAttendB,
         ffFixed,
         6,
         2
      );
   WriteString( PowerSection, ExtAttenKey, ExtAttenStr );

}

double const
TPowerCalIni::GetExtAtten
   (

   )
{

   AnsiString ExtAttenStr = ReadString( PowerSection, ExtAttenKey, ExtAttenStrDef );

   return( ExtAttenStr.ToDouble() );

}

double const
TPowerCalIni::GetL1MaxPower
   (

   )
{

   AnsiString L1MaxPowerStr = ReadString( PowerSection, L1MaxPowerKey, L1MaxPowerStrDef );

   return( L1MaxPowerStr.ToDouble() );

}

double const
TPowerCalIni::GetL2MaxPower
   (
   
   )
{

   AnsiString L2MaxPowerStr = ReadString( PowerSection, L2MaxPowerKey, L2MaxPowerStrDef );

   return( L2MaxPowerStr.ToDouble() );

}

