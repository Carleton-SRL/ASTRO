//---------------------------------------------------------------------------

#ifndef DebugUtilsH
#define DebugUtilsH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: DebugUtils.h                                          $
//
// $Revision:: 1                                                     $
//
// $History:: DebugUtils.h                                           $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 3:39p
//Created in $/TapRci
//Initial checkin.
//
//
//---------------------------------------------------------------------------


// This is only for debug.  The namespace DebugUtils contains classes, global data
// static data used for debugging only
//
namespace DebugUtils {
   extern bool               DebugUtilsEnabled;

class TTimeInterval {
private:

   LARGE_INTEGER             StartCount_;
   double                    Frequency_;

   void                      Init();
   double const              GetTimeInterval() const;
   double const              GetTimeIntervalms() const;

public:
   TTimeInterval();

   void                      ResetStart();
   void                      Reportms( const AnsiString & CodeSiteLineId )
   {
      if ( !DebugUtilsEnabled ) return;
      CodeSite->WriteFloat( CodeSiteLineId, TimeIntervalms );
   }
   void                      Report( const AnsiString & CodeSiteLineId )
   {
      if ( !DebugUtilsEnabled ) return;
      CodeSite->WriteFloat( CodeSiteLineId, TimeInterval );
   }


   __property double TimeInterval   = { read = GetTimeInterval              };
   __property double TimeIntervalms = { read = GetTimeIntervalms            };
   __property double Frequency      = { read = Frequency_                   };

};

class TSequence {
private:

   AnsiString                IdentStr_;
   int                       SequenceNumber_;

public:

   TSequence( const AnsiString & InIdentStr ) : SequenceNumber_( -1 ), IdentStr_( InIdentStr ) {}

   void Report
      (
      const AnsiString     & Str
      )
   {
      if ( !DebugUtilsEnabled ) return;
      CodeSite->SendMsg( AnsiString( ++SequenceNumber_ ) + AnsiString( " : " ) + IdentStr_ + Str );
   }

};

}; // End namespace


#endif
