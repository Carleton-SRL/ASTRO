#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: MsgListFram.cpp                                       $
//
// $Revision:: 4                                                     $
//
// $History:: MsgListFram.cpp                                        $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:21p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:21p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:44p
//Updated in $/TapRci
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------


#ifndef MsgListFramH
#include "MsgListFram.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "RzLabel"
#pragma link "RzLstBox"
#pragma link "RzPanel"
#pragma link "RzStatus"
#pragma resource "*.dfm"
TMsgListFrame *MsgListFrame;
//---------------------------------------------------------------------------


__fastcall
TMsgListFrame::TMsgListFrame
   (
   TComponent              * Owner
   ) :
   TFrame( Owner )
{
}
//---------------------------------------------------------------------------
