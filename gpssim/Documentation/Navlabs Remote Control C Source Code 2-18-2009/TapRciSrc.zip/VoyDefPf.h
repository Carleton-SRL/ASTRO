#ifndef VoyDefPfH
#define VoyDefPfH

//---------------------------------------------------------------------------
//
// $Workfile:: VoyDefPf.h                                            $
//
// $Revision:: 3                                                     $
//
// $History:: VoyDefPf.h                                             $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:34p
//Updated in $/TapRci
//Update from TapMsec.
//
//
//---------------------------------------------------------------------------



class TVoyDefProfile : public TIniFile {
private:

   bool const                IsIntEnabled();

public:
   enum OrbDriverType { Orb16=16, Orb8=8, GsIsa=17, GsPci=18 };
   static const int          Orb8Bit = 1;
   static const int          Orb16Bit = 2;

   TVoyDefProfile();
    _fastcall virtual ~TVoyDefProfile();

   void                      GetRunsDir( char *RunRoot );
   AnsiString const          GetRunsDir();
   void                      GetHostAddr( char *HostAddr );
   AnsiString                GetHostAddr();
   bool const                GetDoCodeCalibration();
   bool const                GetDoRTCalibration();
   bool const                GetDoCarrierCalibration();
   bool const                GetShowCal();
   int  const                GetTruthTimeDelay();
   int  const                GetDisplayUpdateInterval();
   int  const                GetScramnetOffset();
   int  const                GetInterChassisBias( int ChassisNum );
   bool const                IsRemote();
   bool const                IsMcAnal05();
   bool const                IsTestMode();
   OrbDriverType const       GetDriverType();
   bool const                IsGroundTrackEnabled();
   bool const                IsPlotEnabled();
   bool const                IsDebugDisp();
   int const                 GetLLTestNumChans();
   bool const                IsDispRelativePower();
   bool const                IsL2Capable();

   __property bool           L2Capable        = { read = IsL2Capable                          };
   __property AnsiString     HostAddr         = { read = GetHostAddr                          };
   __property bool           TestMode         = { read = IsTestMode                           };
   __property bool           IntEnabled       = { read = IsIntEnabled                         };

};

typedef TVoyDefProfile VoyDefProfile;

#endif


