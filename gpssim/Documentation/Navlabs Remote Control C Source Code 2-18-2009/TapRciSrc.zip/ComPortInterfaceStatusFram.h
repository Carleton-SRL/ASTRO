//---------------------------------------------------------------------------


#ifndef ComPortInterfaceStatusFramH
#define ComPortInterfaceStatusFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: ComPortInterfaceStatusFram.h                          $
//
// $Revision:: 2                                                     $
//
// $History:: ComPortInterfaceStatusFram.h                           $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/24/04    Time: 8:21a
//Created in $/TapRci
//Initial development.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "RzLabel.hpp"
#include "RzPanel.hpp"
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include "RzSplit.hpp"
#include "RzStatus.hpp"
#include <ImgList.hpp>
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------


//---------------------------------------------------------------------------

#ifndef InterfaceStatusFrameH
#include "InterfaceStatusFrame.h"
#endif

#ifndef PortDispH
#include "PortDisp.h"
#endif



class TComPortInterface;

class TComPortInterfaceStatusFrame : public TFrame, public IInterfaceStatusFrame
{
__published:
   TImage *ComPortmage;
   TRzSizePanel *ComPortConfigSizePnl;
   TRzPanel *ConfigPnl;
   TRzLabel *SerialPortLbl;
   TRzLabel *BaudLbl;
   TRzLabel *ParityLbl;
   TRzLabel *DataBitsLbl;
   TRzLabel *StopBitsLbl;
   TRzLabel *HWFlowLbl;
   TRzLabel *SWFlowLbl;
   TRzLabel *SerialPortVal;
   TRzLabel *BaudVal;
   TRzLabel *ParityVal;
   TRzLabel *DataBitsVal;
   TRzLabel *StopBitsVal;
   TRzLabel *HWFlowVal;
   TRzLabel *SWFlowVal;
   TRzPanel *ComPortMainPnl;
   TRzStatusPane *BytesRcvdTxt;
   TImage *XmtImage;
   TImage *RcvImage;
   TRzStatusPane *BytesXmtdTxt;
   TImageList *XmtImageList;
   TImageList *RcvImageList;
   TTimer *ComPortTimer;
   void __fastcall ComPortTimerTimer(TObject *Sender);
private:

   TPortDisp                 PortDisp_;
   int                       PrevBytesRcvd_;
   int                       PrevBytesXmtd_;
   int                       RcvdWindowIndex_;
   int                       XmtdWindowIndex_;
   int                       PortNum_;
   bool                      ExecuteRcvd_;
   bool                      ExecuteXmtd_;
   bool                      InTimer_;
   AnsiString                Title_;
   TComPortInterface       * ComPortInterface_;

   void                      InitDisplay();

   TFrame                  * GetFrame() const { return( (TFrame *) this ); }
   AnsiString const          GetTitle() const { return( Title_ ); }
   void                      SetTitle( const AnsiString & InTitle ) { Title_ = InTitle; }


public:

   __fastcall TComPortInterfaceStatusFrame( TComponent * Owner, const TPortDisp &, TComPortInterface * );

   void                      UpdateDisplay();

};
//---------------------------------------------------------------------------
extern PACKAGE TComPortInterfaceStatusFrame *ComPortInterfaceStatusFrame;
//---------------------------------------------------------------------------
#endif
