#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: InterruptCheck.cpp                                    $
//
// $Revision:: 4                                                     $
//
// $History:: InterruptCheck.cpp                                     $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:24p
//Updated in $/TapRci
//Add External Pulse Reset.  New TpMapInt has props.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:27p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//
//---------------------------------------------------------------------------


#ifndef InterruptCheckH
#include "InterruptCheck.h"
#endif

#ifndef ThreadInfH
#include "ThreadInf.h"
#endif



#pragma package(smart_init)


__fastcall
TInterruptCheck::TInterruptCheck
   (
   TTpMapInterface         * InTpMapInterface
   ) :
   TThread( true ),
   TpMapInterface( InTpMapInterface ),
   IntCount( 0 )
{

   TestMode                = TpMapInterface->TestMode;

   Valid                   = TpMapInterface->Valid;

}

void __fastcall TInterruptCheck::Execute()
{

   TThreadInf TThreadInf( "InterfaceThread" );


   if ( TestMode )
   {
      IntCount = 10;
      return;
   }


   for ( int i=0; i<4; ++i )
   {

      TpMapInterface->WaitForInt();
      ++IntCount;

   }

}


