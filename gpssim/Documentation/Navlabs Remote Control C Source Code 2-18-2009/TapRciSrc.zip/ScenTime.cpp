#include "pch.h"
#pragma hdrstop

#include "ScenTime.h"

long    TScenTime::TimeMillisec(0);
GPSTime TScenTime::StartTime;
GPSTime TScenTime::EndTime;
bool    TScenTime::InitializedFl(false);
bool    TScenTime::InitializedRt(false);

