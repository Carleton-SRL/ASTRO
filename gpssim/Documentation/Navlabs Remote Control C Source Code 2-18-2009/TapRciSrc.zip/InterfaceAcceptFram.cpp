#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: InterfaceAcceptFram.cpp                               $
//
// $Revision:: 3                                                     $
//
// $History:: InterfaceAcceptFram.cpp                                $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:39p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:41p
//Updated in $/TapRci
//Add accept/cancel buttons.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/03/02   Time: 9:14p
//Created in $/RciDriver
//Add ethernet and Monte Carlo trials
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/29/02    Time: 6:54p
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------


#ifndef InterfaceAcceptFramH
#include "InterfaceAcceptFram.h"
#endif


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "RzPanel"
#pragma link "ovclabel"
#pragma link "RzButton"
#pragma resource "*.dfm"
TInterfaceAcceptFrame *InterfaceAcceptFrame;
//---------------------------------------------------------------------------
__fastcall
TInterfaceAcceptFrame::TInterfaceAcceptFrame
   (
   TComponent              * Owner
   ) :
   TFrame( Owner ),
   AcceptInterfaceOptions( NULL )
{
   InterfaceAcceptOptionsTimer->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall
TInterfaceAcceptFrame::AcceptInterfaceBtnClick
   (
   TObject                 * Sender
   )
{

   if ( AcceptInterfaceOptions_ )
   {
      AcceptInterfaceOptions_->DoNewOptions( true );
   }

}
//---------------------------------------------------------------------------
void __fastcall
TInterfaceAcceptFrame::CancelInterfaceBtnClick
   (
   TObject                 * Sender
   )
{

   if ( AcceptInterfaceOptions_ )
   {
      AcceptInterfaceOptions_->DoNewOptions( false );
   }

}
//---------------------------------------------------------------------------
void __fastcall
TInterfaceAcceptFrame::InterfaceAcceptOptionsTimerTimer
   (
   TObject                 * Sender
   )
{
   AcceptInterfaceBtn->Enabled = AcceptInterfaceOptions_ ? AcceptInterfaceOptions_->OptionsChanged : false;
   CancelInterfaceBtn->Enabled = AcceptInterfaceOptions_ ? AcceptInterfaceOptions_->OptionsChanged : false;
}
//---------------------------------------------------------------------------
