#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: ComPortStatusFram.cpp                                 $
//
// $Revision:: 1                                                     $
//
// $History:: ComPortStatusFram.cpp                                  $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/24/04    Time: 8:21a
//Created in $/TapRci
//Initial development.
//
//
//---------------------------------------------------------------------------


#ifndef ComPortStatusFramH
#include "ComPortStatusFram.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "RzLabel"
#pragma link "RzPanel"
#pragma resource "*.dfm"
TComPortStatusFrame *ComPortStatusFrame;
//---------------------------------------------------------------------------
__fastcall
TComPortStatusFrame::TComPortStatusFrame
   (
   TComponent              * Owner
   ) :
   TFrame( Owner )
{
}
//---------------------------------------------------------------------------
