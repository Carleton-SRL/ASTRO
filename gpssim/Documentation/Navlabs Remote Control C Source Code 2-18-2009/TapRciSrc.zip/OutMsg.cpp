#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop


//---------------------------------------------------------------------------
//
// $Workfile:: OutMsg.cpp                                            $
//
// $Revision:: 4                                                     $
//
// $History:: OutMsg.cpp                                             $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:36p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:46p
//Updated in $/TapRci
//Minor cleanup.  
//Add properties.
//
//
//---------------------------------------------------------------------------


#ifndef OutMsgH
#include "OutMsg.h"
#endif

//---------------------------------------------------------------------------



TOutMsg::TOutMsg
   (
   
   )
{ }

unsigned char const
TOutMsg::ComputeChecksum
   (
   const string & Str
   ) const
{
   unsigned char Checksum=0;

   // Checksum after '$' and before '*'
   //
   for ( unsigned long i=Str.find('$')+1; i<( std::min( Str.find('*'), Str.length() ) ); ++i )
   {
      Checksum ^= Str[i];
   }
   return( Checksum );
}

void
TOutMsg::AppendChecksum
   (
   string & Str
   ) const
{
   Str += '*';
   unsigned char Checksum = ComputeChecksum( Str );

   char TmpStr[100];
   sprintf( TmpStr,"%2.2X\r\n", Checksum );
   Str += TmpStr;

}


string const
TOutMsg::GetBody
   (
   )
{
   return( MsgData_ );
}


void
TOutMsg::SetBody
   (
   const string & MsgBody
   )
{

   MsgData_ = MsgBody;
   AppendChecksum( MsgData_ );

}

TMsgData const
TOutMsg::GetMsgData() const
{

   TMsgData OutMsgData;

   for ( unsigned int i=0; i<MsgData_.length(); ++i )
   {
      OutMsgData.push_back( MsgData_[i] );
   }

   return( OutMsgData );

}


