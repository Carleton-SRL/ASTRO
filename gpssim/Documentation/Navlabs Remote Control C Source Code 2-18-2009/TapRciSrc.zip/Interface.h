#ifndef InterfaceH
#define InterfaceH

//---------------------------------------------------------------------------
//
// $Workfile:: Interface.h                                           $
//
// $Revision:: 3                                                     $
//
// $History:: Interface.h                                            $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:39p
//Updated in $/TapRci
//Add multiple wait objects, timer.
//
//
//---------------------------------------------------------------------------


#ifndef RemoteTypesH
#include "RemoteTypes.h"
#endif

#ifndef InMsgH
#include "InMsg.h"
#endif

#ifndef OutMsgH
#include "OutMsg.h"
#endif

#ifndef InterfaceStatusFrameH
#include "InterfaceStatusFrame.h"
#endif

#ifndef ScheduleH
#include "Schedule.h"
#endif



typedef enum { eMSG_SOURCE_SIM, eMSG_SOURCE_CTLR } eMSG_SOURCE;

class TMsgTraffic {
private:

   AnsiString                MsgStr;
   int                       TimeMillisec;
   eMSG_SOURCE               MsgSource;

public:

   TMsgTraffic() : TimeMillisec( 0 ), MsgSource( eMSG_SOURCE_SIM ) {}
   TMsgTraffic( const int InTimeMillisec, const AnsiString &InMsgStr, const eMSG_SOURCE InMsgSource ) :
      TimeMillisec( InTimeMillisec ), MsgStr( InMsgStr ), MsgSource( InMsgSource ) {}

   AnsiString const          GetMsgStr()       const { return( MsgStr );       }
   int const                 GetTimeMillisec() const { return( TimeMillisec ); }
   eMSG_SOURCE const         GetSource()       const { return( MsgSource );    }

};

typedef vector<TMsgTraffic> TMsgTrafficArray;
//---------------------------------------------------------------------------
class TInterface : public TThread {
private:

   TOutMsgQueue              OutMsgQueue;
   TMsgTrafficArray          MsgTrafficArray;
   TInMsg                    InMsg;
   TInMsgArray               InMsgArray;

   TMsgData                  RcvdData;

   int                       NumMsgsSent_;
   int                       NumMsgsRcvd_;
   int                       NumMsgsRcvdExceptStat_;

   HANDLE                    hTimer;

   void                      SetupTimer();
   void                      WaitDebugProcessing( const int WaitResult );

   // Pure virtual implemented by derived classes (TGpib, etc)
   //
   virtual bool const        SendMsg( const TMsgData & Data )        = 0;
   virtual void              ReadMsg( TMsgData & Data )              = 0;
   virtual bool const        GetValidInterface() const               = 0;

   TCriticalSection        * IntCriticalSection;

   static AnsiString         EventReceiveDataName;
   static AnsiString         EventSendDataName;

protected:

   TEvent                  * EventSendData;
   TEvent                  * EventReceiveData;
   TEvent                  * EventReceiveDataRciControl;

   IInterfaceStatusFrame   * InterfaceStatusFrame_;

   bool                      IntError;
   bool const                IsIntError() const { return( IntError ); }
   void                      ClearIntError() { IntError = false; }
   void _fastcall            Execute();
   void                      ProcessReadMsgData( const TMsgData &MsgData );
   void                      ProcessOutputMsg();
   void                      IncNumMsgsRcvd( const TInMsg & );
   int const                 GetNumMsgsSent() const { return( NumMsgsSent ); }
   int const                 GetNumMsgsRcvd() const { return( NumMsgsRcvd ); }
   int const                 GetNumMsgsRcvdExceptStat() const { return( NumMsgsRcvdExceptStat ); }
   int const                 GetOutputQueueSize() const;


public:

   TInterface();
   virtual __fastcall ~TInterface();

   TMsgTrafficArray const    GetMsgTrafficArray();
   void                      QueueMsgs( TOutMsgQueue & OutQueue );
   void                      GetInputMsgs( TInMsgArray &InMsgArray );

   static AnsiString const   GetEventReceiveDataName() { return( EventReceiveDataName ); }


   __property int                     NumMsgsSent              = { read = GetNumMsgsSent                                       };
   __property int                     NumMsgsRcvd              = { read = GetNumMsgsRcvd                                       };
   __property int                     NumMsgsRcvdExceptStat    = { read = GetNumMsgsRcvdExceptStat                             };
   __property int                     OutputQueueSize          = { read = GetOutputQueueSize                                   };
   __property bool                    ValidInterface           = { read = GetValidInterface                                    };
   __property IInterfaceStatusFrame * InterfaceStatusFrame     = { read = InterfaceStatusFrame_, write = InterfaceStatusFrame_ };

};

//---------------------------------------------------------------------------
#endif
