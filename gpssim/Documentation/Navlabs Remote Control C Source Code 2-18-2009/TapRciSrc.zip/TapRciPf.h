#ifndef TapRciPfH
#define TapRciPfH

//---------------------------------------------------------------------------
//
// $Workfile:: TapRciPf.h                                            $
//
// $Revision:: 4                                                     $
//
// $History:: TapRciPf.h                                             $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Additional com port params.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:01p
//Updated in $/TapRci
//Add various properties.
//
//
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
class TTapRciProfile : public TIniFile  {
private:

   bool const                GetDispRelativePower();
   void                      SetDispRelativePower( const bool DispRelativePower );
   AnsiString const          GetTapMsecPath();
   void                      SetTapMsecPath( const AnsiString &TapMsecPath );
   AnsiString const          GetWinVpgPath();
   void                      SetWinVpgPath( const AnsiString &WinVpgPath );
   AnsiString const          GetRemoteScn();
   void                      SetRemoteScn( const AnsiString &RemoteScn );
   eIntType const            GetIntType();
   void                      SetIntType( const eIntType InIntType );
   bool const                GetGpib();
   void                      SetGpib( const bool Gpib );
   bool const                GetSerial();
   void                      SetSerial( const bool Serial );
   bool const                GetEthernet();
   void                      SetEthernet( const bool Ethernet );
   bool const                GetVerifyOperationAtStart();
   void                      SetVerifyOperationAtStart( const bool VerifyOperationAtStart );
   bool const                GetWinVpgRequired();
   void                      SetWinVpgRequired( const bool WinVpgRequired );

   // Message Control Section [MSGCONTROL]
   bool const                GetAckEvery();
   void                      SetAckEvery( const bool AckEvery );
   bool const                GetChanStatOnChange();
   void                      SetChanStatOnChange( const bool InChanStatOnChange );
   bool const                GetSimModeOnChange();
   void                      SetSimModeOnChange( const bool InSimModeOnChange );

   // GPIB
   int const                 GetGpibPrimaryAddress();
   void                      SetGpibPrimaryAddress( const int GpibPrimaryAddress );
   int const                 GetGpibBoardIndex();
   void                      SetGpibBoardIndex( const int GpibBoardIndex );
   int const                 GetGpibTimeout();
   void                      SetGpibTimeout( const int Timeout );
   bool const                GetGpibUseSRQ();
   void                      SetGpibUseSRQ( const bool InUseSRQ );

   // Ethernet
   bool const                GetEthernetServer();
   void                      SetEthernetServer( const bool IsServer );
   AnsiString const          GetEthernetHostAddress();
   void                      SetEthernetHostAddress( const AnsiString &HostAddr );
   int const                 GetEthernetPortNum();
   void                      SetEthernetPortNum( const int PortNum );

   // Serial
   int const                 GetSerialComPort();
   void                      SetSerialComPort( const int ComPort );
   int const                 GetSerialBaud();
   void                      SetSerialBaud( const int Baud );
   int const                 GetSerialStopBits();
   void                      SetSerialStopBits( const int StopBits );
   int const                 GetSerialDataBits();
   void                      SetSerialDataBits( const int DataBits );
   int const                 GetSerialParity();
   void                      SetSerialParity( const int Parity );
   bool const                GetSerialHWFlow();
   void                      SetSerialHWFlow( const bool HWFlow );
   bool const                GetSerialSWFlow();
   void                      SetSerialSWFlow( const bool SWFlow );


protected:

public:

   TTapRciProfile();

   __property bool        DispRelativePower        = { read = GetDispRelativePower,      write = SetDispRelativePower      };
   __property AnsiString  TapMsecPath              = { read = GetTapMsecPath,            write = SetTapMsecPath            };
   __property AnsiString  WinVpgPath               = { read = GetWinVpgPath,             write = SetWinVpgPath             };
   __property AnsiString  RemoteScn                = { read = GetRemoteScn,              write = SetRemoteScn              };
   __property bool        Gpib                     = { read = GetGpib,                   write = SetGpib                   };
   __property bool        Serial                   = { read = GetSerial,                 write = SetSerial                 };
   __property bool        Ethernet                 = { read = GetEthernet,               write = SetEthernet               };
   __property int         GpibPrimaryAddress       = { read = GetGpibPrimaryAddress,     write = SetGpibPrimaryAddress     };
   __property int         GpibBoardIndex           = { read = GetGpibBoardIndex,         write = SetGpibBoardIndex         };
   __property int         GpibTimeout              = { read = GetGpibTimeout,            write = SetGpibTimeout            };
   __property bool        AckEvery                 = { read = GetAckEvery,               write = SetAckEvery               };
   __property bool        VerifyOperationAtStart   = { read = GetVerifyOperationAtStart, write = SetVerifyOperationAtStart };
   __property bool        EthernetServer           = { read = GetEthernetServer,         write = SetEthernetServer         };
   __property AnsiString  EthernetHostAddress      = { read = GetEthernetHostAddress,    write = SetEthernetHostAddress    };
   __property int         EthernetPortNum          = { read = GetEthernetPortNum,        write = SetEthernetPortNum        };
   __property int         SerialComPort            = { read = GetSerialComPort,          write = SetSerialComPort          };
   __property int         SerialBaud               = { read = GetSerialBaud,             write = SetSerialBaud             };
   __property int         SerialStopBits           = { read = GetSerialStopBits,         write = SetSerialStopBits         };
   __property int         SerialDataBits           = { read = GetSerialDataBits,         write = SetSerialDataBits         };
   __property int         SerialParity             = { read = GetSerialParity,           write = SetSerialParity           };
   __property bool        SerialHWFlow             = { read = GetSerialHWFlow,           write = SetSerialHWFlow           };
   __property bool        SerialSWFlow             = { read = GetSerialSWFlow,           write = SetSerialSWFlow           };
   __property eIntType    IntType                  = { read = GetIntType,                write = SetIntType                };
   __property bool        WinVpgRequired           = { read = GetWinVpgRequired,         write = SetWinVpgRequired         };
   __property bool        GpibUseSRQ               = { read = GetGpibUseSRQ,             write = SetGpibUseSRQ             };
   __property bool        MsgChanStatOnChange      = { read = GetChanStatOnChange,       write = SetChanStatOnChange       };
   __property bool        MsgSimModeOnChange       = { read = GetSimModeOnChange,        write = SetSimModeOnChange        };


};

//---------------------------------------------------------------------------
#endif
