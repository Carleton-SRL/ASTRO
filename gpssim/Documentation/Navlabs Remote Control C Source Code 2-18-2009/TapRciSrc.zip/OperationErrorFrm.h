//---------------------------------------------------------------------------

#ifndef OperationErrorFrmH
#define OperationErrorFrmH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: OperationErrorFrm.h                                   $
//
// $Revision:: 3                                                     $
//
// $History:: OperationErrorFrm.h                                    $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:24p
//Updated in $/TapRci
//Brought over from TapMsec.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:23p
//Updated in $/TapRci
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include "RzDlgBtn.hpp"
#include "RzLabel.hpp"
#include "RzPanel.hpp"
#include <ExtCtrls.hpp>
#include "RzButton.hpp"
#include "RzRadChk.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------
//---------------------------------------------------------------------------
class TOperationErrorForm : public TForm
{
__published:
   TRzPanel *BottomPnl;
   TRzPanel *TopClientPnl;
   TRzDialogButtons *Buttons;
   TRzPanel *TopPnl;
   TRzLabel *RzLabel1;
   TOvcLabel *GeneralErrorLbl;
   TRzPanel *ClientPnl;
   TScrollBox *ErrorStrScrollBox;
   TOvcLabel *ErrorSpecificLbl;
   void __fastcall ButtonsClickOk(TObject *Sender);
   void __fastcall ButtonsClickCancel(TObject *Sender);
private:

   AnsiString                ErrorSpecificStr_;
   const bool                PromptToContinue_;
   bool                      Continue_;

   AnsiString const          GetGeneralErrorCaption() const;
   void                      SetGeneralErrorCaption( const AnsiString & InGeneralErrorCaption );
   AnsiString const          GetErrorStr() const;
   void                      SetErrorStr( const AnsiString & ErrorStr );
   bool const                GetContinue() const;

public:

   __fastcall TOperationErrorForm
      (
      TComponent           * Owner,
      const AnsiString     & InErrorSpecificStr    = "",
      const bool             PromptToContinue      = false
      );

   __property AnsiString GeneralErrorCaption      = { read = GetGeneralErrorCaption, write = SetGeneralErrorCaption  };
   __property AnsiString ErrorStr                 = { read = GetErrorStr,            write = SetErrorStr             };
   __property bool       Continue                 = { read = GetContinue                                             };

};
//---------------------------------------------------------------------------
extern PACKAGE TOperationErrorForm *OperationErrorForm;
//---------------------------------------------------------------------------
#endif
