//---------------------------------------------------------------------------


#ifndef ChanStatFramH
#define ChanStatFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: ChanStatFram.h                                        $
//
// $Revision:: 4                                                     $
//
// $History:: ChanStatFram.h                                         $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:18p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:29p
//Updated in $/TapRci
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "RzLabel.hpp"
#include <ExtCtrls.hpp>
#include "RzBorder.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef TapMsecRciH
#include "TapMsecRci.h"
#endif

//---------------------------------------------------------------------------
class TChanStatFrame : public TFrame
{
__published:
   TRzLabel *ChLbl;
   TRzLabel *SvidLbl;
   TRzLabel *L1PowerLbl;
   TRzLabel *ElLbl;
   TRzLabel *AzLbl;
   TRzLabel *L2PowerLbl;
   TRzBorder *RzBorder1;
private:	// User declarations

   TTapMsecStatChan          ChanStat;
   bool                      DispRelative;
   int                       ChanNum;

   void                      DispChanStat();

public:

   __fastcall TChanStatFrame(TComponent* Owner, const int ChanNum, const bool DispRelative=false);

   void                      SetChanStat( const TTapMsecStatChan &ChanStat );
   void                      SetDispRelativePower( const bool DispRelative );
};
//---------------------------------------------------------------------------
extern PACKAGE TChanStatFrame *ChanStatFrame;
//---------------------------------------------------------------------------

typedef std::vector<TChanStatFrame *> TChanStatFrameArray;
#endif
