//---------------------------------------------------------------------------


#ifndef BitResultsFramH
#define BitResultsFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: BitResultsFram.h                                      $
//
// $Revision:: 4                                                     $
//
// $History:: BitResultsFram.h                                       $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:18p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 9:52p
//Updated in $/TapRci
//Add Source Safe keywords.
//Add include file guards.
//Add #ifndef for OS/ VCL includes.
//Minor display changes.
//Minor code cleanup.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include "RzBorder.hpp"
#include "RzPanel.hpp"
#include <ExtCtrls.hpp>
#include "RzCommon.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef TapBitH
#include "TapBit.h"
#endif


//---------------------------------------------------------------------------
class TBitResultsFrame : public TFrame
{
__published:
   TRzPanel *BitResultsDateTimePnl;
   TOvcLabel *DateLbl;
   TOvcLabel *TimeLbl;
   TOvcLabel *BitDateTimeLbl;
   TRzPanel *BottomPnl;
   TRzPanel *MainClientPnl;
   TRzPanel *BitResultsTopPnl;
   TOvcLabel *BitResultsTitle;
   TRzPanel *BitResultsHwProgStatusTitlePnl;
   TOvcLabel *HWProgStatusTitle;
   TRzPanel *BitResultsHwProgStatusPnl;
   TOvcLabel *X1Lbl;
   TOvcLabel *X2Lbl;
   TOvcLabel *X3Lbl;
   TOvcLabel *InitLbl;
   TOvcLabel *DoneLbl;
   TOvcLabel *X1Init;
   TOvcLabel *X2Init;
   TOvcLabel *X3Init;
   TOvcLabel *X1Done;
   TOvcLabel *X2Done;
   TOvcLabel *X3Done;
   TRzPanel *BitResultsHwNonDigitalPnl;
   TOvcLabel *BitResultsNonHwTitle;
   TRzPanel *RzPanel1;
   TOvcLabel *IntLbl;
   TOvcLabel *IntResultsLbl;
   TOvcLabel *OcxoLbl;
   TOvcLabel *OcxoResultsLbl;
   TOvcLabel *PllResultsLbl;
   TOvcLabel *PllLbl;
private:

   typedef struct
   {
      TOvcLabel   *XLbl;
      TOvcLabel   *InitLbl;
      TOvcLabel   *DoneLbl;
   } TChipLblStruct;

   TTapBitResults            TapBitResults;
   void                      DispBitResults( const TTapBitResults & BitResults );
   void                      DispChip( const TTapBitXChip &TapBitXChip, TChipLblStruct &ChipLbls );
   void                      DispBitBase( const TTapBitBase &TapBitBase, TOvcLabel *Lbl, TOvcLabel *ResultsLbl );
   void                      SetResultsLbl( const bool Passed, TOvcLabel *Lbl );
   void                      SetResultsVisible( const bool Passed, TOvcLabel *Lbl );
   void                      SetRequiredLbl( const bool Required, TOvcLabel *Lbl );

public:

   __fastcall                TBitResultsFrame( TComponent * Owner );

   void                      SetBitResults( const TTapBitResults & BitResults );

};
//---------------------------------------------------------------------------
extern PACKAGE TBitResultsFrame *BitResultsFrame;
//---------------------------------------------------------------------------
#endif
