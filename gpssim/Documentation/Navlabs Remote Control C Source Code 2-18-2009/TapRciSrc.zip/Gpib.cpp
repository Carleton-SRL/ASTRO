#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: Gpib.cpp                                              $
//
// $Revision:: 4                                                     $
//
// $History:: Gpib.cpp                                               $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/02/03    Time: 11:43a
//Updated in $/TapRci
//Add BorlandC_gpib-32.obj to pragma link.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:34p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:35p
//Updated in $/TapRci
//Initial release.
//
//
//---------------------------------------------------------------------------


#ifndef GpibH
#include "Gpib.h"
#endif

#ifndef GpibTimeoutH
#include "GpibTimeout.h"
#endif

#ifndef ThreadInfH
#include "ThreadInf.h"
#endif

#include "Decl-32.h"

//---------------------------------------------------------------------------
// Add pragma link here to bring in the object module.  This makes it easier
// to fool the make file as we do not have the source for this file.
//---------------------------------------------------------------------------

#pragma link "borlandc_gpib-32"

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
// Debug Data
//
#ifndef DebugUtilsH
#include "DebugUtils.h"
using namespace DebugUtils;
#endif
#if(1)
static   TTimeInterval ExecuteInterval;
static   double        MinExecuteIntervalms      = 10000.0;
static   double        MaxExecuteIntervalms      = 0.0;
static   int           WaitTimer                 = 0;
static   int           WaitEvent                 = 0;
static   int           WaitTimeout               = 0;
static   int           WaitAbandoned             = 0;
static   int           WaitDebugProcessingCount  = 0;
static   int           WAIT_DEBUG_PROCESSING_MIN = 100;
#endif


//---------------------------------------------------------------------------

static char ErrorMnemonic[21][5] =
{
   "EDVR", "ECIC", "ENOL", "EADR", "EARG", "ESAC", "EABO", "ENEB", "EDMA", "",
   "EOIP", "ECAP", "EFSO", ""    , "EBUS", "ESTB", "ESRQ", ""    , ""    , "",
   "ETAB"
};

static const int             MAX_GPIB_BYTES_TO_READ          = 1000;
static const int             GPIB_EXECUTE_TIMER_MS           = 50;
static const AnsiString      EventSendDataGpibName           = AnsiString( "TGpibSendDataEvent" );

TGpib::TGpib
   (
   TComponent * InOwner
   ) :
   TapRciPf( NULL ),
   Owner( InOwner ),
   GpibThread( NULL )
{


   CodeSite->EnterMethod("TGpib");

   GpibThread                 = new TGpibThread();

   GpibStatusFrame            = new TGpibInterfaceStatusFrame( Owner, this );
   InterfaceStatusFrame       = dynamic_cast<IInterfaceStatusFrame *>( GpibStatusFrame );

   GpibThread->Resume();

   CodeSite->ExitMethod( "TGpib" );

}

bool const
TGpib::InitCommunication
   (
   )
{
   return( true );
}

AnsiString const
TGpib::GetStatusStr
   (
   ) const
{
   return( GpibThread ? GpibThread->StatusStr : AnsiString() );
}

AnsiString const
TGpib::GetParametersStr
   (
   ) const
{
   return( GpibThread ? GpibThread->ParametersStr : AnsiString() );
}


bool const
TGpib::SendMsg
   (
   const TMsgData          & Data
   )
{

   if ( Data.empty() ) return( false );

   bool Sent     = false;

   if ( GpibThread && Data.size() )
   {

      Sent       = !( GpibThread->QueueMsgData( Data ) );

   }

   return( !Sent );

}

void
TGpib::ReadMsg
   (
   TMsgData                & MsgData
   )
{

   if ( GpibThread )
   {
      GpibThread->GetMsgData( MsgData );
   }

}

void
TGpib::ReportError
   (
   const AnsiString &PreStr
   )
{

   CodeSite->SendMsg( csmError, PreStr );

}

__fastcall
TGpib::~TGpib
   (

   )
{

   if ( GpibThread )
   {
      GpibThread->Terminate();
      GpibThread->WaitFor();
      delete GpibThread;
      GpibThread = NULL;
   }

}


//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
// TGpibThread
// Thread that does the actual GPIB communication.  Separate
// from the TRtMsgProcessor thread.
//
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

TGpibThread::TGpibThread
   (
   ) :
   TThread( true ),
   TapRciPf( NULL ),
   ValidInterface_( false ),
   ReadCriticalSection( NULL ),
   WriteCriticalSection( NULL ),
   StrCriticalSection( NULL ),
   hTimer( NULL ),
   Timeout_( T100ms ),
   EventSendDataGpib( NULL ),
   EventReceiveDataInterface( NULL )
{


   CodeSite->EnterMethod( "TGpibThread" );

//   DebugStream.open( "GpibThread.txt" );
//   DebugStream << "GpibThread Active" << endl;

   ValidInterface_           = false;
   TapRciPf                  = new TTapRciProfile();
   BoardIndex_               = TapRciPf->GpibBoardIndex;
   PrimaryAddress_           = TapRciPf->GpibPrimaryAddress;

   Timeout_                  = TapRciPf->GpibTimeout;
   TapRciPf->GpibTimeout     = Timeout_;

   AnsiString GpibBoardStr;
   GpibBoardStr.sprintf( "gpib%d", BoardIndex_ );

   CodeSite->SendMsg( AnsiString( "GpibBoardStr " ) + GpibBoardStr );
//   DebugStream << "GpibBoardStr " << GpibBoardStr.c_str() << endl;

   ReadCriticalSection       = new TCriticalSection();
   WriteCriticalSection      = new TCriticalSection();
   StrCriticalSection        = new TCriticalSection();

   SetupTimer();
   EventSendDataGpib         = new TEvent( NULL, false, false, EventSendDataGpibName );
   EventReceiveDataInterface = new TEvent( NULL, false, false, TInterface::GetEventReceiveDataName() );

   Board_ = ibfind( GpibBoardStr.c_str() );

   if ( Board_ >= 0 )
   {

      CodeSite->SendMsg( GpibBoardStr + AnsiString( " board found. ") );
//      DebugStream << GpibBoardStr.c_str() << " board found. " << endl;

      ibconfig( Board, IbcCICPROT, 0 );

      if ( ibsta & ERR )
      {

         ReportError( AnsiString( "Unable to set CIC to 0" ) );
         ValidInterface_ = false;

      }
      else
      {

         CodeSite->SendMsg( AnsiString( "Set CIC to 0 ") );
//         DebugStream << "Set CIC to 0 " << endl;

         ValidInterface_ = true;

      }

      ibpad( Board, PrimaryAddress_ );

      if ( ibsta & ERR )
      {

         ReportError( AnsiString( "Unable to set primary address to " ) + AnsiString( PrimaryAddress_ ) );
         ValidInterface_ = false;

      }
      else
      {

         CodeSite->SendMsg( AnsiString( "Primary address set to ") + AnsiString( PrimaryAddress_ ) );
//         DebugStream << AnsiString( AnsiString( "Primary address set to ") + AnsiString( PrimaryAddress_ ) ).c_str() << endl; 

         ValidInterface_ = true;

      }

   }
   else
   {

      ReportError( AnsiString( "Unable to find board " ) + GpibBoardStr );
      ValidInterface_ = false;

   }


   ibtmo( Board, Timeout );

   if ( ibsta & ERR )
   {

      ReportError( AnsiString( "Unable to set timeout" ) );
      ValidInterface_ = false;

   }
   else
   {

      TGpibTimeout GpibTime( T100ms );
      CodeSite->SendMsg( AnsiString( "Timeout set to ") + GpibTime.GetTimeoutStr( Timeout ) );
//      DebugStream << "Timeout set to " << GpibTime.GetTimeoutStr( Timeout ).c_str() << endl;
      ValidInterface_ = true;

   }


   if ( ValidInterface )
   {

      CodeSite->SendMsg( csmNote, " GPIB Interface valid." );

   }
   else
   {

      CodeSite->SendMsg( csmError, " GPIB Interface failed." );

   }


   CodeSite->ExitMethod( "TGpibThread" );

}

void
TGpibThread::SetupTimer
   (
   )
{

   hTimer                  = CreateWaitableTimer( NULL, FALSE,  NULL );

   __int64 qwDueTime       = -5;

   // Copy the relative time into a LARGE_INTEGER.
   //
   LARGE_INTEGER   liDueTime;
   liDueTime.LowPart       = (DWORD) ( qwDueTime & 0xFFFFFFFF );
   liDueTime.HighPart      = (LONG)  ( qwDueTime >> 32 );

   SetWaitableTimer
   (
      hTimer,                                              // Handle to the timer object.
      &liDueTime,                                          // When timer will become signaled.
      GPIB_EXECUTE_TIMER_MS,                               // Periodic timer interval millisecs.
      NULL,                                                // Completion routine.
      NULL,                                                // Argument to the completion routine.
      FALSE                                                // Do not restore a suspended system.
   );

}


AnsiString const
TGpibThread::GetStatusStr
   (
   )
{
   AnsiString Str;
#if(0)
   StrCriticalSection->Acquire();
   try
   {
      if ( !StatusStrQ_.empty() )
      {
         Str = StatusStrQ_.front();
         StatusStrQ_.pop_front();
      }
   }
   catch(...)
   {
   }
   StrCriticalSection->Release();
#endif
   return( Str );

}

#if(0)
void
TGpibThread::AddStatus
   (
   const AnsiString        & NewStatusStr
   )
{
   AnsiString ErrStr;

   ErrStr.sprintf( " ibsta = 0x%x", ibsta );

   if ( ibsta & 0x8000 )
   {
      ErrStr.cat_sprintf( " iberr = %d", iberr );
      if ( iberr < 21 )
      {
         ErrStr += AnsiString( ErrorMnemonic[iberr] );
      }
   }

   AnsiString Str = NewStatusStr + ErrStr;

   StrCriticalSection->Acquire();
   try
   {
      StatusStrQ_.push_back( Str );
   }
   catch(...)
   {
   }
   StrCriticalSection->Release();

}
#endif

AnsiString const
TGpibThread::GetParametersStr
   (
   )
{

   AnsiString Str;
   StrCriticalSection->Acquire();
   Str = AnsiString( "Board Index : " ) + AnsiString( BoardIndex_ ) + AnsiString( "   PrimaryAddress : " ) + AnsiString( PrimaryAddress_ )
      + AnsiString( "  SecondaryAddress : " ) + AnsiString( SecondaryAddress_ );
   StrCriticalSection->Release();

   return( Str );

}

void __fastcall
TGpibThread::Execute
   (
   )
{

   TThreadInf TThreadInf( "GpibThread" );
   Priority = PriorityRtMsg;

   int NumSyncObjects = 2;
   HANDLE SyncObjects[2];
   SyncObjects[0]          = hTimer;
   SyncObjects[1]          = (void *) EventSendDataGpib->Handle;

   // DEBUG
   ExecuteInterval.ResetStart();

   while( !Terminated )
   {

      const int WaitResult  = WaitForMultipleObjects( NumSyncObjects, SyncObjects, FALSE, GPIB_EXECUTE_TIMER_MS*2 );

      WaitDebugProcessing( WaitResult );
      try
      {

         WriteQueuedMsgData();

         TMsgData InData;
         ReadMsgData( InData );

         AddInMsgDataQueue( InData );

      }
      catch( const Exception & Exc )
      {
         AnsiString ExcStr     = AnsiString( "TGpibThread::Execute Exception caught.  " ) + Exc.Message;
         CodeSite->SendMsg( ExcStr );
         ReportError( ExcStr );
         throw( Exception( ExcStr ) );
      }

   }

}

bool const
TGpibThread::WriteQueuedMsgData
   (
   )
{

   WriteCriticalSection->Acquire();

   TMsgData OutData = QueuedOutMsgData;

   QueuedOutMsgData.clear();

   WriteCriticalSection->Release();

   bool WriteError = SendMsgData( OutData );
   if ( WriteError )
   {
      ReportError( "TGpibThread::WriteQueuedMsgData error on SendMsgData" );
   }

   return( WriteError );

}

void
TGpibThread::AddInMsgDataQueue
   (
   TMsgData                & MsgData
   )
{

   if ( MsgData.empty() ) return;

   ReadCriticalSection->Acquire();

   try
   {

      if ( QueuedInMsgData.empty() )
      {
         QueuedInMsgData = MsgData;
      }
      else
      {
         QueuedInMsgData.insert( QueuedInMsgData.end(), MsgData.begin(), MsgData.end() );
      }
   }
   catch( const Exception & Exc )
   {
      AnsiString    ErrorStr( "TGpibThread::AddInMsgDataQueue exception.  " );
      ErrorStr += AnsiString( "MsgData.size() = " ) + AnsiString( MsgData.size() ) + AnsiString( ".  " );
      ErrorStr += AnsiString( "QueuedInMsgData.size() = " ) + AnsiString( QueuedInMsgData.size() );
      ErrorStr += Exc.Message;
      ReportError( ErrorStr );
   }

   const bool DataRead = QueuedInMsgData.size();

   ReadCriticalSection->Release();

   if ( DataRead ) EventReceiveDataInterface->SetEvent();

}

bool const
TGpibThread::GetMsgData
   (
   TMsgData                & MsgData
   )
{

   ReadCriticalSection->Acquire();

   if ( QueuedInMsgData.empty() )
   {
      ReadCriticalSection->Release();
      return( false );
   }

   bool bRead = false;

   try
   {

      if ( MsgData.empty() )
      {

         MsgData = QueuedInMsgData;

      }
      else
      {
         MsgData.insert( MsgData.end(), QueuedInMsgData.begin(), QueuedInMsgData.end() );
      }

      QueuedInMsgData.clear();

      bRead = true;

   }
   catch(...)
   {
      AnsiString    ErrorStr( "TGpibThread::GetMsgData exception.  " );
      ErrorStr += AnsiString( "MsgData.size() = " ) + AnsiString( MsgData.size() ) + AnsiString( ".  " );
      ErrorStr += AnsiString( "QueuedInMsgData.size() = " ) + AnsiString( QueuedInMsgData.size() );
      CodeSite->SendMsg( csmError, ErrorStr );
      bRead     = false;
   }

   ReadCriticalSection->Release();

   return( !bRead );

}

bool const
TGpibThread::QueueMsgData
   (
   const TMsgData          & MsgData
   )
{

   bool Queued = false;

   if ( MsgData.size() )
   {

      WriteCriticalSection->Acquire();

      try
      {

         if ( QueuedOutMsgData.empty() )
         {
            QueuedOutMsgData = MsgData;
         }
         else
         {
            QueuedOutMsgData.insert( QueuedOutMsgData.end(), MsgData.begin(), MsgData.end() );
         }

         Queued = true;

      }
      catch(...)
      {
         AnsiString    ErrorStr( "TGpibThread::QueueMsgData exception.  " );
         ErrorStr += AnsiString( "MsgData.size() = " ) + AnsiString( MsgData.size() ) + AnsiString( ".  " );
         ErrorStr += AnsiString( "QueuedOutMsgData.size() = " ) + AnsiString( QueuedOutMsgData.size() );
         CodeSite->SendMsg( csmError, ErrorStr );
      }

      WriteCriticalSection->Release();

      EventSendDataGpib->SetEvent();

   }

   return( !Queued );

}

bool const
TGpibThread::SendMsgData
   (
   const TMsgData          & Data
   )
{

   if ( Data.empty() ) return( false );

   bool Sent = false;

   // Request Service
   //
   ibrsv( Board, 0x40 );

   if ( ibsta & ERR )
   {

      ReportError( AnsiString( "ibrsv error. " ) );

   }

   try
   {
      const int MaxSendAttempts = 10;
      int       SendTimes       = 0;

      while ( !Sent && ++SendTimes < MaxSendAttempts )
      {

         // Update ibsta
         //
         ibwait(Board,0);

         // Talker
         //
         if ( !(ibsta & ATN) && (ibsta & TACS) )
         {

            ibwrt( Board, (void *) &Data[0], Data.size() );
            if ( ibsta & ERR )
            {
               ReportError( AnsiString( "ibwrt error. " ) );
            }
            else
            {
               Sent = true;
            }

         }
      }
   }
   catch ( const Exception & Exc )
   {
      ReportError( AnsiString( "TGpibThread::SendMsgData Exception caught. Exception message = " ) + Exc.Message );
   }

   return( !Sent );

}

void
TGpibThread::ReadMsgData
   (
   TMsgData                & MsgData
   )
{

   unsigned char Data[MAX_GPIB_BYTES_TO_READ];

   ibwait(Board,0);

   // Listener
   //
   if ( !(ibsta & ATN) && (ibsta & LACS) )
   {

      ibrd( Board, Data, MAX_GPIB_BYTES_TO_READ );

      if ( ibsta & ERR ) //&& iberr != EABO )
      {

         AnsiString ErrStr("ibrd error. ");
         ReportError( ErrStr );

      }

      for ( int i=0; i<ibcntl; ++i )
      {
         MsgData.push_back( Data[i] );
      }
      if ( ibcntl )
      {
         CodeSite->SendInteger("TGpib::ReadMsg ibcntl ", ibcntl );
      }

   }

}

void
TGpibThread::WaitDebugProcessing
   (
   const int WaitResult
   )
{
#if(1)
   if ( WaitResult == WAIT_TIMEOUT )
   {
      CodeSite->WriteInteger( "GpibWaitTimeout", ++WaitTimeout );
   }
   else if ( ( WaitResult >= WAIT_ABANDONED_0 ) && ( WaitResult <= ( WAIT_ABANDONED_0 + 2 - 1 ) ) )
   {
      CodeSite->WriteInteger( "GpibWaitAbandoned", ++WaitAbandoned );
      AnsiString Str;
      Str.sprintf( "GpibWaitAbandoned.  WaitResult = %d, AbandonedIndex = %d", WaitResult, WaitResult - WAIT_ABANDONED_0 );
      CodeSite->SendMsg( Str );
   }
   else if ( ( WaitResult >= WAIT_OBJECT_0 ) && ( WaitResult <= ( WAIT_OBJECT_0 + 2 - 1 ) ) )
   {

      const int WaitIndex = WaitResult - WAIT_OBJECT_0;
      if ( WaitIndex == 0 ) ++WaitTimer;
      if ( WaitIndex == 1 ) ++WaitEvent;

      if ( ( WaitDebugProcessingCount % 10 ) == 0 )
      {
         if ( WaitIndex == 0 )
         {
            CodeSite->WriteInteger( "GpibWaitTimer", WaitTimer );
         }
         else if ( WaitIndex == 1 )
         {
            CodeSite->WriteInteger( "GpibWaitEvent", WaitEvent );
         }
      }
   }

   if ( ++WaitDebugProcessingCount > WAIT_DEBUG_PROCESSING_MIN )
   {
      MinExecuteIntervalms = std::min( ExecuteInterval.TimeIntervalms, MinExecuteIntervalms );
      MaxExecuteIntervalms = std::max( ExecuteInterval.TimeIntervalms, MaxExecuteIntervalms );
   }
   if ( ( WaitDebugProcessingCount % 10 ) == 0 )
   {
      CodeSite->WriteFloat( "GpibExecuteMinms", MinExecuteIntervalms );
      CodeSite->WriteFloat( "GpibExecuteMaxms", MaxExecuteIntervalms );
      ExecuteInterval.Reportms( "TGpibThreadExecutems" );
   }
   ExecuteInterval.ResetStart();
#endif
}

void
TGpibThread::ReportError
   (
   const AnsiString & PreStr
   )
{

   AnsiString ErrStr;

   if ( ibsta & ERR )
   {

      ErrStr.sprintf( " ibsta = 0x%x iberr = %d (%s)", ibsta, iberr, ErrorMnemonic[iberr] );

   }

   CodeSite->SendMsg( csmError, PreStr + ErrStr );

//   DebugStream << PreStr.c_str() << ErrStr.c_str() << endl; 

}

__fastcall
TGpibThread::~TGpibThread
   (

   )
{

   ibonl( Dev, 0 );
   CloseHandle( hTimer );
   delete ReadCriticalSection;
   delete WriteCriticalSection;
   delete StrCriticalSection;

}




