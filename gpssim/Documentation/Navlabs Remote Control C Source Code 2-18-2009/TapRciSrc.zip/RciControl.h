//---------------------------------------------------------------------------

#ifndef RciControlH
#define RciControlH


//---------------------------------------------------------------------------
//
// $Workfile:: RciControl.h                                          $
//
// $Revision:: 8                                                     $
//
// $History:: RciControl.h                                           $
//
//*****************  Version 8  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:13p
//Updated in $/TapRci
//Only open TpMapInterface required to avoid conflict w/ TapMsec.
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 1/19/05    Time: 8:55a
//Updated in $/TapRci
//Handle case where TapMsec does not shut down.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Add ScenarioSetPulseMsg
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 1/16/04    Time: 10:41p
//Updated in $/TapRci
//Add "SetL2Atten" message.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:25p
//Updated in $/TapRci
//Add Time Set Pulse message processing.  ExtResetPulse/Cancel.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:51p
//Updated in $/TapRci
//Add REGENSCEN.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef ScheduleH
#include "Schedule.h"
#endif

#ifndef TapMsecRciH
#include "TapMsecRci.h"
#endif

#ifndef GpibH
#include "Gpib.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef TapMsecPfH
#include "TapMsecPf.h"
#endif

#ifndef RciMsgsH
#include "RciMsgs.h"
#endif

#ifndef VoyDefPfH
#include "VoyDefPf.h"
#endif

#ifndef UserQueryH
#include "UserQuery.h"
#endif

#ifndef TpMapInterfaceH
#include "TpMapInterface.h"
#endif


typedef TUserQuery<eRciSimMode>    TSimModeQuery;
typedef TUserQuery<TTapBitResults> TTapBitResultsQuery;
typedef TUserQuery<TChanStatArray> TChanStatQuery;
typedef TUserQuery<TSysCfg>        TSysCfgQuery;
typedef TUserQuery<TTapMsecStat>   TSimTimeQuery;

typedef queue<TTapMsecCommand> TTapMsecCommandQueue;

class TRciControl : public TThread
{
private:

   TTapMsecStatMem         * TapMsecStatMem;
   TTapMsecCommandMem      * TapMsecCommandMem;
   TTapMsecStat              TapMsecStat_;
   TInterface              * Interface;
   bool                      Valid_;
   TScheduleSignal         * ScheduleSignal;
   bool                      AckEvery;
   TTapRciProfile          * TapRciProfile;
   TTapMsecProfile         * TapMsecProfile;
   VoyDefProfile           * Vdp;
   AnsiString                RunsDir;
   eRciSimMode               SimMode;
   TOutMsgQueue              OutMsgQueue;
   TTapMsecCommandQueue      TapMsecCommandQueue;
   TTapBitResults            TapBitResults;
   TChanStatArray            ChanStatArray;
   TSysCfg                   SysCfg;
   TComponent              * Owner;
   int                       CurTimeMillisec;
   HANDLE                    hTimer;
   TEvent                  * EventReceiveData;
   TTpMapInterface         * TpMapInterface_;
   AnsiString                ExtResetPulseScenName_;
   AnsiString                ExtResetPulseScenarioPath_;
   bool                      TapMsecShutdown_;
   double                    TimeIntoSim_;
   int                       NumInMsgs_;
   int                       NumOutMsgs_;

   static AnsiString         EventReceiveDataName;

   // Queries
   TSimModeQuery             SimModeQuery;
   TTapBitResultsQuery       BitResultsQuery;
   TChanStatQuery            ChanStatQuery;
   TSysCfgQuery              SysCfgQuery;
   TSimTimeQuery             SimTimeQuery;
   PROCESS_INFORMATION       TapMsecProcInfo;
   PROCESS_INFORMATION       WinVpgProcInfo;

   void                      RunStartScen( const AnsiString & Parameters );
   void                      RunRegenScen( const AnsiString & Parameters );
   eRciSimMode const         SetCurrentSimMode();
   eRciSimMode const         GetCurrentSimMode();
   void                      ClearTapMsecProcInfo();
   void                      ClearWinVpgProcInfo();
   void                      GetControlData();
   IInterfaceStatusFrame *   GetInterfaceStatusFrame() { return( Interface->InterfaceStatusFrame ); }
   void                      WaitDebugProcessing( const int Wait );

protected:

   void __fastcall           Execute();
   bool const                InitializeInterface();
   void                      ProcessInputMsgs( TInMsgArray &InMsgArray, TOutMsgQueue &OutMsgs );
   void                      ProcessInputMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessInitGeoMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessTimeSetPulseMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessStartScenStartPulseMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessStartScenMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessRegenScenMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessExecMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessStartLocalMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessSetSvidMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessSetPowerMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessSetL1AttenMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessSetL2AttenMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessStopMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessShutdownMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessResetMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessQueryMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessSetRfGainMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessAdjustRfGainMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessSetRfAttenMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessAdjustRfAttenMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessUnknownMsg( const TInMsg &InMsg, TOutMsgQueue &OutMsgs );
   void                      ProcessExtResetPulseRcvd();
   bool const                StartRemoteScenario();
   void                      SendCommandToTapMsec();
   void                      ProcessQueries( TOutMsgQueue & OutMsgs );
   void                      SendSimMode( TOutMsgQueue & OutMsgs );
   void                      SendChanStat( TOutMsgQueue & OutMsgs );
   void                      SendBitResults( TOutMsgQueue & OutMsgs );
   void                      SendSysCfg( TOutMsgQueue & OutMsgs );
   void                      SendSimTime( TOutMsgQueue & OutMsgs );
   void                      SendTimeIntoSim( TOutMsgQueue & OutMsgs );
   void                      PerformBit();
   void                      ReportErrorAndTerminate(const AnsiString & ErrorStr);
   void                      GetSysCfg();
   void                      ProcessTapMsecCommands();
   bool const                GetValid() const { return( Valid_ ); }
   void                      SetValid( const bool InValid ) { Valid_ = InValid; }
   TTapMsecStat const        GetCurrentTapMsecStat();
   TMsgTrafficArray const    GetMsgTrafficArray();
   void                      SetupTimer();
   bool const                GetResetPulseRcvd();
   bool const                GetWaitForExtResetPulseArmed( );
   int const                 GetIntCount() const;
   int const                 GetPPSCount() const;

public:

   __fastcall                TRciControl( TComponent * Owner );
   virtual __fastcall       ~TRciControl();

   void                      CancelExtResetPulse();

   static AnsiString const   GetEventReceiveDataName() { return( EventReceiveDataName ); }



   __property bool                    Valid                      = { read = GetValid,              write = SetValid      };
   __property TTapMsecStat            CurrentTapMsecStat         = { read = GetCurrentTapMsecStat                        };
   __property TMsgTrafficArray        MsgTrafficArray            = { read = GetMsgTrafficArray                           };
   __property IInterfaceStatusFrame * InterfaceStatusFrame       = { read = GetInterfaceStatusFrame                      };
   __property bool                    ResetPulseRcvd             = { read = GetResetPulseRcvd                            };
   __property bool                    WaitForExtResetPulseArmed  = { read = GetWaitForExtResetPulseArmed                 };
   __property eRciSimMode             CurSimMode                 = { read = GetCurrentSimMode                            };
   __property TTpMapInterface       * TpMapInterface             = { read = TpMapInterface_                              };
   __property int                     IntCount                   = { read = GetIntCount                                  };
   __property int                     PPSCount                   = { read = GetPPSCount                                  };
   __property int                     NumInMsgs                  = { read = NumInMsgs_                                   };
   __property int                     NumOutMsgs                 = { read = NumOutMsgs_                                  };

};
//---------------------------------------------------------------------------
#endif
