#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: PortDisp.cpp                                          $
//
// $Revision:: 2                                                     $
//
// $History:: PortDisp.cpp                                           $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/24/04    Time: 12:59p
//Created in $/TapRci
//
//*****************  Version 8  *****************
//User: Michael Wade Date: 5/25/04    Time: 3:05p
//Updated in $/TapMsec
//Add SiRF automobile support.
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 12/09/03   Time: 10:37a
//Updated in $/TapMsec
//Change case of "SiRF"
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 11/14/03   Time: 11:48a
//Updated in $/TapMsec
//Add reference receiver bitmap.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 1/20/03    Time: 11:22a
//Updated in $/TapMsec
//Add parity, baud, etc.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 7/28/02    Time: 10:47p
//Updated in $/TapMsec
//Added include file guards
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 7/23/02    Time: 7:50p
//Updated in $/TapMsec
//Added Source Safe keywords
//Changed Rockwell bitmap to 24 x 24
//
//
//
//
//---------------------------------------------------------------------------


#ifndef PortDispH
#include "PortDisp.h"
#endif



TPortDisp::TPortDisp
   (
   const int                 InPortNum,
   const int                 InBaud,
   const int                 InStopBits,
   const int                 InDataBits,
   const int                 InParity,
   const bool                InHWFlow,
   const bool                InSWFlow
   ) :
   PortNum_( InPortNum ),
   Baud_( InBaud ),
   StopBits_( InStopBits ),
   DataBits_( InDataBits ),
   Parity_( InParity ),
   HWFlow_( InHWFlow ),
   SWFlow_( InSWFlow )
{
}

AnsiString    const
TPortDisp::GetBaudStr
   (
   ) const
{
   return( AnsiString( Baud_ ) );
}

AnsiString    const
TPortDisp::GetPortStr
   (
   ) const
{
   return( AnsiString( "COM" ) + AnsiString( PortNum_ ) );
}

AnsiString    const
TPortDisp::GetNumStopBitsStr
   (
   ) const
{
   AnsiString                Str;
   switch ( StopBits_ )
   {
      case ONESTOPBIT:
         Str               = "1";
         break;
      case TWOSTOPBITS:
         Str               = "2";
         break;
      default:
         Str               = "Unknown";
   }

   return( Str );

}



AnsiString    const
TPortDisp::GetDataBitsStr
   (
   ) const
{
   AnsiString Str;

   switch ( DataBits_ )
   {
      case 7:
         Str               = "7";
         break;
      case 8:
         Str               = "8";
         break;
      default:
         Str               = "Unknown";
   }

   return( Str );

}


AnsiString    const
TPortDisp::GetParityStr
   (
   ) const
{

   AnsiString Str( "None" );

   if ( Parity_ == ODDPARITY )
   {
      Str                  = "Odd";
   }
   else if ( Parity_ == EVENPARITY )
   {
      Str                  = "Even";
   }

   return( Str );

}

AnsiString    const
TPortDisp::GetHwFlowStr
   (
   ) const
{
   return( HWFlow_ ? "On" : "Off" );
}

AnsiString    const
TPortDisp::GetSwFlowStr
   (
   ) const
{
   return( SWFlow_ ? "On" : "Off" );
}


