

const char *TAPMSECSTAT_FNAME        = ( "TAPMSECSTAT" );
const char *TAPMSECBITRESULTS_FNAME  = ( "TAPMSECBITRESULTS" );
const char *TAPMSECCMMND_FNAME       = ( "TAPMSECCMMND" );


 