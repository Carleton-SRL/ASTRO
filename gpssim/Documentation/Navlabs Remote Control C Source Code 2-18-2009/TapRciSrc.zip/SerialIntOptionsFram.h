//---------------------------------------------------------------------------


#ifndef SerialIntOptionsFramH
#define SerialIntOptionsFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: SerialIntOptionsFram.h                                $
//
// $Revision:: 3                                                     $
//
// $History:: SerialIntOptionsFram.h                                 $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:23p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:56p
//Updated in $/TapRci
//Initial checkin.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/30/02    Time: 4:56p
//Created in $/TapRci
//
//
//---------------------------------------------------------------------------

//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include "RzPanel.hpp"
#include <ExtCtrls.hpp>
#include "RzEdit.hpp"
#include "RzSpnEdt.hpp"
#include <Mask.hpp>
#include <Graphics.hpp>
#include "RzCmboBx.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef AcceptInterfaceOptionsH
#include "AcceptInterfaceOptions.h"
#endif


//---------------------------------------------------------------------------
class TSerialIntOptionsFrame : public TFrame, public IAcceptInterfaceOptions
{
__published:
   TRzPanel *SerialTopPnl;
   TOvcLabel *SerialTitle;
   TRzPanel *SerialMainPnl;
   TOvcLabel *SerialPortDescLbl;
   TRzSpinEdit *SerialPortSpinEdit;
   TOvcLabel *SerialStopBitsDescLbl;
   TRzSpinEdit *SerialStopBitsSpinEdit;
   TOvcLabel *SerialBaudDescLbl;
   TImage *Image1;
   TRzComboBox *SerialBaudcbox;
private:

   TTapRciProfile          * TapRciPf;

   void                      SetDisplayFromProfile();
   void                      SetProfileFromDisplay();


public:

   __fastcall                TSerialIntOptionsFrame( TComponent* Owner );
   virtual __fastcall       ~TSerialIntOptionsFrame();

   void                      DoNewOptions( const bool Accept );
   bool const                GetOptionsChanged();

};
//---------------------------------------------------------------------------
extern PACKAGE TSerialIntOptionsFrame *SerialIntOptionsFrame;
//---------------------------------------------------------------------------
#endif
