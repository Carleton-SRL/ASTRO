#ifndef DDTapPciH
#define DDTapPciH

//---------------------------------------------------------------------------
//
// $Workfile:: DDTapPci.h                                            $
//
// $Revision:: 1                                                     $
//
// $History:: DDTapPci.h                                             $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 3:38p
//Created in $/TapRci
//Copied from TapMsec.
//Initial checkin.
//
//
//---------------------------------------------------------------------------


///////////////////////////////////////////////////////////
//  TapPci user application interface
//  Portions Copyright (c) 1996-2000, BlueWater Systems, Inc.
///////////////////////////////////////////////////////////

#define TAPPCI_DEVICE_TYPE              0x8500
#define TAPPCI_MAKE_IOCTL(t,c)\
        (ULONG)CTL_CODE((t), 0x800+(c), METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_TAPPCI_INT_WAIT\
            TAPPCI_MAKE_IOCTL(TAPPCI_DEVICE_TYPE, 0)

#define IOCTL_TAPPCI_MAP_MEM\
            TAPPCI_MAKE_IOCTL(TAPPCI_DEVICE_TYPE, 1)

#define IOCTL_TAPPCI_WRITE_REG\
            TAPPCI_MAKE_IOCTL(TAPPCI_DEVICE_TYPE, 2)

#define IOCTL_TAPPCI_READ_REG\
            TAPPCI_MAKE_IOCTL(TAPPCI_DEVICE_TYPE, 3)

#define IOCTL_TAPPCI_PROG_BOARD\
            TAPPCI_MAKE_IOCTL(TAPPCI_DEVICE_TYPE, 4)

#define IOCTL_TAPPCI_CHIPS_STATUS\
            TAPPCI_MAKE_IOCTL(TAPPCI_DEVICE_TYPE, 5)

#define IOCTL_TAPPCI_QUERY_PROG_BOARD\
            TAPPCI_MAKE_IOCTL(TAPPCI_DEVICE_TYPE, 6)

typedef struct tagMAP_MEMORY_INDEX {
   ULONG    Index;
} MAP_MEMORY_INDEX, *PMAP_MEMORY_INDEX;

typedef struct tagMAP_MEMORY {
   PVOID   Address;
} MAP_MEMORY, *PMAP_MEMORY;

typedef struct tagTAPPCI_WRITE_REG {
   ULONG   RegOffset;
   ULONG   Value;
} TAPPCI_WRITE_REG, *PTAPPCI_WRITE_REG;

typedef struct tagTAPPCI_READ_REG {
   ULONG   RegOffset;
   ULONG   Value;
} TAPPCI_READ_REG, *PTAPPCI_READ_REG;

typedef struct tagTAPPCI_CHIP_STATUS {
   ULONG                     Init;
   ULONG                     Prog;
} TAPPCI_CHIP_STATUS, *PTAPPCI_CHIP_STATUS;

typedef struct tagTAPPCI_CHIPS_STATUS {
   TAPPCI_CHIP_STATUS        x1;
   TAPPCI_CHIP_STATUS        x2;
   TAPPCI_CHIP_STATUS        x3;
} TAPPCI_CHIPS_STATUS, *PTAPPCI_CHIPS_STATUS;

// Since MAX_PATH has changed with time, hard code the max size of the
// file names.
//
#define MAX_TAPPCI_CHIPHEXFILENAME_PATH      ( 400 )
#define TAPPCI_MAX_CHIPS          ( 3 )
typedef struct tagTAPPCI_PROG_CHIP {
   ULONG                     ChipExists;
   char                      ChipHexFilename[MAX_TAPPCI_CHIPHEXFILENAME_PATH];
} TAPPCI_PROG_CHIP, *PTAPPCI_PROG_CHIP;

typedef struct tagTAPPCI_PROG_BOARD {
   ULONG                     ProgramAtStart;
   TAPPCI_PROG_CHIP          ProgChip[TAPPCI_MAX_CHIPS];
} TAPPCI_PROG_BOARD, *PTAPPCI_PROG_BOARD;

//   Defines used in driver and user code

#define TAPPCI_CHIPFILENAME_KEY      ( "ChipHexFilename" )
#define TAPPCI_CHIPEXISTS_KEY        ( "ChipExists" )
#define TAPPCI_PROGRAMATSTART_KEY    ( "ProgramAtStart" )


#endif

