#ifndef PortDispH
#define PortDispH
//---------------------------------------------------------------------------
//
// $Workfile:: PortDisp.h                                            $
//
// $Revision:: 2                                                     $
//
// $History:: PortDisp.h                                             $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/24/04    Time: 12:59p
//Created in $/TapRci
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 1/20/03    Time: 11:22a
//Updated in $/TapMsec
//Add parity, baud, etc.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 7/23/02    Time: 7:50p
//Updated in $/TapMsec
//Added Source Safe keywords
//Changed Rockwell bitmap to 24 x 24
//
//
//
//
//---------------------------------------------------------------------------

typedef struct tagTPortDispDataStr {
   char *Name;
   char *BitmapName;
   char *IconName;
} TPortDispDataStr;

class TPortDispData {
public:
   AnsiString Name;
   AnsiString BitmapName;
   AnsiString IconName;
public:

};

class TPortDisp {
private:

   int                       PortNum_;
   int                       Baud_;
   int                       StopBits_;
   int                       DataBits_;
   int                       Parity_;
   bool                      HWFlow_;
   bool                      SWFlow_;


public:
   TPortDisp( const int PortNum, const int Baud, const int StopBits, const int DataBits, const int Parity, const bool HWFlow, const bool SWFlow );

   TPortDispData const       GetPortDispData( ) const;
   AnsiString    const       GetPortStr( ) const;
   AnsiString    const       GetBaudStr( ) const;
   AnsiString    const       GetNumStopBitsStr( ) const;
   AnsiString    const       GetDataBitsStr( ) const;
   AnsiString    const       GetParityStr( ) const;
   AnsiString    const       GetHwFlowStr( ) const;
   AnsiString    const       GetSwFlowStr( ) const;

   __property TPortDispData PortDispData          = { read = GetPortDispData         };
   __property AnsiString    PortStr               = { read = GetPortStr              };
   __property AnsiString    BaudStr               = { read = GetBaudStr              };
   __property AnsiString    NumStopBitsStr        = { read = GetNumStopBitsStr       };
   __property AnsiString    DataBitsStr           = { read = GetDataBitsStr          };
   __property AnsiString    ParityStr             = { read = GetParityStr            };
   __property AnsiString    HWFlowStr             = { read = GetHwFlowStr            };
   __property AnsiString    SWFlowStr             = { read = GetSwFlowStr            };
   __property int           PortNum               = { read = PortNum_                };
};

#endif

 