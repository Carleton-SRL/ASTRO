#include "pch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: TapMsecPf.cpp                                         $
//
// $Revision:: 3                                                     $
//
// $History:: TapMsecPf.cpp                                          $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:58p
//Updated in $/TapRci
//Default BIT to not test.
//
//
//---------------------------------------------------------------------------


#ifndef TapMsecPfH
#include "TapMsecPf.h"
#endif

//---------------------------------------------------------------------------

static const AnsiString TapMsecSection("TAPMSEC");
static const AnsiString CreateRcvrAsDialogKey("CreateRcvrAsDialog");
static const AnsiString UseGpsTimeForXAxisKey("UseGpsTimeForXAxis");
static const AnsiString ResetErrPlotOnTimeResetKey("ResetErrPlotOnTimeReset");
static const AnsiString AttenIncrementKey("AttenIncrement");
static const AnsiString ShowDebugKey("ShowDebug");
static const AnsiString LogMissedIntsKey("LogMissedInts");
static const AnsiString DispRelativePowerKey( "DispRelativePower" );


static const AnsiString PTSection("TAPPTINIT");

static const AnsiString PTLatKey("Lat");
static const AnsiString PTLonKey("Lon");
static const AnsiString PTAltKey("Alt");
static const AnsiString PTDateKey("Date");
static const AnsiString PTTimeKey("Time");
static const AnsiString PTInitFromClockKey("InitFromClock");
static const AnsiString PTRefLocalTimeKey("RefLocalTime");

static const AnsiString DefLatStr("34.000000");
static const AnsiString DefLonStr("-118.000000");
static const AnsiString DefAltStr("0.00");
static const AnsiString DefDateStr("1/30/2001");
static const AnsiString DefTimeStr("12:00:00");
static const int        DefInitFromClock(1);
static const int        DefRefLocalTime(1);
static const int        DefShowDebug(0);
static const int        DefLogMissedInts(0);
static const int        DefDispRelativePower( 1 );

static const AnsiString SyncToSkySection("SYNCTOSKY");

static const AnsiString PPSSection( "PPS" );
static const AnsiString PPSWidthKey( "PPSWidth" );
static const AnsiString PPSAlwaysOnKey( "PPSAlwaysOn" );

static const int        PPSWidthDef( 1 );
static const int        PPSAlwaysOnDef( 0 );

//---------------------------------------------------------------------------
// BIT Section
//
static const AnsiString BitSection( "BIT" );

static const AnsiString TestX1Key( "TestX1" );
static const int        TestX1Def( 0 );
static const AnsiString TestX2Key( "TestX2" );
static const int        TestX2Def( 0 );
static const AnsiString TestX3Key( "TestX3" );
static const int        TestX3Def( 0 );
static const AnsiString TestIntKey( "TestInt" );
static const int        TestIntDef( 0 );
static const AnsiString TestOcxoKey( "TestOcxo" );
static const int        TestOcxoDef( 0 );
static const AnsiString TestPllKey( "TestPll" );
static const int        TestPllDef( 0 );


TTapMsecProfile::TTapMsecProfile() : TIniFile("Voyager.ini")
{}

double const
TTapMsecProfile::GetAttenIncrement()
{
   return(ReadFloat(TapMsecSection,AttenIncrementKey,0.5));
}

void
TTapMsecProfile::WriteAttenIncrement
   (
   const double AttenIncrement
   )
{
   WriteFloat(TapMsecSection,AttenIncrementKey,AttenIncrement);
}
bool const
TTapMsecProfile::IsCreateRcvrAsDialog
   (

   )
{
   return(ReadInteger(TapMsecSection,CreateRcvrAsDialogKey,1));
}
void
TTapMsecProfile::WriteCreateRcvrAsDialog
   (
   const bool CreateRcvrAsDialog
   )
{
   WriteInteger(TapMsecSection,CreateRcvrAsDialogKey,CreateRcvrAsDialog);
}

bool const
TTapMsecProfile::IsUseGpsTimeForXAxis
   (

   )
{
   return(ReadInteger(TapMsecSection,UseGpsTimeForXAxisKey,0));
}
void
TTapMsecProfile::WriteUseGpsTimeForXAxis
   (
   const bool UseGpsTime
   )
{
   WriteInteger(TapMsecSection,UseGpsTimeForXAxisKey,UseGpsTime);
}

bool const
TTapMsecProfile::IsResetErrPlotOnTimeReset
   (

   )
{
   return(ReadInteger(TapMsecSection,ResetErrPlotOnTimeResetKey,0));
}
void
TTapMsecProfile::WriteResetErrPlotOnTimeReset
   (
   const bool Reset
   )
{
   WriteInteger(TapMsecSection,ResetErrPlotOnTimeResetKey,Reset);
}

void
TTapMsecProfile::GetPos
   (
   double &Lat,
   double &Lon,
   double &Alt
   )
{

   AnsiString LatStr = ReadString(PTSection,PTLatKey,DefLatStr);
   AnsiString LonStr = ReadString(PTSection,PTLonKey,DefLonStr);
   AnsiString AltStr = ReadString(PTSection,PTAltKey,DefAltStr);

   Lat = LatStr.ToDouble();
   Lon = LonStr.ToDouble();
   Alt = AltStr.ToDouble();

}

TDateTime const
TTapMsecProfile::GetDate
   (
   )
{


   AnsiString DateStr = ReadString(PTSection,PTDateKey,TDateTime::CurrentDate().DateString());
   if ( !DateStr.Length() )
   {
      DateStr = TDateTime::CurrentDate().DateString();
   }

   return ( StrToDate( DateStr ) );

}

TDateTime const
TTapMsecProfile::GetTime
   (
   )
{

   AnsiString TimeStr = ReadString(PTSection,PTTimeKey,TDateTime::CurrentTime().TimeString());

   return ( StrToTime( TimeStr ) );

}

bool const
TTapMsecProfile::GetInitFromClock
   (
   )
{

   return( ReadInteger( PTSection, PTInitFromClockKey, DefInitFromClock ) );

}

void
TTapMsecProfile::SetPos
   (
   double Lat,
   double Lon,
   double Alt
   )
{

   char Str[100];
   sprintf(Str,"%12.7lf",Lat);
   WriteString( PTSection, PTLatKey, AnsiString(Str) );

   sprintf(Str,"%12.7lf",Lon);
   WriteString( PTSection, PTLonKey, AnsiString(Str) );

   sprintf(Str,"%10.2lf",Alt);
   WriteString( PTSection, PTAltKey, AnsiString(Str) );

}

void
TTapMsecProfile::SetDate
   (
   const TDateTime &Date
   )
{

   WriteString( PTSection, PTDateKey, Date.DateString() );

}

void
TTapMsecProfile::SetTime
   (
   const TDateTime &Time
   )
{

   WriteString( PTSection, PTTimeKey, Time.TimeString() );

}

void
TTapMsecProfile::SetInitFromClock
   (
   bool InitFromClock
   )
{

   WriteInteger(PTSection,PTInitFromClockKey,InitFromClock);

}

void
TTapMsecProfile::SetRefLocalTime
   (
   bool RefLocalTime
   )
{

   WriteInteger(PTSection,PTRefLocalTimeKey,RefLocalTime);

}

bool const
TTapMsecProfile::GetRefLocalTime
   (
   )
{

   return( ReadInteger( PTSection, PTRefLocalTimeKey, DefRefLocalTime ) );

}


bool const
TTapMsecProfile::IsShowDebug
   (
   
   )
{
   return( ReadInteger( TapMsecSection, ShowDebugKey, DefShowDebug ) );
}

bool const
TTapMsecProfile::IsLogMissedInts
   (

   )
{
   return( ReadInteger( TapMsecSection, LogMissedIntsKey, DefLogMissedInts ) );
}


bool const
TTapMsecProfile::IsDispRelativePower
   (

   )
{
   return( ReadInteger( TapMsecSection, DispRelativePowerKey, DefDispRelativePower ) );
}

void
TTapMsecProfile::WriteDispRelativePower
   (
   const bool DispRelativePower
   )
{
   WriteInteger( TapMsecSection, DispRelativePowerKey, DispRelativePower );
}

bool const
TTapMsecProfile::IsPPSAlwaysOn()
{
   return( ReadInteger( PPSSection, PPSAlwaysOnKey, PPSAlwaysOnDef ) );
}

int const
TTapMsecProfile::GetPPSWidth()
{
   return( ReadInteger( PPSSection, PPSWidthKey, PPSWidthDef ) );
}

void
TTapMsecProfile::WritePPSAlwaysOn
   (
   const bool PPSAlwaysOn
   )
{
   WriteInteger( PPSSection, PPSAlwaysOnKey, PPSAlwaysOn );
}

void
TTapMsecProfile::WritePPSWidth
   (
   const int PPSWidth
   )
{
   WriteInteger( PPSSection, PPSWidthKey, PPSWidth );
}

bool const
TTapMsecProfile::IsBitTestX1()
{
   return( ReadInteger( BitSection, TestX1Key, TestX1Def ) );
}

void
TTapMsecProfile::WriteBitTestX1
   (
   const bool TestX1
   )
{
   WriteInteger( BitSection, TestX1Key, TestX1 );
}

bool const
TTapMsecProfile::IsBitTestX2()
{
   return( ReadInteger( BitSection, TestX2Key, TestX2Def ) );
}

void
TTapMsecProfile::WriteBitTestX2
   (
   const bool TestX2
   )
{
   WriteInteger( BitSection, TestX2Key, TestX2 );
}

bool const
TTapMsecProfile::IsBitTestX3()
{
   return( ReadInteger( BitSection, TestX3Key, TestX3Def ) );
}

void
TTapMsecProfile::WriteBitTestX3
   (
   const bool TestX3
   )
{
   WriteInteger( BitSection, TestX3Key, TestX3 );
}

bool const
TTapMsecProfile::IsBitTestInt()
{
   return( ReadInteger( BitSection, TestIntKey, TestIntDef ) );
}

void
TTapMsecProfile::WriteBitTestInt
   (
   const bool TestInt
   )
{
   WriteInteger( BitSection, TestIntKey, TestInt );
}

bool const
TTapMsecProfile::IsBitTestOcxo()
{
   return( ReadInteger( BitSection, TestOcxoKey, TestOcxoDef ) );
}

void
TTapMsecProfile::WriteBitTestOcxo
   (
   const bool TestOcxo
   )
{
   WriteInteger( BitSection, TestOcxoKey, TestOcxo );
}

bool const
TTapMsecProfile::IsBitTestPll()
{
   return( ReadInteger( BitSection, TestPllKey, TestPllDef ) );
}

void
TTapMsecProfile::WriteBitTestPll
   (
   const bool TestPll
   )
{
   WriteInteger( BitSection, TestPllKey, TestPll );
}

