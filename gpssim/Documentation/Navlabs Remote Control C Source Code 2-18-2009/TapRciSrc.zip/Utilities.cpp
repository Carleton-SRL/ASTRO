#include "pch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: Utilities.cpp                                         $
//
// $Revision:: 2                                                     $
//
// $History:: Utilities.cpp                                          $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:04p
//Updated in $/TapRci
//Add Source Safe keywords.
//Changed include file guard to match standard filenameH format.
//
//
//---------------------------------------------------------------------------


#ifndef UtilitiesH
#include "Utilities.h"
#endif


///////////////////////////////////////////////////////////////////////////////
// IsValidScenario
//   This function returns true if the given scenario is valid.
///////////////////////////////////////////////////////////////////////////////
bool const
IsValidScenario
   (
   const AnsiString        & ScenarioRoot
   )
{
   char CurrentDir[MAX_PATH];
   bool CurrentDirValid = ( getcwd( CurrentDir, MAX_PATH ) != NULL );

   chdir( ScenarioRoot.c_str() );
   std::ifstream ValidBuild("ValidBld.scn");
   int ValidScen=0;
   ValidBuild >> ValidScen;
   if ( CurrentDirValid )
   {
      chdir(CurrentDir);
   }
   ValidBuild.close();
   return( ValidScen != 0 && ValidBuild.good() );
}


 