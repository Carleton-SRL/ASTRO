#ifndef GpibH
#define GpibH

//---------------------------------------------------------------------------
//
// $Workfile:: Gpib.h                                                $
//
// $Revision:: 2                                                     $
//
// $History:: Gpib.h                                                 $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:35p
//Updated in $/TapRci
//Initial release.
//
//
//---------------------------------------------------------------------------


#ifndef RemoteTypesH
#include "RemoteTypes.h"
#endif

#ifndef InterfaceH
#include "Interface.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef GpibInterfaceStatusFramH
#include "GpibInterfaceStatusFram.h"
#endif

class TGpibThread : public TThread {
private:

   TTapRciProfile                      * TapRciPf;
   int                                   BoardIndex_;
   int                                   PrimaryAddress_;
   int                                   SecondaryAddress_;
   int                                   Timeout_;
   bool                                  ValidInterface_;
   int                                   Board_;
   TCriticalSection                    * ReadCriticalSection;
   TCriticalSection                    * WriteCriticalSection;
   TCriticalSection                    * StrCriticalSection;
   HANDLE                                hTimer;
   TMsgData                              QueuedOutMsgData;
   TMsgData                              QueuedInMsgData;
   AnsiString                            StatusStr_;
   TEvent                              * EventSendDataGpib;
   TEvent                              * EventReceiveDataInterface;
   int                                   Dev;
   // Debug
//   std::deque<AnsiString>                StatusStrQ_;
//   void                                  AddStatus( const AnsiString & );
//   ofstream                              DebugStream;

   bool const                            WriteQueuedMsgData();
   void                                  AddInMsgDataQueue( TMsgData & );
   void                                  ReadMsgData( TMsgData & );
   bool const                            SendMsgData( const TMsgData & );

   AnsiString const                      GetStatusStr();
   void                                  SetStatusStr( const AnsiString & InStatusStr );

   AnsiString const                      GetParametersStr();
   void                                  SetParametersStr( const AnsiString & InParametersStr );

   void                                  SetupTimer();

   void                                  WaitDebugProcessing( const int WaitResult );

   void                                  ReportError( const AnsiString & PreStr );

protected:

   void __fastcall                       Execute();

public:

   TGpibThread();
   __fastcall ~TGpibThread();

   bool const                            QueueMsgData( const TMsgData & Msg );
   bool const                            GetMsgData( TMsgData & Msg );
   bool const                            InitializeSocket();

   __property int            BoardIndex                = { read = BoardIndex_,                  write = BoardIndex_                  };
   __property int            PrimaryAddress            = { read = PrimaryAddress_,              write = PrimaryAddress_              };
   __property int            SecondaryAddress          = { read = SecondaryAddress_,            write = SecondaryAddress_            };
   __property int            Timeout                   = { read = Timeout_,                     write = Timeout_                     };
   __property int            Board                     = { read = Board_,                                                            };
   __property bool           ValidInterface            = { read = ValidInterface_                                                    };
   __property AnsiString     StatusStr                 = { read = GetStatusStr,                 write = SetStatusStr                 };
   __property AnsiString     ParametersStr             = { read = GetParametersStr,             write = SetParametersStr             };

};




//---------------------------------------------------------------------------
class TGpib : public TInterface  {
private:

   TGpibThread               * GpibThread;
   TGpibInterfaceStatusFrame * GpibStatusFrame;
   TComponent                * Owner;

   void                      ReportError( const AnsiString & PreStr );
   int        const          GetBoardIndex() const     { return( GpibThread ? GpibThread->BoardIndex     : 0 ); }
   int        const          GetPrimaryAddress() const { return( GpibThread ? GpibThread->PrimaryAddress : 0 ); }
   int        const          GetTimeout() const        { return( GpibThread ? GpibThread->Timeout        : 0 ); }
   bool       const          GetValidInterface() const { return( GpibThread ? GpibThread->ValidInterface : 0 ); }
   AnsiString const          GetStatusStr() const;
   AnsiString const          GetParametersStr() const;

protected:

   TTapRciProfile          * TapRciPf;

   bool const                SendMsg( const TMsgData &MsgData );
   void                      ReadMsg( TMsgData &MsgData );
   bool const                InitCommunication( );

public:

   TGpib( TComponent * Owner );
   virtual __fastcall ~TGpib();

   __property bool       ValidInterface        = { read = GetValidInterface                            };
   __property int        BoardIndex            = { read = GetBoardIndex,                               };
   __property int        PrimaryAddress        = { read = GetPrimaryAddress,                           };
   __property int        Timeout               = { read = GetTimeout                                   };
   __property AnsiString StatusStr             = { read = GetStatusStr                                 };

};

//---------------------------------------------------------------------------

#if(0)

 ifdefed out -- Multi threaded GPIB code from TapMsec

#ifndef RtInterfaceH
#include "RtInterface.h"
#endif

#ifndef ReportErrorH
#include "ReportError.h"
#endif

#ifndef TapMsecPfH
#include "TapMsecPf.h"
#endif


class TGpibThread : public TThread {
private:

   TTapMsecProfile                     * TapMsecPf;
   int                                   BoardIndex_;
   int                                   PrimaryAddress_;
   int                                   SecondaryAddress_;
   int                                   Timeout_;
   bool                                  ValidInterface_;
   bool                                  WriteError_;
   TReportError                        * Report;
   TCriticalSection                    * ReadCriticalSection;
   TCriticalSection                    * WriteCriticalSection;
   TCriticalSection                    * StrCriticalSection;
   HANDLE                                hTimer;
   TMsgData                              QueuedOutMsgData;
   TMsgData                              QueuedInMsgData;
   AnsiString                            StatusStr_;
   TEvent                              * EventSendData;
   int                                   Dev;

   bool const                            WriteQueuedMsgData();
   void                                  AddInMsgDataQueue( TMsgData & );
   void                                  ReadMsgData( TMsgData & );
   bool const                            SendMsgData( const TMsgData & );
   AnsiString const                      GetStatusStr();
   void                                  SetStatusStr( const AnsiString & InStatusStr );
   AnsiString const                      GetParametersStr();
   void                                  SetParametersStr( const AnsiString & InParametersStr );
   void                                  SetupTimer();
   void                                  WaitDebugProcessing( const int WaitResult );

protected:

   void __fastcall                       Execute();

public:

   TGpibThread();
   __fastcall ~TGpibThread();

   bool const                            QueueMsgData( const TMsgData & Msg );
   bool const                            GetMsgData( TMsgData & Msg );
   bool const                            InitializeSocket();

   __property int            BoardIndex                = { read = BoardIndex_,                  write = BoardIndex_                  };
   __property int            PrimaryAddress            = { read = PrimaryAddress_,              write = PrimaryAddress_              };
   __property int            SecondaryAddress          = { read = SecondaryAddress_,            write = SecondaryAddress_            };
   __property bool           ValidInterface            = { read = ValidInterface_                                                    };
   __property AnsiString     StatusStr                 = { read = GetStatusStr,                 write = SetStatusStr                 };
   __property AnsiString     ParametersStr             = { read = GetParametersStr,             write = SetParametersStr             };
   __property bool           WriteError                = { read = WriteError_                                                        };

};

class TGpib : public IRtInterface {
private:

   bool                      Valid_;
   TReportError            * Report;
   TGpibThread             * GpibThread;

protected:

   AnsiString const          GetStatusStr();
   AnsiString const          GetParametersStr();


public:
   TGpib( );
   virtual _fastcall ~TGpib();

   bool const                IsValid() const { return( Valid_ ); };
   void                      GetData( TMsgData &Data );
   bool const                SendMsg( const TOutMsg &OutMsg );
   bool const                InitCommunication( );


};

#endif

#endif

