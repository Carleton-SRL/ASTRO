#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: ChanStatFram.cpp                                      $
//
// $Revision:: 5                                                     $
//
// $History:: ChanStatFram.cpp                                       $
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:17p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:18p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:29p
//Updated in $/TapRci
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------

#ifndef ChanStatFramH
#include "ChanStatFram.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "RzLabel"
#pragma link "RzBorder"
#pragma resource "*.dfm"
TChanStatFrame *ChanStatFrame;
//---------------------------------------------------------------------------
__fastcall
TChanStatFrame::TChanStatFrame
   (
   TComponent              * Owner,
   const int                 InChanNum,
   const bool                InDispRelative
   ) :
   TFrame( Owner ),
   ChanNum( InChanNum ),
   DispRelative( InDispRelative )
{

   TTapMsecStatChan TapMsecStatChan( ChanNum );

   SetChanStat( TapMsecStatChan );

}

void
TChanStatFrame::SetDispRelativePower
   (
   const bool                InDispRelative
   )
{

   DispRelative = InDispRelative;
   DispChanStat();

}


void
TChanStatFrame::SetChanStat
   (
   const TTapMsecStatChan  & InChanStat
   )
{

   ChanStat = InChanStat;

   DispChanStat();

}

void
TChanStatFrame::DispChanStat
   (
   )
{

   if ( ChanStat.Chan >= 0 )
   {

      ChLbl->Caption            = ChanStat.Chan + 1;

      if ( ChanStat.Svid )
      {

         SvidLbl->Caption       = ChanStat.Svid;

         AnsiString L1PowerStr;
         AnsiString L2PowerStr;
         L1PowerLbl->Caption    = L1PowerStr.sprintf( "%4.1lf", DispRelative ? ChanStat.L1Power : ChanStat.L1Atten );
         L2PowerLbl->Caption    = L2PowerStr.sprintf( "%4.1lf", DispRelative ? ChanStat.L2Power : ChanStat.L2Atten );

         ElLbl->Caption         = AnsiString( NINT( ChanStat.El ) );
         AzLbl->Caption         = AnsiString( NINT( ChanStat.Az ) );

      }
      else
      {

         SvidLbl->Caption       = "";
         L1PowerLbl->Caption    = "";
         L2PowerLbl->Caption    = "";
         ElLbl->Caption         = "";
         AzLbl->Caption         = "";

      }

   }
   else
   {
      Visible = false;
   }

}

//---------------------------------------------------------------------------
