//---------------------------------------------------------------------------

#ifndef ComPortInterfaceH
#define ComPortInterfaceH
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//
// $Workfile:: ComPortInterface.h                                    $
//
// $Revision:: 2                                                     $
//
// $History:: ComPortInterface.h                                     $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/24/04    Time: 12:18p
//Created in $/TapRci
//
//
//---------------------------------------------------------------------------



#ifndef InterfaceH
#include "Interface.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef ComPortInterfaceStatusFramH
#include "ComPortInterfaceStatusFram.h"
#endif

#ifndef PortDispH
#include "PortDisp.h"
#endif


//---------------------------------------------------------------------------
class TComPortInterface : public TInterface  {
private:

   TComPortInterfaceStatusFrame * ComPortInterfaceFrame_;
   TTapRciProfile          * TapRciPf_;
   bool                      Valid_;
   HANDLE                    ComHandle;

   int                       BytesRcvd_;
   int                       BytesXmtd_;
   int                       Port_;
   int                       Baud_;
   BYTE                      StopBits_;
   BYTE                      Parity_;
   BYTE                      DataBits_;
   bool                      HWFlow_;
   bool                      SWFlow_;

   TPortDisp               * PortDisp_;

   // Properties
   int const                 GetBytesRcvd() const { return( BytesRcvd_ ); }
   void                      SetBytesRcvd( const int InBytesRcvd );
   int const                 GetBytesXmtd() const { return( BytesXmtd_ ); }
   void                      SetBytesXmtd( const int InBytesXmtd );

   int const                 GetBaud() const { return( Baud_ ); }
   int const                 GetStopBits() const { return( StopBits_ ); }
   int const                 GetDataBits() const { return( DataBits_ ); }
   AnsiString const          GetParity() const;
   bool const                GetHWFlow() const { return( HWFlow_ ); }
   bool const                GetSWFlow() const { return( SWFlow_ ); }


   bool const                OpenComPort();


protected:

   bool const                SendMsg( const TMsgData &MsgData );
   void                      ReadMsg( TMsgData &MsgData );
   bool const                GetValidInterface() const { return( Valid_ ); }


public:

   TComPortInterface( TComponent * InOwner );
   virtual __fastcall ~TComPortInterface();

   __property int            Baud         = { read = GetBaud              };
   __property int            StopBits     = { read = GetStopBits          };
   __property int            DataBits     = { read = GetDataBits          };
   __property AnsiString     Parity       = { read = GetParity            };
   __property bool           HWFlow       = { read = GetHWFlow            };
   __property bool           SWFlow       = { read = GetSWFlow            };
   __property int            BytesRcvd    = { read = GetBytesRcvd, write = SetBytesRcvd };
   __property int            BytesXmtd    = { read = GetBytesXmtd, write = SetBytesXmtd };

};

#endif
