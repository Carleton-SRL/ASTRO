#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: SerialIntOptionsFram.cpp                              $
//
// $Revision:: 4                                                     $
//
// $History:: SerialIntOptionsFram.cpp                               $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:40p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:23p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:56p
//Updated in $/TapRci
//Initial checkin.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/30/02    Time: 4:56p
//Created in $/TapRci
//
//
//---------------------------------------------------------------------------


#ifndef SerialIntOptionsFramH
#include "SerialIntOptionsFram.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ovclabel"
#pragma link "RzPanel"
#pragma link "RzEdit"
#pragma link "RzSpnEdt"
#pragma link "RzCmboBx"
#pragma resource "*.dfm"
TSerialIntOptionsFrame *SerialIntOptionsFrame;
//---------------------------------------------------------------------------

static const int NumSerialBaudRates                  = 12;
static const int SerialBaudRates[NumSerialBaudRates] = { 1200, 2400, 4800, 9600, 14400, 19200, 38400, 56000, 57600, 115200, 128000, 256000 };

__fastcall
TSerialIntOptionsFrame::TSerialIntOptionsFrame
   (
   TComponent              * Owner
   ) :
   TFrame( Owner ),
   TapRciPf( NULL )
{

   TapRciPf                  = new TTapRciProfile();

   SetDisplayFromProfile();

}

__fastcall
TSerialIntOptionsFrame::~TSerialIntOptionsFrame
   (
   )
{
   delete TapRciPf;
}

void
TSerialIntOptionsFrame::SetDisplayFromProfile
   (
   )
{

   SerialPortSpinEdit->Value     = TapRciPf->SerialComPort;
   SerialStopBitsSpinEdit->Value = TapRciPf->SerialStopBits;
   int Baud                      = TapRciPf->SerialBaud;
   for ( int i=0; i<NumSerialBaudRates; ++i )
   {
      if ( SerialBaudRates[i] == Baud )
      {
         SerialBaudcbox->ItemIndex     = i;
         break;
      }
   }

}   

void
TSerialIntOptionsFrame::SetProfileFromDisplay
   (
   )
{

   TapRciPf->SerialComPort       = SerialPortSpinEdit->Value;
   TapRciPf->SerialStopBits      = SerialStopBitsSpinEdit->Value;
   TapRciPf->SerialBaud          = SerialBaudRates[ SerialBaudcbox->ItemIndex ];

}

void
TSerialIntOptionsFrame::DoNewOptions
   (
   const bool                Accept
   )
{

   if ( Accept )
   {
      SetProfileFromDisplay();
   }
   else
   {
      SetDisplayFromProfile();
   }

}   

bool const
TSerialIntOptionsFrame::GetOptionsChanged
   (
   )
{

   bool Changed         = false;
   try
   {

      Changed          |= TapRciPf->SerialComPort  != SerialPortSpinEdit->Value;
      Changed          |= TapRciPf->SerialStopBits != SerialStopBitsSpinEdit->Value;
      Changed          |= TapRciPf->SerialBaud     != SerialBaudRates[ SerialBaudcbox->ItemIndex ];

   }
   catch(...)
   {
      CodeSite->SendMsg( csmError, "TSerialIntOptionsFrame::GetOptionsChanged exception" );
   }

   return( Changed );

}   


 