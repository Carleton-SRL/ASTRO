#ifndef UtilitiesH
#define UtilitiesH

//---------------------------------------------------------------------------
//
// $Workfile:: Utilities.h                                           $
//
// $Revision:: 2                                                     $
//
// $History:: Utilities.h                                            $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:04p
//Updated in $/TapRci
//Add Source Safe keywords.
//Changed include file guard to match standard filenameH format.
//
//
//---------------------------------------------------------------------------


bool const
IsValidScenario
   (
   const AnsiString        & ScenarioRoot
   );

#endif   

 