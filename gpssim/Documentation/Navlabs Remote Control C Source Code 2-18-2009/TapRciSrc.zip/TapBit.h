#ifndef TapBitH
#define TapBitH

//---------------------------------------------------------------------------
//
// $Workfile:: TapBit.h                                              $
//
// $Revision:: 1                                                     $
//
// $History:: TapBit.h                                               $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/29/02    Time: 5:29p
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------



//-----------------------------------------------------------------------------
// Bit Results
//

class TTapBitBase {
private:

   bool                      Required;
   bool                      Tested;
   bool                      Passed;

public:

   TTapBitBase() : Required( false ), Tested( false ), Passed( false ) {}

   virtual bool const        IsPassed() const { return( Passed ); }
   virtual bool const        IsTested() const { return( Tested ); }
   virtual bool const        IsRequired() const { return( Required ); }
   virtual void              SetRequired( const bool InRequired ) { Required = InRequired; }
   virtual void              SetPassed( const bool InPassed ) { Passed = InPassed; }
   virtual void              SetTested( const bool InTested ) { Tested = InTested; }

};

class TTapBitXChip : public TTapBitBase {
private:

   bool                      Init;
   bool                      Done;

public:

   TTapBitXChip() : Init( false ), Done( false ) {}

   virtual bool const        IsPassed() const { return( IsDone() && IsInit() ); }
   bool const                IsInit() const { return ( Init ); }
   bool const                IsDone() const { return ( Done ); }
   virtual void              SetInit( const bool InInit ) { Init = InInit; }
   virtual void              SetDone( const bool InDone ) { Done = InDone; }

};

class TTapBitResults {
public:

   bool                      Valid;
   TTapBitXChip              x1;
   TTapBitXChip              x2;
   TTapBitXChip              x3;
   TTapBitBase               Interrupt;
   TTapBitBase               Ocxo;
   TTapBitBase               Pll;
   TDateTime                 DateTime;

public:

   TTapBitResults() : Valid( false ) {}

   bool const BitPassed()
   {
      bool Passed = true;
      if ( !Valid ) Passed = false;
      if ( x1.IsRequired() && !x1.IsPassed() ) Passed = false;
      if ( x2.IsRequired() && !x2.IsPassed() ) Passed = false;
      if ( x3.IsRequired() && !x3.IsPassed() ) Passed = false;
      if ( Interrupt.IsRequired() && !Interrupt.IsPassed() ) Passed = false;
      if ( Ocxo.IsRequired() && !Ocxo.IsPassed() ) Passed = false;
      if ( Pll.IsRequired() && !Pll.IsPassed() ) Passed = false;

      return( Passed );
   }

   friend bool const operator==( const TTapBitResults &cp1, const TTapBitResults &cp2 )
   {
      bool Same = true;
      if ( cp1.x1.IsRequired() )
      {
         if ( cp1.x1.IsPassed() != cp2.x1.IsPassed() )
         {
            Same = false;
         }
      }
      if ( cp1.x2.IsRequired() )
      {
         if ( cp1.x2.IsPassed() != cp2.x2.IsPassed() )
         {
            Same = false;
         }
      }
      if ( cp1.x3.IsRequired() )
      {
         if ( cp1.x3.IsPassed() != cp2.x3.IsPassed() )
         {
            Same = false;
         }
      }
      if ( cp1.Interrupt.IsRequired() )
      {
         if ( cp1.Interrupt.IsPassed() != cp2.Interrupt.IsPassed() )
         {
            Same = false;
         }
      }
      if ( cp1.Ocxo.IsRequired() )
      {
         if ( cp1.Ocxo.IsPassed() != cp2.Ocxo.IsPassed() )
         {
            Same = false;
         }
      }
      if ( cp1.Pll.IsRequired() )
      {
         if ( cp1.Pll.IsPassed() != cp2.Pll.IsPassed() )
         {
            Same = false;
         }
      }

      return( Same );

   }
   friend bool const operator!=( const TTapBitResults &cp1, const TTapBitResults &cp2 )
   {
      return( !( cp1 == cp2 ) );
   }
};




#endif

