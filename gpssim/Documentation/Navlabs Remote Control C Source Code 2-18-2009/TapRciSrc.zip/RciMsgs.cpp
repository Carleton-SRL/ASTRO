#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: RciMsgs.cpp                                           $
//
// $Revision:: 8                                                     $
//
// $History:: RciMsgs.cpp                                            $
//
//*****************  Version 8  *****************
//User: Michael Wade Date: 3/17/05    Time: 3:08p
//Updated in $/TapRci
//Add floating point power/attenuation
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Add StartScen based on start pulse.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 1/16/04    Time: 10:43p
//Updated in $/TapRci
//Add "SetL2Atten" message.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:26p
//Updated in $/TapRci
//Add TimeSetPulse external to sim message.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:37p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:53p
//Updated in $/TapRci
//Add RF Gain/Atten.
//Add REGENSCEN.
//
//
//---------------------------------------------------------------------------


#ifndef RciMsgsH
#include "RciMsgs.h"
#endif

static const AnsiString Comma( "," );

static const AnsiString AckMsgValidStr( "MSGVALID" );
static const AnsiString AckMsgInvalidStr( "MSGINVALID" );
static const AnsiString AckSimModeValidStr( "SIMMODEVALID" );
static const AnsiString AckSimModeInvalidStr( "SIMMODEINVALID" );

static const AnsiString SysCfgL1OnlyStr( "L1" );
static const AnsiString SysCfgL2CapableStr( "L1/L2" );

TExtToSim::TExtToSim
   (
   const TInMsg &InMsg
   ) :
   Fields( NULL ),
   Valid_( false )
{
   ( *this ) = InMsg;
}

TExtToSim &
TExtToSim::operator=
   (
   const TInMsg &InMsg
   )
{
   Fields = new TStringList();

   InMsg.GetFields( Fields );

   return( *this );
}

TExtToSim::~TExtToSim
   (
   )
{
   delete Fields;
}

//-----------------------------------------------------------------------------
// StartScen
//
TStartScenMsg::TStartScenMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TStartScenMsg &
TStartScenMsg::operator=
   (
   const TInMsg &InMsg
   )
{


   try
   {
      ScenName = Fields->Strings[0];
      Valid_   = true;
   }
   catch(...)
   {
      Valid_   = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// StartScenStartPulse
//
TStartScenStartPulseMsg::TStartScenStartPulseMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TStartScenStartPulseMsg &
TStartScenStartPulseMsg::operator=
   (
   const TInMsg &InMsg
   )
{


   try
   {
      ScenName = Fields->Strings[0];
      Valid_   = true;
   }
   catch(...)
   {
      Valid_   = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// RegenScen
//
TRegenScenMsg::TRegenScenMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TRegenScenMsg &
TRegenScenMsg::operator=
   (
   const TInMsg &InMsg
   )
{


   try
   {
      ScenName = Fields->Strings[0];
      Valid_   = true;
   }
   catch(...)
   {
      Valid_   = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// Exec
//
TExecMsg::TExecMsg
   (
   const TInMsg            & InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this )               = InMsg;

}

TExecMsg &
TExecMsg::operator=
   (
   const TInMsg            & InMsg
   )
{


   try
   {
      ExecParams           = Fields->Strings[0];
      Valid_               = true;
   }
   catch(...)
   {
      Valid_               = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// InitGeo
//
TInitGeoMsg::TInitGeoMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg ),
   Lat_( 0 ),
   Lon_( 0 ),
   Alt_( 0 ),
   Date_( TDateTime::CurrentDate() ),
   Time_( TDateTime::CurrentTime() )
{

   ( *this ) = InMsg;

}

TInitGeoMsg &
TInitGeoMsg::operator=
   (
   const TInMsg            & InMsg
   )
{

   TStringList *Fields       = new TStringList();

   InMsg.GetFields( Fields );

   try
   {

      int FieldIndex         = 0;
      AnsiString LatStr      = Fields->Strings[FieldIndex++];
      AnsiString LatRefStr   = Fields->Strings[FieldIndex++];
      AnsiString LonStr      = Fields->Strings[FieldIndex++];
      AnsiString LonRefStr   = Fields->Strings[FieldIndex++];
      AnsiString AltStr      = Fields->Strings[FieldIndex++];
      AnsiString TimeStr     = Fields->Strings[FieldIndex++];
      AnsiString DateStr     = Fields->Strings[FieldIndex++];

      LatStr.Trim();
      LatRefStr.Trim();
      LonStr.Trim();
      LonRefStr.Trim();
      AltStr.Trim();
      TimeStr.Trim();
      DateStr.Trim();

      Lat_                   = LatStr.ToDouble();
      if ( LatRefStr == 'S' || LatRefStr == 's' )
      {
         Lat_                = -Lat;
      }

      Lon_                   = LonStr.ToDouble();
      if ( LonRefStr == 'W' || LonRefStr == 'w' )
      {
         Lon_                = -Lon_;
      }

      Alt_                   = AltStr.ToDouble();

      // Time
      //
      AnsiString HoursStr    = TimeStr.SubString( 1, 2 );
      AnsiString MinutesStr  = TimeStr.SubString( 3, 2 );
      AnsiString SecondsStr  = TimeStr.SubString( 5, 2 );

      int Hours              = HoursStr.ToInt();
      int Minutes            = MinutesStr.ToInt();
      int Seconds            = SecondsStr.ToInt();

      Time_                  = TDateTime( (unsigned short) Hours, (unsigned short) Minutes, (unsigned short) Seconds, 0 );

      // Date
      //
      AnsiString DayStr      = DateStr.SubString( 1, 2 );
      AnsiString MonthStr    = DateStr.SubString( 3, 2 );
      AnsiString YearStr     = DateStr.SubString( 5, 4 );

      int Day                = DayStr.ToInt();
      int Month              = MonthStr.ToInt();
      int Year               = YearStr.ToInt();

      Date_                  = TDateTime( (unsigned short) Year, (unsigned short) Month, (unsigned short) Day );

      Valid_                 = true;

   }
   catch(...)
   {
      Valid_                 = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// TimeSetPulse
//
TTimeSetPulseMsg::TTimeSetPulseMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg ),
   Lat_( 0 ),
   Lon_( 0 ),
   Alt_( 0 ),
   Date_( TDateTime::CurrentDate() ),
   Time_( TDateTime::CurrentTime() )
{

   ( *this ) = InMsg;

}

TTimeSetPulseMsg &
TTimeSetPulseMsg::operator=
   (
   const TInMsg            & InMsg
   )
{

   TStringList *Fields       = new TStringList();

   InMsg.GetFields( Fields );

   try
   {

      int FieldIndex         = 0;
      AnsiString LatStr      = Fields->Strings[FieldIndex++];
      AnsiString LatRefStr   = Fields->Strings[FieldIndex++];
      AnsiString LonStr      = Fields->Strings[FieldIndex++];
      AnsiString LonRefStr   = Fields->Strings[FieldIndex++];
      AnsiString AltStr      = Fields->Strings[FieldIndex++];
      AnsiString TimeStr     = Fields->Strings[FieldIndex++];
      AnsiString DateStr     = Fields->Strings[FieldIndex++];

      LatStr.Trim();
      LatRefStr.Trim();
      LonStr.Trim();
      LonRefStr.Trim();
      AltStr.Trim();
      TimeStr.Trim();
      DateStr.Trim();

      Lat_                   = LatStr.ToDouble();
      if ( LatRefStr == 'S' || LatRefStr == 's' )
      {
         Lat_                = -Lat;
      }

      Lon_                   = LonStr.ToDouble();
      if ( LonRefStr == 'W' || LonRefStr == 'w' )
      {
         Lon_                = -Lon_;
      }

      Alt_                   = AltStr.ToDouble();

      // Time
      //
      AnsiString HoursStr    = TimeStr.SubString( 1, 2 );
      AnsiString MinutesStr  = TimeStr.SubString( 3, 2 );
      AnsiString SecondsStr  = TimeStr.SubString( 5, 2 );

      int Hours              = HoursStr.ToInt();
      int Minutes            = MinutesStr.ToInt();
      int Seconds            = SecondsStr.ToInt();

      Time_                  = TDateTime( (unsigned short) Hours, (unsigned short) Minutes, (unsigned short) Seconds, 0 );

      // Date
      //
      AnsiString DayStr      = DateStr.SubString( 1, 2 );
      AnsiString MonthStr    = DateStr.SubString( 3, 2 );
      AnsiString YearStr     = DateStr.SubString( 5, 4 );

      int Day                = DayStr.ToInt();
      int Month              = MonthStr.ToInt();
      int Year               = YearStr.ToInt();

      Date_                  = TDateTime( (unsigned short) Year, (unsigned short) Month, (unsigned short) Day );

      Valid_                 = true;

   }
   catch(...)
   {
      Valid_                 = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// SetSvid
//
TSetSvidMsg::TSetSvidMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg )
{
   ( *this ) = InMsg;
}

TSetSvidMsg &
TSetSvidMsg::operator =
   (
   const TInMsg &InMsg
   )
{

   try
   {
      for ( int i=0; i<Fields->Count; i+=2 )
      {

         TChanSvid ChanSvid( Fields->Strings[i].ToInt(), Fields->Strings[i+1].ToInt() );

         ChanSvidArray.push_back( ChanSvid );

      }
      Valid = true;
   }
   catch(...)
   {
      Valid = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// SetPower
//
TSetPowerMsg::TSetPowerMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg )
{
   ( *this ) = InMsg;
}

TSetPowerMsg &
TSetPowerMsg::operator =
   (
   const TInMsg &InMsg
   )
{

   try
   {
      for ( int i=0; i<Fields->Count; i+=2 )
      {

         TChanPower ChanPower( Fields->Strings[i].ToInt(), Fields->Strings[i+1].ToDouble() );

         ChanPowerArray.push_back( ChanPower );

      }
      Valid = true;
   }
   catch(...)
   {
      Valid = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// Query
//
TQueryMsg::TQueryMsg
   (
   const TInMsg &InMsg
   ) :
   TExtToSim( InMsg )
{
   ( *this ) = InMsg;
}

TQueryMsg &
TQueryMsg::operator =
   (
   const TInMsg &InMsg
   )
{

   try
   {

      Valid = true;

      AnsiString MsgTypeStr = Fields->Strings[0];
      MsgTypeStr.Trim();

      eQUERYTYPE   QueryType;
      eQUERYTRANS  QueryTransRate;
      int          Interval = 0;

      if ( MsgTypeStr.AnsiCompareIC( SimModeMsgId ) == 0 )
      {
         QueryType = eQUERY_SIM_MODE;
      }
      else if ( MsgTypeStr.AnsiCompareIC( ChanStatMsgId ) == 0 )
      {
         QueryType = eQUERY_CHAN_STAT;
      }
      else if ( MsgTypeStr.AnsiCompareIC( BitResultsMsgId ) == 0 )
      {
         QueryType = eQUERY_BIT_RESULTS;
      }
      else if ( MsgTypeStr.AnsiCompareIC( SysCfgMsgId ) == 0 )
      {
         QueryType = eQUERY_SYS_CFG;
      }
      else if ( MsgTypeStr.AnsiCompareIC( SimTimeMsgId ) == 0 )
      {
         QueryType = eQUERY_SIMTIME;
      }
      else
      {
         Valid = false;
      }

      if ( Valid )
      {

         AnsiString TransRateStr = Fields->Strings[1];
         TransRateStr.Trim();

         int TransRate = TransRateStr.ToInt();

         if ( TransRate < -1 )
         {
            QueryTransRate = eQUERY_OFF;
         }
         else if ( TransRate == -1 )
         {
            QueryTransRate = eQUERY_ONCE;
         }
         else if ( TransRate == 0 )
         {
            QueryTransRate = eQUERY_ON_CHANGE;
         }
         else
         {
            QueryTransRate = eQUERY_RATE;
            Interval       = TransRate;
         }
         ExtQuery = TExtQuery( QueryType, QueryTransRate, Interval );

      }
   }
   catch(...)
   {
      Valid = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// SetRfGain
//
TSetRfGainMsg::TSetRfGainMsg
   (
   const TInMsg            & InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TSetRfGainMsg &
TSetRfGainMsg::operator=
   (
   const TInMsg &InMsg
   )
{


   try
   {
      RfGain_  = Fields->Strings[0].ToDouble();
      Valid_   = true;
   }
   catch(...)
   {
      Valid_   = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// AdjustRfGain
//
TAdjustRfGainMsg::TAdjustRfGainMsg
   (
   const TInMsg            & InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TAdjustRfGainMsg &
TAdjustRfGainMsg::operator=
   (
   const TInMsg &InMsg
   )
{


   try
   {
      AdjustRfGain_  = Fields->Strings[0].ToDouble();
      Valid_         = true;
   }
   catch(...)
   {
      Valid_         = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// SetRfAtten
//
TSetRfAttenMsg::TSetRfAttenMsg
   (
   const TInMsg            & InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TSetRfAttenMsg &
TSetRfAttenMsg::operator=
   (
   const TInMsg &InMsg
   )
{


   try
   {
      RfAtten_  = Fields->Strings[0].ToDouble();
      Valid_    = true;
   }
   catch(...)
   {
      Valid_   = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// AdjustRfAtten
//
TAdjustRfAttenMsg::TAdjustRfAttenMsg
   (
   const TInMsg            & InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TAdjustRfAttenMsg &
TAdjustRfAttenMsg::operator=
   (
   const TInMsg &InMsg
   )
{


   try
   {
      AdjustRfAtten_  = Fields->Strings[0].ToDouble();
      Valid_          = true;
   }
   catch(...)
   {
      Valid_         = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// SetL1Atten
//
TSetL1AttenMsg::TSetL1AttenMsg
   (
   const TInMsg            & InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TSetL1AttenMsg &
TSetL1AttenMsg::operator=
   (
   const TInMsg            & InMsg
   )
{

   try
   {
      for ( int i=0; i<Fields->Count; i+=2 )
      {

         TChanL1Atten ChanL1Atten( Fields->Strings[i].ToInt(), Fields->Strings[i+1].ToDouble() );

         ChanL1AttenArray_.push_back( ChanL1Atten );

      }
      Valid = true;
   }
   catch(...)
   {
      Valid = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// SetL2Atten
//
TSetL2AttenMsg::TSetL2AttenMsg
   (
   const TInMsg            & InMsg
   ) :
   TExtToSim( InMsg )
{

   ( *this ) = InMsg;

}

TSetL2AttenMsg &
TSetL2AttenMsg::operator=
   (
   const TInMsg            & InMsg
   )
{

   try
   {
      for ( int i=0; i<Fields->Count; i+=2 )
      {

         TChanL2Atten ChanL2Atten( Fields->Strings[i].ToInt(), Fields->Strings[i+1].ToDouble() );

         ChanL2AttenArray_.push_back( ChanL2Atten );

      }
      Valid = true;
   }
   catch(...)
   {
      Valid = false;
   }

   return( *this );

}

//-----------------------------------------------------------------------------
// Ack
//
TAckMsg::TAckMsg
   (
   const AnsiString MsgAcked,
   const bool MsgValid,
   const bool SimModeValid
   ) :
   MsgId( AckMsgId )
{

   AnsiString Msg = AnsiString( "$" ) + MsgId + Comma + MsgAcked + Comma;
   if ( MsgValid )
   {
      Msg += AckMsgValidStr + Comma;
   }
   else
   {
      Msg += AckMsgInvalidStr + Comma;
   }

   if ( SimModeValid )
   {
      Msg += AckSimModeValidStr;
   }
   else
   {
      Msg += AckSimModeInvalidStr;
   }

   SetBody( string( Msg.c_str() ) );

}

//-----------------------------------------------------------------------------
// BitResults
//
TBitResultsMsg::TBitResultsMsg
   (
   const TTapBitResults & TapBitResults
   ) :
   MsgId( BitResultsMsgId )
{

   AnsiString Msg = AnsiString( "$" ) + MsgId + Comma;

   // Date
   //
   Msg += TapBitResults.DateTime.DateString() + Comma;

   // Time
   //
   Msg += TapBitResults.DateTime.TimeString() + Comma;

   // x1
   //
   bool x1Passed = true;
   if ( TapBitResults.x1.IsRequired() && !TapBitResults.x1.IsPassed() )
   {
      x1Passed = false;
   }

   Msg += AnsiString( (int) !x1Passed ) + Comma;

   // x2
   //
   bool x2Passed = true;
   if ( TapBitResults.x2.IsRequired() && !TapBitResults.x2.IsPassed() )
   {
      x2Passed = false;
   }

   Msg += AnsiString( (int) !x2Passed ) + Comma;

   // x3
   //
   bool x3Passed = true;
   if ( TapBitResults.x3.IsRequired() && !TapBitResults.x3.IsPassed() )
   {
      x3Passed = false;
   }

   Msg += AnsiString( (int) !x3Passed ) + Comma;

   // Interrupt
   //
   bool InterruptPassed = true;
   if ( TapBitResults.Interrupt.IsRequired() && !TapBitResults.Interrupt.IsPassed() )
   {
      InterruptPassed = false;
   }

   Msg += AnsiString( (int) !InterruptPassed ) + Comma;

   // Ocxo
   //
   bool OcxoPassed = true;
   if ( TapBitResults.Ocxo.IsRequired() && !TapBitResults.Ocxo.IsPassed() )
   {
      OcxoPassed = false;
   }

   Msg += AnsiString( (int) !OcxoPassed ) + Comma;

   // Pll
   //
   bool PllPassed = true;
   if ( TapBitResults.Pll.IsRequired() && !TapBitResults.Pll.IsPassed() )
   {
      PllPassed = false;
   }

   Msg += AnsiString( (int) !PllPassed );

   SetBody( string( Msg.c_str() ) );

}

//-----------------------------------------------------------------------------
// Sim Mode
//
TSimModeMsg::TSimModeMsg
   (
   const eRciSimMode SimMode
   ) :
   MsgId( SimModeMsgId )
{

   AnsiString Msg = AnsiString( "$" ) + MsgId + Comma;

   AnsiString ModeStr;
   if ( SimMode == eSimIdle )
   {
      ModeStr = AnsiString( "IDLE" );
   }
   else if ( SimMode == eSimLocal )
   {
      ModeStr = AnsiString( "RUNLOCAL" );
   }
   else if ( SimMode == eSimScen )
   {
      ModeStr = AnsiString( "RUNSCEN" );
   }
   else if ( SimMode == eSimRegen )
   {
      ModeStr = AnsiString( "REGENSCEN" );
   }
   else if ( SimMode == eSimExtResetPulseWaitLocal )
   {
      ModeStr = AnsiString( "TIMESETPULSE" );
   }
   else if ( SimMode == eSimExtResetPulseWaitScen )
   {
      ModeStr = AnsiString( "WAITRESETPULSESCEN" );
   }

   Msg += ModeStr;

   SetBody( string( Msg.c_str() ) );

}

//-----------------------------------------------------------------------------
// Channel Status
//
TChanStatMsg::TChanStatMsg
   (
   const TChanStatArray & ChanStatArray
   ) :
   MsgId( ChanStatMsgId )
{

   AnsiString Msg = AnsiString( "$" ) + MsgId + Comma;

   for ( unsigned int i=0; i<ChanStatArray.size(); ++i )
   {
      AnsiString ChanStatStr = AnsiString( i+1 ) + Comma +
         AnsiString( ChanStatArray[i].GetSvid() ) + Comma +
         AnsiString::FormatFloat( "0.00", ChanStatArray[i].GetL1Power() );
      if ( i != ChanStatArray.size()-1 )
      {
         ChanStatStr += Comma;
      }
      Msg += ChanStatStr;
   }

   SetBody( string( Msg.c_str() ) );

}

//-----------------------------------------------------------------------------
// System Configuration (SYSCFG)
//
TSysCfgMsg::TSysCfgMsg
   (
   const TSysCfg & SysCfg
   ) :
   MsgId( SysCfgMsgId )
{

   AnsiString Msg = AnsiString( "$" ) + MsgId + Comma;


   Msg += AnsiString( SysCfg.NumChans ) + Comma;
   if ( SysCfg.L2Capable )
   {
      Msg += SysCfgL2CapableStr + Comma;
   }
   else
   {
      Msg += SysCfgL1OnlyStr + Comma;
   }

   Msg += AnsiString( SysCfg.MinPower ) + Comma;
   Msg += AnsiString( SysCfg.MaxPower );

   SetBody( string( Msg.c_str() ) );

}

//-----------------------------------------------------------------------------
// Scen Time (SCENTIME)
//
TSimTimeMsg::TSimTimeMsg
   (
   const TSimTime          & SimTime
   ) :
   MsgId( SimTimeMsgId )
{

   AnsiString Msg          = AnsiString( "$" ) + MsgId + Comma;


   Msg                    += AnsiString::FormatFloat( "0.000", SimTime.SecondsIntoSim ) + Comma;
   Msg                    += AnsiString( SimTime.CurWeek ) + Comma + AnsiString::FormatFloat( "0.000", SimTime.CurSeconds );

   SetBody( string( Msg.c_str() ) );

}



