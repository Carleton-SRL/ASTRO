#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: VoyDefPf.cpp                                          $
//
// $Revision:: 2                                                     $
//
// $History:: VoyDefPf.cpp                                           $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:34p
//Updated in $/TapRci
//Update from TapMsec.
//
//
//---------------------------------------------------------------------------


#ifndef VoyDefPfH
#include "VoyDefPf.h"
#endif

#ifndef OrbDriverH
//#include "OrbDriver.h"
#endif

const char *DefaultRunRoot = "c:\\voyager\\runs";

///////////////////////////////////////////////////////////////////////////////
//  TVoyDefProfile
// Profile object for voyager defaults
///////////////////////////////////////////////////////////////////////////////
TVoyDefProfile::TVoyDefProfile() : TIniFile("VOYAGER.INI")
{ }

_fastcall TVoyDefProfile::~TVoyDefProfile(){}
///////////////////////////////////////////////////////////////////////////////
//   GetRunsDir(char *RunRoot)
// Fills RunRoot with the run root directory path, including drive.
///////////////////////////////////////////////////////////////////////////////
void
TVoyDefProfile::GetRunsDir
   (
   char *RunRoot
   )
{
   AnsiString RunRootStr = ReadString("Defaults","RunsDir",DefaultRunRoot);
   strcpy(RunRoot,RunRootStr.c_str());
}

AnsiString const
TVoyDefProfile::GetRunsDir
   (
   )
{
   AnsiString RunRootStr = ReadString("Defaults","RunsDir",DefaultRunRoot);
   return( RunRootStr );
}

bool const
TVoyDefProfile::IsGroundTrackEnabled() 
{

   return(ReadInteger("Defaults","GroundTrackEnabled",1));

}


bool const
TVoyDefProfile::IsPlotEnabled()
{

   return(ReadInteger("Defaults","PlotEnabled",1));

}


bool const
TVoyDefProfile::GetDoCodeCalibration()
{
   return(ReadInteger("Defaults","DoCodeCalibration",1));
}

bool const
TVoyDefProfile::GetDoRTCalibration()
{
   return(ReadInteger("Defaults","DoRTCalibration",1));
}
bool const
TVoyDefProfile::IsRemote()
{
   return(ReadInteger("Defaults","IsRT",1));
}

bool const
TVoyDefProfile::IsMcAnal05
   (
   )
{

   return(ReadInteger("Defaults","IsMcAnal05",1));

}

bool const
TVoyDefProfile::GetDoCarrierCalibration()
{
   return(ReadInteger("Defaults","DoCarrierCalibration",1));
}

int const TVoyDefProfile::GetScramnetOffset()
{
   return( ReadInteger("Defaults","ScramnetOffset",0) );
}

bool const
TVoyDefProfile::GetShowCal()
{
   return(ReadInteger("Defaults","ShowCal",1));
}

int const
TVoyDefProfile::GetTruthTimeDelay()
{
   return(ReadInteger("Defaults","TruthTimeDelay",0));
}

int const
TVoyDefProfile::GetDisplayUpdateInterval()
{
   return(ReadInteger("Defaults","DisplayUpdateInterval",1000));
}

bool const
TVoyDefProfile::IsIntEnabled
   (
   )
{
   bool LocalIntEnabled = false;
   int  iIntEnabled     = ReadInteger( "Defaults", "IntEnabled", -1 );
   if ( iIntEnabled >= 0 )
   {
      LocalIntEnabled = ( iIntEnabled != 0 );
   }
   else
   {
      int iPcsgIntEnabled = ReadInteger( "Defaults", "PcsgIntEnabled", 0 );
      LocalIntEnabled     = ( iPcsgIntEnabled != 0 );
   }

   return( LocalIntEnabled );

}

int const
TVoyDefProfile::GetInterChassisBias
   (
   int ChassisNum
   )
{
   int Value;
   if ( ChassisNum )
   {
      Value = ReadInteger("Defaults","InterChassisBias1",0);
   } else
   {
      Value = ReadInteger("Defaults","InterChassisBias2",0);
   }
   return (Value);
}
///////////////////////////////////////////////////////////////////////////////
//   GetDriverType()
// Returns the type of driver (8 ot 16 bit)
///////////////////////////////////////////////////////////////////////////////
TVoyDefProfile::OrbDriverType const
TVoyDefProfile::GetDriverType
   (
   )
{
   int Value = ReadInteger("Defaults","OrbDriverType",16);
   if ( Value == Orb8 )      return(Orb8);
   else if ( Value == GsIsa )return(GsIsa);
   else if ( Value == GsPci )return(GsPci);
   else return(Orb16);
}
bool const
TVoyDefProfile::IsTestMode
   (
   )
{
   return ( ReadInteger("Defaults","TestMode",0));
}
bool const
TVoyDefProfile::IsDebugDisp
   (

   )
{
   return( ReadInteger( "LLTest", "DebugDisp", 0 ) );
}

int const
TVoyDefProfile::GetLLTestNumChans
   (
   )
{
   return( ReadInteger( "LLTest","NumChans",1 ) );
}

bool const
TVoyDefProfile::IsL2Capable
   (
   )
{
   bool L2Capable = false;
   if ( ReadInteger( "Defaults", "L2Capable", 0 ) )
   {
      L2Capable = true;
   }
   return( L2Capable );
}

