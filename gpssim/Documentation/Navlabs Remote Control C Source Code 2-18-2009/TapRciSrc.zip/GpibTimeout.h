//---------------------------------------------------------------------------

#ifndef GpibTimeoutH
#define GpibTimeoutH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: GpibTimeout.h                                         $
//
// $Revision:: 2                                                     $
//
// $History:: GpibTimeout.h                                          $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:38p
//Updated in $/TapRci
//Initial checkin.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/08/02   Time: 9:04p
//Created in $/TapRci
//
//
//---------------------------------------------------------------------------

class TGpibTimeout {
private:

   int                       DefaultTimeout;

public:
   TGpibTimeout( int InDefaultTimeout );

   int const                 GetTimeout( const AnsiString & TimeoutStr );
   AnsiString const          GetTimeoutStr( const int Timeout );

};   



#endif
 