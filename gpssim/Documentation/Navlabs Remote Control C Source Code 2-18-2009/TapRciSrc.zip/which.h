#ifndef WhichH
#define WhichH

//---------------------------------------------------------------------------
//
// $Workfile:: which.h                                               $
//
// $Revision:: 1                                                     $
//
// $History:: which.h                                                $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 3:24p
//Created in $/TapRci
//Initial checkin.
//
//
//---------------------------------------------------------------------------


template<class TMem>
class TWhich {
private:
   TMem  Set1;
   TMem  Set2;
   int   which;
public:
   TWhich() : which(0) {}
   TMem const GetCurrent() const
   {
      if ( which == 2 )
      {
         return( Set2 );
      }
      else
      {
         return( Set1 );
      }
   }

   int const SetInitial( const TMem &InSet1, const TMem &InSet2 )
   {

      Set1  = InSet1;
      Set2  = InSet2;
      which = 1;

      return(which);

   }

   int const SetCurrent( const TMem &New )
   {
      if ( which != 1 )
      {
         Set1  = New;
         which = 1;
      }
      else
      {
         Set2  = New;
         which = 2;
      }
      return(which);
   }

};

template<class TMem>
class TWhichPtr {
private:
   TMem  *Set1;
   TMem  *Set2;
   int   which;
public:
   TWhichPtr(int Numctor) : which(0)
   {
      Set1 = new TMemPtr(Numctor);
      Set2 = new TMemPtr(Numctor);
   }

   ~TWhichPtr()
   {
      delete Set1;
      delete Set2;
   }

   TMem GetCurrent()
   {
      if ( which == 2 )
      {
         return(*Set2);
      }
      else
      {
         return(*Set1);
      }
   }

   int const SetInitial
      (
      const TMem &InSet1,
      const TMem &InSet2
      )
   {

      *Set1  = InSet1;
      *Set2  = InSet2;
      which  = 1;

      return(which);

   }

   int const SetCurrent
      (
      const TMem &New
      )
   {
      if ( which != 1 )
      {
         *Set1  = New;
         which  = 1;
      }
      else
      {
         *Set2  = New;
         which  = 2;
      }
      return(which);
   }

};

template<class TMem>
class TWhichReadSwitches {
private:
   TMem  Set1;
   TMem  Set2;
   mutable int   which;
public:
   TWhichReadSwitches() : which( 0 )
   {
   }

   ~TWhichReadSwitches()
   {
   }
   TMem GetCurrent() const
   {
      if ( which != 1 )
      {
         which = 1;
         return( Set1 );
      }
      else
      {
         which = 2;
         return( Set2 );
      }
   }

   int const SetInitial
      (
      const TMem &InSet1,
      const TMem &InSet2
      )
   {

      Set1  = InSet1;
      Set2  = InSet2;
      which = 2;

      return( which );

   }

   int const SetCurrent
      (
      const TMem &New
      )
   {
      if ( which == 1 )
      {
         Set1  = New;
      }
      else
      {
         Set2  = New;
      }
      return( which );
   }

   void SetWhich
      (
      const int NewWhich
      ) const
   {
      which = NewWhich;
   }

   int const GetWhich() const
   {
      return ( which );
   }


};

template<class TMem>
class TWhichPtrReadSwitches {
private:
   TMem  *Set1;
   TMem  *Set2;
   mutable int   which;
public:
   TWhichPtrReadSwitches(const int Numctor) : which(0)
   {
      Set1 = new TMem(Numctor);
      Set2 = new TMem(Numctor);
   }

   ~TWhichPtrReadSwitches()
   {
      delete Set1;
      delete Set2;
   }
   TMem GetCurrent() const
   {
      if ( which != 1 )
      {
         which = 1;
         return(*Set1);
      }
      else
      {
         which = 2;
         return(*Set2);
      }
   }

   int const SetInitial
      (
      const TMem &InSet1,
      const TMem &InSet2
      )
   {

      *Set1  = InSet1;
      *Set2  = InSet2;
      which  = 1;

      return(which);

   }

   int const SetCurrent
      (
      const TMem &New
      )
   {
      if ( which != 1 )
      {
         *Set1  = New;
      }
      else
      {
         *Set2  = New;
      }
      return(which);
   }

   void SetWhich
      (
      const int NewWhich
      ) const
   {
      which = NewWhich;
   }


};

template<class TMem>
class TWhichPtrSingle {
private:
   TMem  *Set1;
   bool  SetValid;
public:
   TWhichPtrSingle(const int Numctor) : SetValid(false)
   {
      Set1 = new TMem(Numctor);
   }
   ~TWhichPtrSingle()
   {
      delete Set1;
   }
   bool const IsSet() const
   {
      return(SetValid);
   }

   TMem GetCurrent()
   {
      SetValid = false;
      return(*Set1);
   }

   void SetCurrent
      (
      const TMem &InSet
      )
   {
      *Set1    = InSet;
      SetValid = true;
   }
};

template<class TMem>
class TWhichSingle {
private:
   TMem  Set1;
   bool  SetValid;
public:
   TWhichSingle() : SetValid(false)
   {
   }
   ~TWhichSingle()
   {
   }
   bool const IsSet() const
   {
      return(SetValid);
   }

   TMem GetCurrent()
   {
      SetValid = false;
      return( Set1 );
   }

   void SetCurrent
      (
      const TMem &InSet
      )
   {
      Set1     = InSet;
      SetValid = true;
   }
};




#endif
