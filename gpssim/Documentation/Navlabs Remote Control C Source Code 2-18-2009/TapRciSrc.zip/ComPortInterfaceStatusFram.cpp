#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: ComPortInterfaceStatusFram.cpp                        $
//
// $Revision:: 2                                                     $
//
// $History:: ComPortInterfaceStatusFram.cpp                         $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/24/04    Time: 8:21a
//Created in $/TapRci
//Initial development.
//
//
//---------------------------------------------------------------------------


#ifndef ComPortInterfaceStatusFramH
#include "ComPortInterfaceStatusFram.h"
#endif

#ifndef ComPortInterfaceH
#include "ComPortInterface.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "RzLabel"
#pragma link "RzPanel"
#pragma link "RzSplit"
#pragma link "RzStatus"
#pragma resource "*.dfm"
TComPortInterfaceStatusFrame *ComPortInterfaceStatusFrame;
//---------------------------------------------------------------------------

#define NUM_WINDOWS   (7)
#define DISABLED_INDEX (7)


__fastcall
TComPortInterfaceStatusFrame::TComPortInterfaceStatusFrame
   (
   TComponent              * Owner,
   const TPortDisp         & InPortDisp,
   TComPortInterface       * InComPortInterface
   ) :
   TFrame( Owner ),
   PortDisp_( InPortDisp ),
   ComPortInterface_( InComPortInterface )
{

   XmtImageList->GetBitmap( 0, XmtImage->Picture->Bitmap );
   RcvImageList->GetBitmap( 0, RcvImage->Picture->Bitmap );


   InitDisplay();

   UpdateDisplay();

   Title_                  = AnsiString( "Serial Port " ) + AnsiString( PortDisp_.PortNum ) + AnsiString( " Status" );

   ComPortTimer->Enabled   = true;
}
//---------------------------------------------------------------------------

void
TComPortInterfaceStatusFrame::UpdateDisplay
   (
   )
{


   BytesRcvdTxt->Caption   = AnsiString( ComPortInterface_->BytesRcvd );

   BytesXmtdTxt->Caption   = AnsiString( ComPortInterface_->BytesXmtd );

   if ( PrevBytesRcvd_ != ComPortInterface_->BytesRcvd )
   {
      ExecuteRcvd_         = true;
   }
   PrevBytesRcvd_          = ComPortInterface_->BytesRcvd;

   if ( PrevBytesXmtd_ != ComPortInterface_->BytesXmtd )
   {
      ExecuteXmtd_         = true;
   }
   PrevBytesXmtd_          = ComPortInterface_->BytesXmtd;




}
void __fastcall
TComPortInterfaceStatusFrame::ComPortTimerTimer
   (
   TObject                 * Sender
   )
{

   if ( ExecuteRcvd_ )
   {

      if ( ++RcvdWindowIndex_ >= NUM_WINDOWS )
      {
         RcvdWindowIndex_  = 0;
         ExecuteRcvd_      = false;
      }

      RcvImageList->GetBitmap( RcvdWindowIndex_, RcvImage->Picture->Bitmap );

      RcvImage->Invalidate();

   }

   if ( ExecuteXmtd_ )
   {

      if ( ++XmtdWindowIndex_ >= NUM_WINDOWS )
      {
         XmtdWindowIndex_  = 0;
         ExecuteXmtd_      = false;
      }

      XmtImageList->GetBitmap( XmtdWindowIndex_, XmtImage->Picture->Bitmap );

      XmtImage->Invalidate();

   }


}
//---------------------------------------------------------------------------

void
TComPortInterfaceStatusFrame::InitDisplay
   (
   )
{

   SerialPortVal->Caption  = PortDisp_.PortStr;
   BaudVal->Caption        = PortDisp_.BaudStr;
   ParityVal->Caption      = PortDisp_.ParityStr;
   DataBitsVal->Caption    = PortDisp_.DataBitsStr;
   StopBitsVal->Caption    = PortDisp_.NumStopBitsStr;
   HWFlowVal->Caption      = PortDisp_.HWFlowStr;
   SWFlowVal->Caption      = PortDisp_.SWFlowStr;

}
