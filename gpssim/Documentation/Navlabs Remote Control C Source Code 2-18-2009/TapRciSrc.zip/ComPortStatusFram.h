//---------------------------------------------------------------------------


#ifndef ComPortStatusFramH
#define ComPortStatusFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: ComPortStatusFram.h                                   $
//
// $Revision:: 1                                                     $
//
// $History:: ComPortStatusFram.h                                    $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 9/24/04    Time: 8:21a
//Created in $/TapRci
//Initial development.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "RzLabel.hpp"
#include "RzPanel.hpp"
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------


//---------------------------------------------------------------------------

#ifndef InterfaceStatusFrameH
#include "InterfaceStatusFrame.h"
#endif



class TComPortStatusFrame : public TFrame
{
__published:
   TImage *ComPortmage;
   TRzPanel *RzPanel1;
   TRzLabel *ComPortStatusTitleLbl;
   TRzLabel *SerialPortLbl;
   TRzLabel *BaudLbl;
   TRzLabel *ParityLbl;
   TRzLabel *DataBitsLbl;
   TRzLabel *StopBitsLbl;
   TRzLabel *HWFlowLbl;
   TRzLabel *SWFlowLbl;
   TRzLabel *SerialPortVal;
   TRzLabel *BaudVal;
   TRzLabel *ParityVal;
   TRzLabel *DataBitsVal;
   TRzLabel *StopBitsVal;
   TRzLabel *HWFlowVal;
   TRzLabel *SWFlowVal;
private:
public:

   __fastcall TComPortStatusFrame( TComponent * Owner );

};
//---------------------------------------------------------------------------
extern PACKAGE TComPortStatusFrame *ComPortStatusFrame;
//---------------------------------------------------------------------------
#endif
