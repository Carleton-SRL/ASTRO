#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop


//---------------------------------------------------------------------------
//
// $Workfile:: GpibIntOptionsFram.cpp                                $
//
// $Revision:: 4                                                     $
//
// $History:: GpibIntOptionsFram.cpp                                 $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:28p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:37p
//Updated in $/TapRci
//Added options for primary address, etc.
//
//
//---------------------------------------------------------------------------


#include "Decl-32.h"

#ifndef GpibIntOptionsFramH
#include "GpibIntOptionsFram.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ovclabel"
#pragma link "RzEdit"
#pragma link "RzSpnEdt"
#pragma link "RzButton"
#pragma link "RzPanel"
#pragma resource "*.dfm"


static char ErrorMnemonic[21][5] =
{
   "EDVR", "ECIC", "ENOL", "EADR", "EARG", "ESAC", "EABO", "ENEB", "EDMA", "",
   "EOIP", "ECAP", "EFSO", ""    , "EBUS", "ESTB", "ESRQ", ""    , ""    , "",
   "ETAB"
};

TGpibIntOptionsFrame *GpibIntOptionsFrame;
//---------------------------------------------------------------------------


__fastcall
TGpibIntOptionsFrame::TGpibIntOptionsFrame
   (
   TComponent    * Owner
   ) :
   TFrame( Owner ),
   ValidInterface_( false ),
   TapRciProfile( NULL )
{

   TapRciProfile                 = new TTapRciProfile();
   SetDisplayFromProfile();

}
//---------------------------------------------------------------------------


void
TGpibIntOptionsFrame::SetProfileFromDisplay
   (
   )
{

   TapRciProfile->GpibBoardIndex     = BoardIndexSpinEdit->Value;
   TapRciProfile->GpibPrimaryAddress = PrimaryAddrSpinEdit->Value;

}

void
TGpibIntOptionsFrame::SetDisplayFromProfile
   (
   )
{

   BoardIndexSpinEdit->Value         = TapRciProfile->GpibBoardIndex;
   PrimaryAddrSpinEdit->Value        = TapRciProfile->GpibPrimaryAddress;

}


void __fastcall
TGpibIntOptionsFrame::TestBtnClick
   (
   TObject * Sender
   )
{

   ValidInterface_          = false;

   AnsiString GpibBoardStr;
   GpibBoardStr.sprintf( "gpib%d", BoardIndexSpinEdit->Value );

   AnsiString TestResultsDetailStr;

   int Board = ibfind( GpibBoardStr.c_str() );
   if ( Board >= 0 )
   {

      TestResultsDetailsMemo->Lines->Add( GpibBoardStr + AnsiString( " board found. ") );

      ibpad( Board, PrimaryAddrSpinEdit->Value );

      if ( ibsta & ERR )
      {
         AnsiString ErrStr;

         ErrStr.sprintf( "Unable to set primary address to %d. ibsta = 0x%x iberr = %d (%s)",
                   PrimaryAddrSpinEdit->Value, ibsta, iberr, ErrorMnemonic[iberr]);

         TestResultsDetailsMemo->Lines->Add( ErrStr );
         ValidInterface_ = false;

      }
      else
      {

         TestResultsDetailsMemo->Lines->Add( AnsiString( "Primary address set to ") + AnsiString( (int) PrimaryAddrSpinEdit->Value ) );

         ValidInterface_ = true;

      }

   }
   else
   {

      AnsiString ErrStr;

      ErrStr.sprintf( "Unable to find board %s. ibsta = 0x%x iberr = %d (%s)",
                GpibBoardStr.c_str(), ibsta, iberr, ErrorMnemonic[iberr]);

      TestResultsDetailsMemo->Lines->Add( ErrStr );
      ValidInterface_ = false;

   }

   if ( ValidInterface )
   {

      TestResultsLbl->Caption = " PASSED ";
      TestResultsLbl->Font->Color = clGreen;

   }
   else
   {

      TestResultsLbl->Caption = " FAILED ";
      TestResultsLbl->Font->Color = clRed;

   }


}
//---------------------------------------------------------------------------


__fastcall
TGpibIntOptionsFrame::~TGpibIntOptionsFrame
   (

   )
{

   delete TapRciProfile;
   TapRciProfile = NULL;

}

void
TGpibIntOptionsFrame::DoNewOptions
   (
   const bool Accept
   )
{

   if ( Accept )
   {
      SetProfileFromDisplay();
   }
   else
   {
      SetDisplayFromProfile();
   }

}

bool const
TGpibIntOptionsFrame::GetOptionsChanged
   (
   )
{

   bool Changed     = false;

   try
   {

      Changed      |= BoardIndexSpinEdit->Value  != TapRciProfile->GpibBoardIndex;
      Changed      |= PrimaryAddrSpinEdit->Value != TapRciProfile->GpibPrimaryAddress;

   }
   catch(...)
   {
      CodeSite->SendMsg( csmError, "TGpibIntOptionsFrame::GetOptionsChanged exception" );
   }

   return( Changed );

}   




