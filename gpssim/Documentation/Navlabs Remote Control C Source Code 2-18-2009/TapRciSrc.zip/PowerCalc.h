//---------------------------------------------------------------------------
// ClassExplorer Pro generated header file
// Created by Michael Wade on 2/15/2002, 11:55:15 PM
//---------------------------------------------------------------------------
#ifndef PowerCalcH
#define PowerCalcH

#include "PowerCalIni.h"
//---------------------------------------------------------------------------
class TPowerCalc {
private:
   double L2MaxPower;
   double ExtAtten;
   double L1MaxPower;
protected:
   double const GetPower(const double Atten, const double RFGain, const double MaxPower) const ;
   double const GetAtten(const double Power, const double RFGain, const double MaxPower) const;
public:
   TPowerCalc();
   TPowerCalc(const double InL1MaxPower, const double InL2MaxPower, const double InExtAtten, const double InRFGain);
   void SetNewPowerCal();
   double const GetL1Atten(const double L1Power, const double RFGain ) const;
   double const GetL2Atten(const double L2Power, const double RFGain ) const;
   double const GetL1Power(const double L1Atten, const double RFGain ) const;
   double const GetL2Power(const double L2Atten, const double RFGain ) const;
};

//---------------------------------------------------------------------------
#endif
