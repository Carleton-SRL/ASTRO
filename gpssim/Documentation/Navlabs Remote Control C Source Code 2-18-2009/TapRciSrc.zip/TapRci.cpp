#include "pch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: TapRci.cpp                                            $
//
// $Revision:: 5                                                     $
//
// $History:: TapRci.cpp                                             $
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 1/05/04    Time: 11:31a
//Updated in $/TapRci
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 4:46p
//Updated in $/TapRci
//Too long since project .bpr file updated.  BCB5.
//
//
//---------------------------------------------------------------------------

USEFORM("BitResultsFram.cpp", BitResultsFrame); /* TFrame: File Type */
USEFORM("ChanStatFram.cpp", ChanStatFrame); /* TFrame: File Type */
USEFORM("EthernetInterfaceStatusFram.cpp", EthernetInterfaceStatusFrame); /* TFrame: File Type */
USEFORM("EthernetIntOptionsFram.cpp", EthernetIntOptionsFrame); /* TFrame: File Type */
USEFORM("EXPANDABLEDLG.cpp", ExpandableDialog);
USEFORM("GpibInterfaceStatusFram.cpp", GpibInterfaceStatusFrame); /* TFrame: File Type */
USEFORM("GpibIntOptionsFram.cpp", GpibIntOptionsFrame); /* TFrame: File Type */
USEFORM("InterfaceAcceptFram.cpp", InterfaceAcceptFrame); /* TFrame: File Type */
USEFORM("MsgListFram.cpp", MsgListFrame); /* TFrame: File Type */
USEFORM("OperationErrorFrm.cpp", OperationErrorForm);
USEFORM("PowerDispFrm.cpp", PowerDispForm);
USEFORM("SerialIntOptionsFram.cpp", SerialIntOptionsFrame); /* TFrame: File Type */
USEFORM("TapMsecStatFram.cpp", TapMsecStatFrame); /* TFrame: File Type */
USEFORM("TapRciFrm.cpp", TapRciForm);
USEFORM("VerifyOperationFrm.cpp", VerifyOperationForm);
USEFORM("ComPortInterfaceStatusFram.cpp", ComPortInterfaceStatusFrame); /* TFrame: File Type */
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
       Application->Initialize();
       Application->Title = "Tapestry Remote Control Interface";
       Application->CreateForm(__classid(TTapRciForm), &TapRciForm);
       Application->Run();
   }
   catch (Exception &exception)
   {
       Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------
