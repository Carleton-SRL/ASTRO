#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: PowerDispFrm.cpp                                      $
//
// $Revision:: 3                                                     $
//
// $History:: PowerDispFrm.cpp                                       $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:20p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:50p
//Updated in $/TapRci
//Minor cleanup.
//
//
//---------------------------------------------------------------------------



#ifndef PowerDispFrmH
#include "PowerDispFrm.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "RzPanel"
#pragma link "RzRadGrp"
#pragma link "ovclabel"
#pragma link "RzDlgBtn"
#pragma resource "*.dfm"
TPowerDispForm *PowerDispForm;
//---------------------------------------------------------------------------
__fastcall
TPowerDispForm::TPowerDispForm
   (
   TComponent              * Owner
   ) :
   TForm( Owner )
{

   TTapRciProfile *TapRciProfile = new TTapRciProfile();
   bool DispRelativePower        = TapRciProfile->DispRelativePower;
   delete TapRciProfile;

   PowerDispGrp->ItemIndex       = DispRelativePower ? 1 : 0;

}


void __fastcall
TPowerDispForm::DlgBtnsClickOk
   (
   TObject                 * Sender
   )
{

   bool DispRelativePower           = PowerDispGrp->ItemIndex == 1;

   TTapRciProfile *TapRciProfile    = new TTapRciProfile();
   TapRciProfile->DispRelativePower = DispRelativePower;
   delete TapRciProfile;

   ModalResult = mrOk;

}

void __fastcall
TPowerDispForm::DlgBtnsClickCancel
   (
   TObject                 * Sender
   )
{
   ModalResult = mrCancel;
}

