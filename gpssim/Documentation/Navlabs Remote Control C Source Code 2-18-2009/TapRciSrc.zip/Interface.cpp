#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: Interface.cpp                                         $
//
// $Revision:: 7                                                     $
//
// $History:: Interface.cpp                                          $
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:13p
//Updated in $/TapRci
//Remove some CodeSite messages.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Add serial comm.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:35p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:40p
//Updated in $/TapRci
//Add Source Safe keywords.
//
//
//---------------------------------------------------------------------------


#ifndef InterfaceH
#include "Interface.h"
#endif

#ifndef ThreadInfH
#include "ThreadInf.h"
#endif

#ifndef RciControlH
#include "RciControl.h"
#endif

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Debug Data
//
#ifndef DebugUtilsH
#include "DebugUtils.h"
using namespace DebugUtils;
#endif
#if(1)
static   TTimeInterval ExecuteInterval;
static   double        MinExecuteIntervalms      = 10000.0;
static   double        MaxExecuteIntervalms      = 0.0;
static   int           WaitTimer                 = 0;
static   int           WaitSendEvent             = 0;
static   int           WaitReceiveEvent          = 0;
static   int           WaitTimeout               = 0;
static   int           WaitAbandoned             = 0;
static   int           WaitDebugProcessingCount  = 0;
static   int           WAIT_DEBUG_PROCESSING_MIN = 100;
#endif



//---------------------------------------------------------------------------

static const int             INTERFACE_PERIOD_MSEC            = 100;
static const int             MaxMsgsRcvdNoStat                = 50;
static const int             INTERFACE_EXECUTE_TIMER_MS       = 100;

AnsiString                   TInterface::EventSendDataName    = AnsiString( "TInterfaceSendDataEvent" );
AnsiString                   TInterface::EventReceiveDataName = AnsiString( "TInterfaceReceiveDataEvent" );

TInterface::TInterface
   (
   ) :
   IntError( false ),
   TThread( true ),
   NumMsgsSent_( 0 ),
   NumMsgsRcvd_( 0 ),
   NumMsgsRcvdExceptStat_( 0 ),
   EventSendData( NULL ),
   EventReceiveData( NULL ),
   EventReceiveDataRciControl( NULL )
{

   IntCriticalSection         = new TCriticalSection();

   EventSendData              = new TEvent( NULL, false, false, EventSendDataName );
   EventReceiveData           = new TEvent( NULL, false, false, EventReceiveDataName );
   EventReceiveDataRciControl = new TEvent( NULL, false, false, TRciControl::GetEventReceiveDataName() );

   SetupTimer();

}

void
TInterface::SetupTimer
   (
   )
{

   hTimer                  = CreateWaitableTimer( NULL, FALSE,  NULL );

   __int64 qwDueTime       = -5;

   // Copy the relative time into a LARGE_INTEGER.
   //
   LARGE_INTEGER   liDueTime;
   liDueTime.LowPart       = (DWORD) ( qwDueTime & 0xFFFFFFFF );
   liDueTime.HighPart      = (LONG)  ( qwDueTime >> 32 );

   SetWaitableTimer
   (
      hTimer,                                              // Handle to the timer object.
      &liDueTime,                                          // When timer will become signaled.
      INTERFACE_EXECUTE_TIMER_MS,                          // Periodic timer interval millisecs.
      NULL,                                                // Completion routine.
      NULL,                                                // Argument to the completion routine.
      FALSE                                                // Do not restore a suspended system.
   );

}


__fastcall
TInterface::~TInterface
   (

   )
{

   CloseHandle( hTimer );

   delete IntCriticalSection;
   delete EventReceiveData;
   delete EventSendData;
   delete EventReceiveDataRciControl;

   IntCriticalSection            = NULL;
   EventReceiveData              = NULL;
   EventSendData                 = NULL;
   EventReceiveDataRciControl    = NULL;

}

void _fastcall
TInterface::Execute()
{

   TThreadInf TThreadInf( "InterfaceThread" );

   int NumSyncObjects      = 3;
   HANDLE SyncObjects[3];
   SyncObjects[0]          = hTimer;
   SyncObjects[1]          = (void *) EventReceiveData->Handle;
   SyncObjects[2]          = (void *) EventSendData->Handle;

   // DEBUG
   ExecuteInterval.ResetStart();

   while ( !Terminated && ValidInterface )
   {

      const int WaitResult  = WaitForMultipleObjects( NumSyncObjects, SyncObjects, FALSE, INTERFACE_EXECUTE_TIMER_MS*2 );

      WaitDebugProcessing( WaitResult );

      if ( Terminated ) break;

      IntCriticalSection->Enter();

      if ( !OutMsgQueue.empty() )
      {

         ProcessOutputMsg();

      }

      ReadMsg( RcvdData );

      while ( !RcvdData.empty() )
      {

         InMsg.ProcessData( RcvdData );

         if ( InMsg.IsMsgComplete() )
         {

            MsgTrafficArray.push_back( TMsgTraffic( TScheduleSignal::GetCurTimeMillisec(), InMsg.GetMsgData(), eMSG_SOURCE_CTLR ) );
            IncNumMsgsRcvd( InMsg );
            InMsgArray.push_back( InMsg );
            InMsg.Clear();
            EventReceiveDataRciControl->SetEvent();

         }

      }

      IntCriticalSection->Leave();

   }

}

static const int MaxSendAttempts = 4;
void
TInterface::ProcessOutputMsg
   (
   )
{

   AnsiString OutMsgId  = OutMsgQueue.front().MsgId;

   int SendTimes = 0;
   bool Sent     = false;

   while ( !Sent && SendTimes < MaxSendAttempts )
   {
      if ( SendMsg( OutMsgQueue.front().GetMsgData() ) )
      {
         ++SendTimes;
         ClearIntError();
      }
      else
      {
         Sent = true;
      }
   }

   if ( Sent )
   {

      MsgTrafficArray.push_back( TMsgTraffic( TScheduleSignal::GetCurTimeMillisec(), OutMsgQueue.front().MsgStr, eMSG_SOURCE_SIM ) );
      OutMsgQueue.pop();

      ++NumMsgsSent_;

   }
   else
   {
//      CodeSite->SendMsg( AnsiString( "TInterface::ProcessOutputMsg Error sending msg " ) + OutMsgId );
   }

   if ( IsIntError() )
   {
      CodeSite->SendMsg( "ProcessOutputMsg - Clearing IntError" );
      ClearIntError();
   }
}

void
TInterface::QueueMsgs
   (
   TOutMsgQueue & OutQ
   )
{

   if ( OutQ.size() != 0 )
   {

      IntCriticalSection->Enter();


      while( OutQ.size() )
      {
         OutMsgQueue.push( OutQ.front() );
         OutQ.pop();
      }

      IntCriticalSection->Leave();

      EventSendData->SetEvent();

   }

}

TMsgTrafficArray const
TInterface::GetMsgTrafficArray
   (
   )
{

   IntCriticalSection->Enter();

   TMsgTrafficArray NewMsgTrafficArray = MsgTrafficArray;
   MsgTrafficArray.clear();

   IntCriticalSection->Leave();

   return( NewMsgTrafficArray );

}

void
TInterface::IncNumMsgsRcvd
   (
   const TInMsg &Msg
   )
{
   ++NumMsgsRcvd_;
}

void
TInterface::GetInputMsgs
   (
   TInMsgArray             & OutInMsgArray
   )
{

   IntCriticalSection->Enter();

   OutInMsgArray = InMsgArray;
   InMsgArray.clear();

   IntCriticalSection->Leave();
}

int const
TInterface::GetOutputQueueSize
   (
   ) const
{
   return( (int) OutMsgQueue.size() );
}   

void
TInterface::WaitDebugProcessing
   (
   const int WaitResult
   )
{
#if(1)
   if ( WaitResult == WAIT_TIMEOUT )
   {
      CodeSite->WriteInteger( "TInterface::WaitTimeout", ++WaitTimeout );
   }
   else if ( ( WaitResult >= WAIT_ABANDONED_0 ) && ( WaitResult <= ( WAIT_ABANDONED_0 + 3 - 1 ) ) )
   {
      CodeSite->WriteInteger( "TInterface::WaitAbandoned", ++WaitAbandoned );
      AnsiString Str;
      Str.sprintf( "TInterface::WaitAbandoned.  WaitResult = %d, AbandonedIndex = %d", WaitResult, WaitResult - WAIT_ABANDONED_0 );
      CodeSite->SendMsg( Str );
   }
   else if ( ( WaitResult >= WAIT_OBJECT_0 ) && ( WaitResult <= ( WAIT_OBJECT_0 + 3 - 1 ) ) )
   {

      const int WaitIndex = WaitResult - WAIT_OBJECT_0;
      if ( WaitIndex == 0 ) ++WaitTimer;
      if ( WaitIndex == 1 ) ++WaitSendEvent;
      if ( WaitIndex == 2 ) ++WaitReceiveEvent;

      if ( ( WaitDebugProcessingCount % 10 ) == 0 )
      {
         if ( WaitIndex == 0 )
         {
//            CodeSite->WriteInteger( "TInterface::WaitTimer", WaitTimer );
         }
         else if ( WaitIndex == 1 )
         {
            CodeSite->WriteInteger( "TInterface::WaitSendEvent", WaitSendEvent );
         }
         else if ( WaitIndex == 2 )
         {
            CodeSite->WriteInteger( "TInterface::WaitReceiveEvent", WaitReceiveEvent );
         }
      }

   }

   ExecuteInterval.ResetStart();
#endif
}

