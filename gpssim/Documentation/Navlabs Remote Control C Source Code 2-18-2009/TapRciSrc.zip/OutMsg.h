#ifndef OutMsgH
#define OutMsgH

//---------------------------------------------------------------------------
//
// $Workfile:: OutMsg.h                                              $
//
// $Revision:: 3                                                     $
//
// $History:: OutMsg.h                                               $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:46p
//Updated in $/TapRci
//Minor cleanup.  
//Add properties.
//
//
//---------------------------------------------------------------------------


#ifndef RemoteTypesH
#include "RemoteTypes.h"
#endif

//---------------------------------------------------------------------------

class TOutMsg {
private:

protected:

   AnsiString                MsgId_;
   string                    MsgData_;

   unsigned char const       ComputeChecksum( const string & Str ) const;
   void                      AppendChecksum(string & Str) const;
   AnsiString const          GetMsgId() const  { return( MsgId_ ); }
   AnsiString const          GetMsgStr() const { return( AnsiString( MsgData_.c_str() ) ); }
   string const              GetBody();
   void                      SetBody(const string & MsgBody);

public:
   TOutMsg();

   TMsgData const            GetMsgData() const;
   
   __property AnsiString MsgId     = { read = GetMsgId                           };
   __property AnsiString MsgStr    = { read = GetMsgStr                          };
   __property string     Body      = { read = GetBody,      write = SetBody      };

};

typedef std::queue<TOutMsg> TOutMsgQueue;

//---------------------------------------------------------------------------
#endif

 