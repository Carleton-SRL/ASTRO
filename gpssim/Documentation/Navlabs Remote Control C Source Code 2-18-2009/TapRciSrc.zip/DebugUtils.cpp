#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: DebugUtils.cpp                                        $
//
// $Revision:: 1                                                     $
//
// $History:: DebugUtils.cpp                                         $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 3:39p
//Created in $/TapRci
//Initial checkin.
//
//
//---------------------------------------------------------------------------


#ifndef DebugUtilsH
#include "DebugUtils.h"
#endif

//---------------------------------------------------------------------------
// This is a debug unit containing debug global data, class methods, etc.

#pragma package(smart_init)

bool                      DebugUtils::DebugUtilsEnabled = true;

namespace DebugUtils {


TTimeInterval::TTimeInterval
   (
   )
{

   Init();

}

void
TTimeInterval::Init
   (
   )
{

   LARGE_INTEGER       lFrequency;
   QueryPerformanceFrequency( &lFrequency );
   Frequency_        = lFrequency.QuadPart;

   QueryPerformanceCounter( &StartCount_ );

}

void
TTimeInterval::ResetStart
   (
   )
{

   if ( !DebugUtilsEnabled ) return;
   QueryPerformanceCounter( &StartCount_ );

}

double const
TTimeInterval::GetTimeInterval
   (
   ) const
{

   if ( !DebugUtilsEnabled ) return( 0.0 );

   LARGE_INTEGER       CurCount;
   QueryPerformanceCounter( &CurCount );

   const double DeltaTime    = ( CurCount.QuadPart - StartCount_.QuadPart )/Frequency;

   return( DeltaTime );

}

double const
TTimeInterval::GetTimeIntervalms
   (
   ) const
{

   if ( !DebugUtilsEnabled ) return( 0.0 );

   return( GetTimeInterval()*1000.0 );

}

};
