//---------------------------------------------------------------------------


#ifndef GpibInterfaceStatusFramH
#define GpibInterfaceStatusFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: GpibInterfaceStatusFram.h                             $
//
// $Revision:: 3                                                     $
//
// $History:: GpibInterfaceStatusFram.h                              $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:19p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:36p
//Updated in $/TapRci
//Update display.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/02/02   Time: 10:27a
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include "RzEdit.hpp"
#include <ComCtrls.hpp>
#include "RzButton.hpp"
#include "RzRadChk.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef InterfaceStatusFrameH
#include "InterfaceStatusFrame.h"
#endif

#ifndef GpibTimeoutH
#include "GpibTimeout.h"
#endif



//---------------------------------------------------------------------------

class TGpib;

class TGpibInterfaceStatusFrame : public TFrame, public IInterfaceStatusFrame
{
__published:
   TImage *GpibImage;
   TOvcLabel *BoardIndexDescLbl;
   TOvcLabel *BoardIndexLbl;
   TOvcLabel *PrimaryAddressLbl;
   TOvcLabel *PrimaryAddressDescLbl;
   TOvcLabel *TimeoutDescLbl;
   TOvcLabel *TimeoutLbl;
   TRzRichEdit *DebugRichEdit;
   TRzRadioButton *ValidInterfacerb;
private:

   const TGpib * const       Gpib;
   AnsiString                Title_;
   TGpibTimeout              GpibTime;

   TFrame                  * GetFrame() const { return( (TFrame *) this ); }
   AnsiString const          GetTitle() const { return( Title_ ); }
   void                      SetTitle( const AnsiString & InTitle ) { Title_ = InTitle; }

public:
   __fastcall TGpibInterfaceStatusFrame( TComponent* Owner, const TGpib * const InGpib );

   void                      UpdateDisplay();

   __property TFrame *     Frame       = { read = GetFrame                       };
   __property AnsiString   Title       = { read = GetTitle,   write = SetTitle   };

};
//---------------------------------------------------------------------------
extern PACKAGE TGpibInterfaceStatusFrame *GpibInterfaceStatusFrame;
//---------------------------------------------------------------------------
#endif
