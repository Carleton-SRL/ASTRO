#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: TpMapInterface.cpp                                    $
//
// $Revision:: 4                                                     $
//
// $History:: TpMapInterface.cpp                                     $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:30p
//Updated in $/TapRci
//Add properties for PPSCount/IntCount for External Reset Pulse.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:24p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//
//---------------------------------------------------------------------------


#ifndef VoyDefPfH
#include "VoyDefPf.h"
#endif

#ifndef DDTapPciH
#include "DDTapPci.h"
#endif

#ifndef TpMapInterfaceH
#include "TpMapInterface.h"
#endif

#ifndef OperationErrorFrmH
#include "OperationErrorFrm.h"
#endif

#ifndef InterruptCheckH
#include "InterruptCheck.h"
#endif



TTpMapInterface::TTpMapInterface
   (

   ) :
   Valid_( false ),
   TestMode_( false ),
   UseInt( false ),
   BoardIntEnabled( false ),
   TpMap_( NULL )
{

   TVoyDefProfile * pVdp                   = new TVoyDefProfile();
   TTapMsecProfile * TapMsecProfile        = new TTapMsecProfile();
   TestMode_                               = pVdp->TestMode;
   UseInt                                  = pVdp->IntEnabled;
   TestX1                                  = TapMsecProfile->IsBitTestX1();
   TestX2                                  = TapMsecProfile->IsBitTestX2();
   TestX3                                  = TapMsecProfile->IsBitTestX3();
   TestInt                                 = TapMsecProfile->IsBitTestInt();
   TestOcxo                                = TapMsecProfile->IsBitTestOcxo();
   TestPll                                 = TapMsecProfile->IsBitTestPll();
   delete pVdp;
   delete TapMsecProfile;

   Valid_                                  = OpenInterface();

   if ( Valid && UseInt )
   {
      EnableInt( true );
   }

}

bool const
TTpMapInterface::WaitForInt
   (

   )
{
   bool IntError = false;
   if ( !TestMode_ )
   {
      if ( !BoardIntEnabled )
      {
         EnableInt( true );
      }
      DWORD retval;
      if ( DeviceIoControl(hTapPci,IOCTL_TAPPCI_INT_WAIT,NULL,0,NULL,0,&retval,NULL) == 0 )
      {
         CodeSite->SendMsg( csmError, "TpMapInterface DeviceIoControl returned error!" );
         Application->Terminate();
         Application->ProcessMessages();
         IntError = true;
      }
   }
   return( IntError );
}

void
TTpMapInterface::EnableInt
   (
   const bool Enable
   )
{
   if ( Enable )
   {
      BoardIntEnabled           = true;
      TpMap->BoardCtl.IntEnable = 0x01;
   }
   else
   {
      BoardIntEnabled           = false;
      TpMap->BoardCtl.IntEnable = 0x00;
   }
}


bool const
TTpMapInterface::OpenInterface
   (

   )
{
   bool ValidInt = false;

   if ( !TestMode_ )
   {

      MAP_MEMORY MapMem;
      unsigned long length;
      char *DevName = "\\\\.\\Tappci0";
      hTapPci = CreateFile(DevName,
                           GENERIC_READ | GENERIC_WRITE,
                           FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL,
                           OPEN_EXISTING,
                           0,
                           NULL);

      if (hTapPci == INVALID_HANDLE_VALUE)
      {
         AnsiString ErrStr;
         ErrStr.sprintf( "Unable to open TapPci device. (%d)", GetLastError() );
         TOperationErrorForm *ErrFrm = new TOperationErrorForm( Application, ErrStr );
         ErrFrm->ShowModal();
         delete ErrFrm;
         return( ValidInt );
      }

      TAPPCI_WRITE_REG WriteReg;
      WriteReg.RegOffset = 0x60;
      WriteReg.Value     = 0xa1a1a1a1;
      if (!DeviceIoControl(
               hTapPci,
               IOCTL_TAPPCI_WRITE_REG,
               &WriteReg,
               sizeof(TAPPCI_WRITE_REG),
               NULL,
               0,
               &length,
               NULL))
      {
         AnsiString ErrStr;
         ErrStr.sprintf( "Unable to write reg in TapPci interface.  IOCTL_TAPPCI_WRITE_REG failed:  %d", GetLastError() );
         TOperationErrorForm *ErrFrm = new TOperationErrorForm( Application, ErrStr );
         ErrFrm->ShowModal();
         delete ErrFrm;
         return( ValidInt );
      }

      WriteReg.RegOffset = 0x38;
      WriteReg.Value     = 0x2c0c;
      if (!DeviceIoControl(
               hTapPci,
               IOCTL_TAPPCI_WRITE_REG,
               &WriteReg,
               sizeof(TAPPCI_WRITE_REG),
               NULL,
               0,
               &length,
               NULL))
      {
         AnsiString ErrStr;
         ErrStr.sprintf( "Unable to write reg in TapPci interface.  IOCTL_TAPPCI_WRITE_REG failed:  %d", GetLastError() );
         TOperationErrorForm *ErrFrm = new TOperationErrorForm( Application, ErrStr );
         ErrFrm->ShowModal();
         delete ErrFrm;
         return( ValidInt );
      }

      MAP_MEMORY_INDEX MapMemIndex;

      MapMemIndex.Index = 0;
      if (!DeviceIoControl(
            hTapPci,
            IOCTL_TAPPCI_MAP_MEM,
            &MapMemIndex,
            sizeof(MAP_MEMORY_INDEX),
            &MapMem,
            sizeof(MapMem),
            &length,
            NULL))
      {
         AnsiString ErrStr;
         ErrStr.sprintf( "Unable to write reg in TapPci interface.  IOCTL_TAPPCI_MAP_MEM failed:  %d", GetLastError() );
         TOperationErrorForm *ErrFrm = new TOperationErrorForm( Application, ErrStr );
         ErrFrm->ShowModal();
         delete ErrFrm;
         return( ValidInt );
      }
      ProgBoard();
      TpMap_   = (TPMAP *) MapMem.Address;
      ValidInt = true;

   }
   else
   {


      ValidInt = true;
      TpMap_   = (TPMAP *) new unsigned char[sizeof(TPMAP)];
   }

   return( ValidInt );

}

//---------------------------------------------------------------------------
// Program the board if any of the existing chips are not programmed until we
// can get the program at start working with inactive interrupts
//---------------------------------------------------------------------------
void
TTpMapInterface::ProgBoard
   (
   )
{


   TAPPCI_PROG_BOARD ProgBoard;

   DWORD retval;
   if ( DeviceIoControl( hTapPci, IOCTL_TAPPCI_QUERY_PROG_BOARD, NULL, 0, &ProgBoard, sizeof( ProgBoard ), &retval, NULL ) == 0 )
   {
      CodeSite->SendMsg( "Error getting IOCTL_TAPPCI_QUERY_PROG_BOARD information." );
      return;
   }

   TAPPCI_CHIPS_STATUS ChipsStatus;

   if ( DeviceIoControl( hTapPci, IOCTL_TAPPCI_CHIPS_STATUS, NULL, 0, &ChipsStatus, sizeof( ChipsStatus ), &retval, NULL ) == 0 )
   {
      CodeSite->SendMsg( csmError, "TpMapInterface DeviceIoControl returned error getting chips status.  " );
   }

   bool NeedToProgram   = false;
   NeedToProgram       |= ProgBoard.ProgChip[0].ChipExists && !ChipsStatus.x1.Prog;
   NeedToProgram       |= ProgBoard.ProgChip[1].ChipExists && !ChipsStatus.x2.Prog;
   NeedToProgram       |= ProgBoard.ProgChip[2].ChipExists && !ChipsStatus.x3.Prog;

   if ( NeedToProgram )
   {

      CodeSite->SendMsg( "TpMapInterface programming board." );
      if ( DeviceIoControl( hTapPci, IOCTL_TAPPCI_PROG_BOARD, &ProgBoard, sizeof( ProgBoard ), NULL, 0, &retval, NULL ) == 0 )
      {
         CodeSite->SendMsg( "DeviceIoControl error IOCTL_TAPPCI_PROG_BOARD " );
         return;
      }

   }

}

TTpMapInterface::~TTpMapInterface
   (

   )
{

   // Disable interrupts
   //
   EnableInt( false );
   
   if ( !TestMode_ )
   {
      CloseHandle( hTapPci );
   }

   if ( TestMode_ )
   {
      delete [] TpMap_;
   }

}

TPMAP *
TTpMapInterface::GetTpMap
   (

   )
{
   return( TpMap_ );
}


int const
TTpMapInterface::GetIntCount
   (
   
   ) const
{
   return( TpMap_->BoardCtl.InterruptCount & 0x1ff );
}


int const
TTpMapInterface::GetPPSCount
   (

   ) const
{

   return( ( TpMap_->BoardCtl.InterruptCount >> 9 ) & 0x7f );
}

void
TTpMapInterface::CompensateTimeForSync
   (
   TGpsTime                & Time,
   int                       RolloverCount,
   int                       InPPSCount
   )
{
   int CurPPSCount = GetPPSCount();

   if ( CurPPSCount < InPPSCount )
   {
      ++RolloverCount;
   }

   Time += RolloverCount*(MAX_PPS_COUNT+1) + CurPPSCount;

}

void
TTpMapInterface::ResetCounters
   (
   )
{
   TpMap_->BoardCtl.ResetCounters = 0x01;
}

bool const
TTpMapInterface::GetExtResetPulseRcvd
   (
   )
{

   const int PPSCount1           = PPSCount;
   const int IntCount1           = IntCount;
   Sleep( 10 );
   const int PPSCount2           = PPSCount;
   const int IntCount2           = IntCount;
   return( ( PPSCount1 != PPSCount2 ) || ( IntCount1 != IntCount2 ) );

   // MDW Ideally would like arm reset to clear counters, but right now they keep last values.  4/13/2003
//   return( PPSCount != 0 || IntCount != 0 );

}

#if(0)
bool const
TTpMapInterface::GetArmExtResetPulse
   (
   )
{

}
#endif

void
TTpMapInterface::SetArmExtResetPulse
   (
   const bool              InArmExtReset
   )
{

   if ( InArmExtReset )
   {
      TpMap->BoardCtl.ResetOnNext1PPS             = TPMAP_ENABLE_RESET_ON_NEXT_PULSE;
   }
   else
   {
      TpMap->BoardCtl.ResetOnNext1PPS             = TPMAP_DISABLE_RESET_ON_NEXT_PULSE;
//      TpMap->RfCtlAll.RfCtl[0].CancelExtReset     = 0x01;

   }
   

}

TTapBitResults const
TTpMapInterface::RunBit
   (
   )
{

   TTapBitResults TapBitResults;

   bool ChipsPassed = TestX1 || TestX2 || TestX3;
   if ( TestX1 )
   {
      TapBitResults.x1.SetRequired( true );
      GetHwChipBit( TpMap->BoardProg.X1ProgStatus, TapBitResults.x1 );
      TapBitResults.x1.SetTested( true );
      if ( !TapBitResults.x1.IsPassed() ) ChipsPassed = false;
   }

   if ( TestX2 )
   {
      TapBitResults.x2.SetRequired( true );
      GetHwChipBit( TpMap->BoardProg.X2ProgStatus, TapBitResults.x2 );
      TapBitResults.x2.SetTested( true );
      if ( !TapBitResults.x2.IsPassed() ) ChipsPassed = false;
   }

   if ( TestX3 )
   {
      TapBitResults.x3.SetRequired( true );
      GetHwChipBit( TpMap->BoardProg.X3ProgStatus, TapBitResults.x3 );
      TapBitResults.x3.SetTested( true );
      if ( !TapBitResults.x3.IsPassed() ) ChipsPassed = false;
   }


   if ( ChipsPassed && TestInt )
   {

      TapBitResults.Interrupt.SetRequired( true );
      TapBitResults.Interrupt.SetTested( true );
      TInterruptCheck *InterruptCheck = new TInterruptCheck( this );
      InterruptCheck->Resume();

      Sleep( 100 );

      // If the interrupt count is still 0, then the test has failed.
      //
      if ( InterruptCheck->GetIntCount() == 0 )
      {
         TapBitResults.Interrupt.SetPassed( false );
      }
      else
      {
         InterruptCheck->Terminate();
         InterruptCheck->WaitFor();
         TapBitResults.Interrupt.SetPassed( true );
      }

      delete InterruptCheck;

   }

   if ( TestOcxo )
   {
      TapBitResults.Ocxo.SetRequired( TestOcxo );
      TapBitResults.Ocxo.SetTested( true );
      TapBitResults.Ocxo.SetPassed( true );
   }

   if ( TestPll )
   {
      TapBitResults.Pll.SetRequired( TestPll );
      TapBitResults.Pll.SetTested( true );
      TapBitResults.Pll.SetPassed( true );
   }


   TapBitResults.DateTime = TDateTime::CurrentDateTime();
   TapBitResults.Valid    = true;


   return( TapBitResults );

}


void
TTpMapInterface::GetHwChipBit
   (
   unsigned char             Status,
   TTapBitXChip            & TapBitXChip
   ) const
{

   TapBitXChip.SetInit( Status & CHIP_STATUS_INIT );
   TapBitXChip.SetDone( Status & CHIP_STATUS_DONE );

}


