#ifndef SCENTIME_H
#define SCENTIME_H

#include "GpsTime.h"
#include "SimType.h"
#include "VhTrthRt.h"
#include "VhTrthFl.h"
#include "ScenIniFile.h"

static const int RT_DURATION = 1e6;

class TScenTime {

private:

   static long TimeMillisec;
   static GPSTime StartTime;
   static GPSTime EndTime;
   static bool InitializedFl;
   static bool InitializedRt;


public:

   TScenTime()
   {
      GetScenarioTimes(StartTime,EndTime);
   }
   static GPSTime const GetCurTime()
   {
      return(StartTime + TimeMillisec*0.001);
   }

   static void
   GetScenarioTimes
      (
      GPSTime &Start,
      GPSTime &End
      )
   {
      TScenIniFile *ScenIni = new TScenIniFile();
      if ( !ScenIni->IsFileBased() )
      {
         GetScenarioTimesRt(Start,End);
      }
      else
      {
         GetScenarioTimesFl(Start,End);
      }
      delete ScenIni;
   }

   static void
   GetScenarioTimesFl
      (
      GPSTime &Start,
      GPSTime &End
      )
   {
      if ( !InitializedFl )
      {

         Start = GPSTime(0,0.0);
         ifstream ValidBuild("ValidBld.scn");
         if ( !ValidBuild.good() )
         {
            VehicleTruthFile VehTruth(0);
            Start = VehTruth.GetFirst().GpsTime;
            End   = VehTruth.GetLast().GpsTime;
         }
         else
         {
            int ValidScen=0;
            ValidBuild >> ValidScen;
            ValidBuild >> Start.Week;
            ValidBuild >> Start.Seconds;
            double Duration = 0.0;
            ValidBuild >> Duration;
            End = Start + Duration;
         }
         ValidBuild.close();
         InitializedFl = true;
      }
      else
      {
         Start = StartTime;
         End   = EndTime;
      }
   }

   static void GetScenarioTimesRt
      (
      GPSTime &Start,
      GPSTime &End
      )
   {
//      if ( !InitializedRt )
//      {
         VehTruthRec First = VehicleTruthRt::GetFirstRt();
         Start             = First.GpsTime;
         End               = Start + RT_DURATION;
         InitializedRt     = true;
//      }
//      else
//      {
//         Start = StartTime;
//         End   = EndTime;
//      }

   }

   static void
   SetTimeMillisec
      (
      const long InTimeMillisec
      )
   {
      TimeMillisec = InTimeMillisec;
   };

   static long const
   GetTimeMillisec
      (
      ) 
   {
      return(TimeMillisec);
   };

   static void Clear ()
   {
      InitializedRt = false;
      InitializedFl = false;
   }

};

#endif