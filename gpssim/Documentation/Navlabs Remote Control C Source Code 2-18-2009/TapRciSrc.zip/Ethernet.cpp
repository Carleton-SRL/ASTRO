#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: Ethernet.cpp                                          $
//
// $Revision:: 3                                                     $
//
// $History:: Ethernet.cpp                                           $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:38p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:30p
//Updated in $/TapRci
//Initial release.
//
//
//---------------------------------------------------------------------------


#ifndef EthernetH
#include "Ethernet.h"
#endif

#ifndef OutMsgH
#include "OutMsg.h"
#endif

//---------------------------------------------------------------------------

#pragma package(smart_init)

//---------------------------------------------------------------------------
// Constants
//
static const int SOCKET_TIMEOUT_MSECS       = 10;
static const int SOCKET_WAIT_TIMEOUT_MSECS  = 10;
static const int MAX_WRITE_ATTEMPTS         = 4;
static const int MAX_ETHERNET_BYTES_TO_READ = 1000;


//---------------------------------------------------------------------------
// Static Data
//
TCriticalSection     * TEthernetServerClientThread::ReadCriticalSection          = NULL;
TCriticalSection     * TEthernetServerClientThread::WriteCriticalSection         = NULL;
bool                   TEthernetServerClientThread::CriticalSectionInitialized   = false;



static int Breakpt;

#pragma package(smart_init)

static const int MAX_GPIB_BYTES_TO_READ = 1000;


TEthernetClient::TEthernetClient
   (
   TComponent * InOwner
   ) :
   ClientSocket( NULL ),
   WinSocketStream( NULL ),
   TapRciPf( NULL ),
   Owner( InOwner )
{

   CodeSite->EnterMethod( "TEthernetClient::TEthernetClient" );

   ValidInterface_           = false;

   TapRciPf                  = new TTapRciProfile();

   ClientSocket              = new TClientSocket( Application );

   PortNum_                  = TapRciPf->EthernetPortNum;
   HostAddr_                 = TapRciPf->EthernetHostAddress;

   EthernetStatusFrame       = new TEthernetInterfaceStatusFrame( Owner, this );
   InterfaceStatusFrame      = dynamic_cast<IInterfaceStatusFrame *>( EthernetStatusFrame );

   ClientSocket->Address     = HostAddr_;
   ClientSocket->Port        = PortNum_;
   ClientSocket->ClientType  = ctBlocking;

   ClientSocket->Open();

   AnsiString OpenStr        = AnsiString( "ClientSocket->Open().  Port = " ) + AnsiString( PortNum_ ) + AnsiString( " Host Addr = " ) + HostAddr;
   CodeSite->SendMsg( OpenStr );

   WinSocketStream           = new TWinSocketStream( ClientSocket->Socket, SOCKET_TIMEOUT_MSECS );

   ValidInterface_           = true;

   if ( ValidInterface )
   {
      CodeSite->SendMsg( csmNote, " EthernetClient Interface valid." );
   }
   else
   {
      CodeSite->SendMsg( csmError, " EthernetClient Interface failed." );
   }

   CodeSite->ExitMethod( "TEthernetClient::TEthernetClient" );

}

bool const
TEthernetClient::SendMsg
   (
   const TMsgData & Data
   )
{

   bool Sent       = false;
   bool WriteError = false;

   if ( Data.empty() ) return( false );

   int TotalBytesWritten     = 0;
   int WriteAttempts         = 0;

   while ( !Sent && !WriteError )
   {

      int BytesWritten   = WinSocketStream->Write( (void *) &Data[TotalBytesWritten], Data.size() - TotalBytesWritten );
      TotalBytesWritten += BytesWritten;

      if ( TotalBytesWritten == (int) Data.size() )
      {
         Sent       = true;
         WriteError = false;
      }
      else
      {
         CodeSite->SendMsg( "EthernetClient::SendMsg write failed" );
         if ( ++WriteAttempts > MAX_WRITE_ATTEMPTS )
         {
            Sent       = false;
            WriteError = true;
            CodeSite->SendMsg( "EthernetClient::SendMsg too many WriteAttempts" );
         }
      }

   }

   return( !Sent );

}

void
TEthernetClient::ReadMsg
   (
   TMsgData &MsgData
   )
{

   unsigned char Data[MAX_ETHERNET_BYTES_TO_READ];

   bool Done = false;

   while ( !Done )
   {

      unsigned int NumBytesToRead = ClientSocket->Socket->ReceiveLength();

      if ( NumBytesToRead )
      {

         WinSocketStream->Read( Data, NumBytesToRead );

         for ( unsigned int i=0; i<NumBytesToRead; ++i )
         {

            MsgData.push_back( Data[i] );

         }

      }
      else
      {

         Done = true;

      }

   }

}

bool const
TEthernetClient::GetActive
   (
   ) const
{
   return ( ClientSocket && ClientSocket->Active );
}


__fastcall
TEthernetClient::~TEthernetClient
   (

   )
{
   delete WinSocketStream;
   delete ClientSocket;
}

//---------------------------------------------------------------------------
// TEthernetServer
// Does the listen and accept
//

TEthernetServer::TEthernetServer
   (
   TComponent              * InOwner
   ) :
   ServerSocket( NULL ),
   ActiveClientThread( NULL ),
   TapRciPf( NULL ),
   Owner( InOwner )
{

   ValidInterface_                     = false;

   TapRciPf                            = new TTapRciProfile();

   ServerSocket                        = new TServerSocket( NULL );

   ServerSocket->OnGetThread           = GetThread;

   ServerSocket->OnThreadEnd           = ThreadEnd;

   ServerSocket->OnClientDisconnect    = ClientDisconnect;

   ServerSocket->Port                  = TapRciPf->EthernetPortNum;

   ServerSocket->ServerType            = stThreadBlocking;

   ServerSocket->Open();

   PortNum_                            = TapRciPf->EthernetPortNum;

   EthernetStatusFrame                 = new TEthernetInterfaceStatusFrame( Owner, this );
   InterfaceStatusFrame                = dynamic_cast<IInterfaceStatusFrame *>( EthernetStatusFrame );

   ValidInterface_                     = true;

}

void __fastcall
TEthernetServer::GetThread
   (
   TObject                    *    Sender,
   TServerClientWinSocket     *    ClientSocket,
   TServerClientThread        * &  SocketThread
   )
{

   TEthernetServerClientThread * NewThread       = new TEthernetServerClientThread( ClientSocket );
   SocketThread                                  = NewThread;

   if ( ActiveClientThread == NULL )
   {
      ActiveClientThread                         = NewThread;
      ActiveClientThread->ActiveClient           = true;
   }

   SocketThread->Resume();

}

void __fastcall
TEthernetServer::ThreadEnd
   (
   TObject                  * Sender,
   TServerClientThread      * Thread
   )
{

   CodeSite->SendMsg( "TEthernetServer::ThreadEnd" );

   if ( Thread == ActiveClientThread )
   {

      CodeSite->SendMsg( "ActiveClientThread has ended." );
      ActiveClientThread = NULL;

   }

}

void __fastcall
TEthernetServer::ClientDisconnect
   (
   TObject                  * Sender,
   TCustomWinSocket         * Socket
   )
{

   CodeSite->SendMsg( csmInfo, "TEthernetServer::ClientDisconnect" );

}



bool const
TEthernetServer::SendMsg
   (
   const TMsgData & Data
   )
{

   if ( Data.empty() ) return( false );

   bool Sent = false;

   if ( ActiveClientThread && Data.size() )
   {

      Sent = !( ActiveClientThread->QueueMsgData( Data ) );

   }

   return( !Sent );

}

void
TEthernetServer::ReadMsg
   (
   TMsgData &MsgData
   )
{

   if ( ActiveClientThread )
   {
      ActiveClientThread->GetMsgData( MsgData );
   }

}

__fastcall
TEthernetServer::~TEthernetServer
   (

   )
{
//   delete ServerSocket;

}

TEthernetServerClientThread::TEthernetServerClientThread
   (
   TServerClientWinSocket * InServerClientWinSocket
   ) :
   TServerClientThread( true, InServerClientWinSocket ),
   ServerClientWinSocket( InServerClientWinSocket ),
   WinSocketStream( NULL ),
   ActiveClient_( false )
{

   if ( !CriticalSectionInitialized )
   {

      CriticalSectionInitialized = true;
      ReadCriticalSection        = new TCriticalSection();
      WriteCriticalSection       = new TCriticalSection();

   }

   WinSocketStream               = new TWinSocketStream( ClientSocket, SOCKET_TIMEOUT_MSECS );

}

__fastcall
TEthernetServerClientThread::~TEthernetServerClientThread
   (
   )
{
   CodeSite->SendMsg( csmInfo, "TEthernetServerClientThread destructor" );
   delete WinSocketStream;
}

bool const
TEthernetServerClientThread::QueueMsgData
   (
   const TMsgData          & MsgData
   )
{

   bool Queued = false;

   if ( MsgData.size() )
   {

      WriteCriticalSection->Acquire();

      try
      {

         if ( QueuedOutMsgData.empty() )
         {
            QueuedOutMsgData = MsgData;
         }
         else
         {
            QueuedOutMsgData.insert( QueuedOutMsgData.end(), MsgData.begin(), MsgData.end() );
         }

         Queued = true;

      }
      catch(...)
      {
         AnsiString    ErrorStr( "TEthernetServerClientThread::QueueMsgData exception.  " );
         ErrorStr += AnsiString( "MsgData.size() = " ) + AnsiString( MsgData.size() ) + AnsiString( ".  " );
         ErrorStr += AnsiString( "QueuedOutMsgData.size() = " ) + AnsiString( QueuedOutMsgData.size() );
         CodeSite->SendMsg( csmError, ErrorStr );
      }

      WriteCriticalSection->Release();

   }

   return( !Queued );

}

bool const
TEthernetServerClientThread::GetMsgData
   (
   TMsgData & MsgData
   )
{

   if ( QueuedInMsgData.empty() ) return( false );

   bool bRead = false;

   if ( QueuedInMsgData.size() )
   {

      ReadCriticalSection->Acquire();

      try
      {

         if ( MsgData.empty() )
         {

            MsgData = QueuedInMsgData;

         }
         else
         {
            MsgData.insert( MsgData.end(), QueuedInMsgData.begin(), QueuedInMsgData.end() );
         }

         QueuedInMsgData.clear();

         bRead = true;

      }
      catch(...)
      {
         AnsiString    ErrorStr( "TEthernetServerClientThread::GetMsgData exception.  " );
         ErrorStr += AnsiString( "MsgData.size() = " ) + AnsiString( MsgData.size() ) + AnsiString( ".  " );
         ErrorStr += AnsiString( "QueuedInMsgData.size() = " ) + AnsiString( QueuedInMsgData.size() );
         CodeSite->SendMsg( csmError, ErrorStr );
         bRead     = false;
      }

      ReadCriticalSection->Release();

   }

   return( !bRead );

}


void __fastcall
TEthernetServerClientThread::ClientExecute
   (
   )
{


   while( !Terminated && ( ClientSocket && ClientSocket->Connected ) )
   {

      WriteQueuedMsgData();

      TMsgData InData;
      ReadMsgData( InData );

      if ( ActiveClient )
      {
         AddInMsgDataQueue( InData );
      }
      else
      {
         SendInactiveClientMsg();
         ClientSocket->Close();
      }

   }

   CodeSite->SendMsg( csmInfo, "TEthernetServerClientThread::ClientExecute is ending." );

}


void
TEthernetServerClientThread::AddInMsgDataQueue
   (
   TMsgData                & MsgData
   )
{

   if ( MsgData.empty() ) return;

   ReadCriticalSection->Acquire();

   try
   {

      if ( QueuedInMsgData.empty() )
      {
         QueuedInMsgData = MsgData;
      }
      else
      {
         QueuedInMsgData.insert( QueuedInMsgData.end(), MsgData.begin(), MsgData.end() );
      }
   }
   catch(...)
   {
      AnsiString    ErrorStr( "TEthernetServerClientThread::AddInMsgDataQueue exception.  " );
      ErrorStr += AnsiString( "MsgData.size() = " ) + AnsiString( MsgData.size() ) + AnsiString( ".  " );
      ErrorStr += AnsiString( "QueuedInMsgData.size() = " ) + AnsiString( QueuedInMsgData.size() );
      CodeSite->SendMsg( csmError, ErrorStr );
   }


   ReadCriticalSection->Release();

}


bool const
TEthernetServerClientThread::WriteQueuedMsgData
   (
   )
{

   WriteCriticalSection->Acquire();

   TMsgData OutData = QueuedOutMsgData;

   QueuedOutMsgData.clear();

   WriteCriticalSection->Release();

   bool WriteError = SendMsgData( OutData );
   if ( WriteError )
   {
      CodeSite->SendMsg( csmError, "TEthernetServerClientThread::WriteQueuedMsgData error on SendMsgData" );
   }

   return( WriteError );

}

bool const
TEthernetServerClientThread::ReadMsgData
   (
   TMsgData & ReadMsg
   )
{

   ReadMsg.clear();

   if ( WinSocketStream && WinSocketStream->WaitForData( SOCKET_WAIT_TIMEOUT_MSECS ) )
   {

      bool Reading = true;

      while ( Reading )
      {

         try
         {
            if ( WinSocketStream->WaitForData( SOCKET_WAIT_TIMEOUT_MSECS ) )
            {
               unsigned char Byte;
               int BytesRead = WinSocketStream->Read( &Byte, 1 );
               if ( BytesRead )
               {
                  ReadMsg.push_back( Byte );
               }
               else
               {
                  Reading    = false;
                  CodeSite->SendMsg( csmInfo, "TEthernetServerClientThread::ReadMsgData WaitForData returned true, no bytes read.  Closing ClientSocket." );
                  ClientSocket->Close();
                  Terminate();
               }
            }
            else
            {
               Reading = false;
            }
         }
         catch(...)
         {
            Reading = false;
            return( 0 );
         }

      }

   }

   return( ReadMsg.size() != 0 );

}

bool const
TEthernetServerClientThread::SendMsgData
   (
   const TMsgData          & WriteMsgData
   )
{


   if ( !WinSocketStream )     return( true );

   if ( WriteMsgData.empty() ) return( false );

   bool Sent                 = false;
   bool WriteError           = false;
   int  TotalBytesWritten    = 0;
   int  WriteAttempts        = 0;

   while ( !Sent && !WriteError )
   {

      try
      {
         int BytesWritten       = WinSocketStream->Write( (void *) &WriteMsgData[TotalBytesWritten], WriteMsgData.size() - TotalBytesWritten );
         TotalBytesWritten     += BytesWritten;

         if ( TotalBytesWritten == (int) WriteMsgData.size() )
         {
            Sent                = true;
            WriteError          = false;
         }
         else
         {
            CodeSite->SendMsg( "TEthernetServerClientThread::SendMsgData write failed" );
            if ( ++WriteAttempts > MAX_WRITE_ATTEMPTS )
            {
               Sent             = false;
               WriteError       = true;
               CodeSite->SendMsg( "TEthernetServerClientThread::SendMsg too many WriteAttempts" );
            }
         }
      }
      catch(...)
      {
         Sent       = false;
         WriteError = true;
      }

   }

   return( !Sent );

}

void
TEthernetServerClientThread::SendInactiveClientMsg
   (
   )
{

   AnsiString                ErrorStr( "$ERROR,Not active socket connection" );
   string                    ErrorString( ErrorStr.c_str() );
   TOutMsg                   ErrorMsg;

   ErrorMsg.Body           = ErrorString;

   TMsgData   Data         = ErrorMsg.GetMsgData();

   SendMsgData( Data );

}

