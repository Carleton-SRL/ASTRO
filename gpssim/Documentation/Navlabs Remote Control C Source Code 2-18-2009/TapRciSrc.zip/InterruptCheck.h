//---------------------------------------------------------------------------

#ifndef InterruptCheckH
#define InterruptCheckH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: InterruptCheck.h                                      $
//
// $Revision:: 3                                                     $
//
// $History:: InterruptCheck.h                                       $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:27p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef TpMapInterfaceH
#include "TpMapInterface.h"
#endif

//---------------------------------------------------------------------------

class TInterruptCheck : public TThread
{
private:

   TTpMapInterface         * TpMapInterface;
   bool                      TestMode;
   int                       IntCount;
   bool                      Valid;

protected:

   void __fastcall           Execute();

public:

   __fastcall                TInterruptCheck( TTpMapInterface * TpMapInterface );
   int const                 GetIntCount() const { return( IntCount ); }

};

//---------------------------------------------------------------------------

#endif
