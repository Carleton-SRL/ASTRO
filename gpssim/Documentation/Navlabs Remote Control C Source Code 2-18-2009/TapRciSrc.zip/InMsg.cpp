#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

#ifndef InMsgH
#include "InMsg.h"
#endif

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: InMsg.cpp                                             $
//
// $Revision:: 4                                                     $
//
// $History:: InMsg.cpp                                              $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:36p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:39p
//Updated in $/TapRci
//Add StripString to remove extraneous chars.
//
//
//---------------------------------------------------------------------------



#define MAX_IN_MSG_LENGTH ( 1000 )

TInMsg::TInMsg
   (
   ) :
   Valid( false ),
   MsgComplete( false ),
   Fields( NULL )
{
}

TInMsg::~TInMsg()
{
   delete Fields;
}

TInMsg::TInMsg
   (
   const TInMsg & InMsg
   ) :
   Valid( false ),
   MsgComplete( false ),
   Fields( NULL )
{
   (*this) = InMsg;
}

TInMsg &
TInMsg::operator=
   (
   const TInMsg &rhs
   )
{
   if ( this == &rhs )
   {
      return( *this );
   }

   Valid       = rhs.Valid;
   MsgComplete = rhs.Valid;
   MsgStr      = rhs.MsgStr;

   delete Fields;
   Fields = new TStringList;
   for ( int i=0; i<rhs.Fields->Count; ++i )
   {
      Fields->Add( rhs.Fields->Strings[i] );
   }

   return( *this );

}


bool const
TInMsg::ProcessData
   (
   TMsgData & NewMsgData
   )
{

   if ( !NewMsgData.empty() )
   {

      // Add a byte at a time, checking for valid or bad message each byte.
      // Remove each byte as it is used.
      //
      unsigned int i; // Outside loop as needed to erase used bytes

      for ( i=0; i<NewMsgData.size() && !IsMsgComplete(); ++i )
      {

         ProcessByte( (char) NewMsgData[i] ); // Checks for end/bad message

      }

      // Erase used bytes
      //
      TMsgData::iterator LastUsed = ( NewMsgData.begin() + i );
      NewMsgData.erase( NewMsgData.begin(), LastUsed );

   }

   return( IsMsgComplete() );

}


bool const
TInMsg::ProcessByte
   (
   const char Byte
   )
{

   if ( isascii( Byte ) )
   {


      if ( Byte == '$' )
      {

         MsgStr      = "$";

         Valid = false;

      }
      else
      {

         MsgStr += Byte;

         if ( Byte == '\n' )
         {

            ProcessMsg();

         }
         else
         {
            Valid = false;
         }

         if ( MsgStr.length() > MAX_IN_MSG_LENGTH )
         {
            MsgStr = "";
            Valid = false;
         }

      }

   }

   return( IsValid() );

}

void
TInMsg::ProcessMsg
   (
   )
{

   if ( MsgHasChecksum( MsgStr ) )
   {
      Valid       = IsChecksumValid( MsgStr );
   }
   else
   {
      Valid = true;
   }


   if ( Valid )
   {
      string sMsgStr = StripString( MsgStr );
      delete Fields;
      Fields = new TStringList();
      ExtractTokensL( sMsgStr.c_str(), AnsiString( "," ), '\'', true, Fields );
   }
   MsgComplete = true;

}

string
TInMsg::StripString
   (
   const string & InMsgStr
   ) const
{
   string sMsgStr = InMsgStr;
   if ( sMsgStr.find( '\n' ) < sMsgStr.length() )
   {
      sMsgStr.erase( sMsgStr.find( '\n' ), sMsgStr.length() );
   }
   if ( sMsgStr.find( '\r' ) < sMsgStr.length() )
   {
      sMsgStr.erase( sMsgStr.find( '\r' ), sMsgStr.length() );
   }
   if ( sMsgStr.find( '*' ) < sMsgStr.length() )
   {
      sMsgStr.erase( sMsgStr.find( '*' ), sMsgStr.length() );
   }
   return( sMsgStr );
}


bool const
TInMsg::IsChecksumValid
   (
   const string &Msg
   ) const
{

   // Compute checksum of message
   //
   unsigned char Checksum = ComputeChecksum( Msg );

   // Get the checksum sent
   //
   string ChckStr = Msg.substr( Msg.find( '*' ) + 1 );

   unsigned int MsgChecksum=0;

   sscanf( ChckStr.c_str(), "%2X", &MsgChecksum );

   // return true if computed equals sent
   //
   return((unsigned char) MsgChecksum == Checksum);
}

bool const
TInMsg::MsgHasChecksum
   (
   const string & Msg
   ) const
{

   return( Msg.find('*') < Msg.length() );

}

const unsigned char
TInMsg::ComputeChecksum
   (
   const string & Msg
   ) const
{
   unsigned char Checksum=0;

   // Checksum after '$' and before '*'
   //
   for ( unsigned long i=Msg.find('$')+1; i<( std::min( Msg.find('*'),Msg.length())); ++i )
   {
      Checksum ^= Msg[i];
   }
   return(Checksum);
}

bool const
TInMsg::IsValid
   (

   ) const
{
   return(Valid);
}


AnsiString const
TInMsg::GetMsgId
   (
   ) const
{


   AnsiString MsgId;

   if ( IsMsgComplete() )
   {
      int FirstFieldLength = Fields->Strings[0].Length() - 1;
      MsgId = Fields->Strings[0].SubString( 2, FirstFieldLength );
   }
   return( MsgId );

}


bool const
TInMsg::IsTypeFound
   (
   const string & HeaderStr
   ) const
{

   bool Found = false;
   if ( MsgStr.find(HeaderStr) != string::npos )
   {

      Found = true;

   }

   return(Found);

}
void
TInMsg::Clear()
{

   MsgStr      = "";
   Valid       = false;
   MsgComplete = false;

}

AnsiString const
TInMsg::GetMsgData
   (
   ) const
{
   return( AnsiString( MsgStr.c_str() ) );
}

void
TInMsg::GetFields
   (
   TStringList *StringList
   ) const
{
   StringList->Clear();

   // Exclude MsgId and checksum
   //
   for ( int i=1; i<Fields->Count; ++i )
   {
      StringList->Add( Fields->Strings[i] );
   }
}




