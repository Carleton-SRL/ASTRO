#ifndef TpMapInterfaceH
#define TpMapInterfaceH
//---------------------------------------------------------------------------
//
// $Workfile:: TpMapInterface.h                                      $
//
// $Revision:: 4                                                     $
//
// $History:: TpMapInterface.h                                       $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:30p
//Updated in $/TapRci
//Add properties for PPSCount/IntCount for External Reset Pulse.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 1/20/03    Time: 2:45p
//Updated in $/TapMsec
//Add ProgBoard
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 7/23/02    Time: 8:07p
//Updated in $/TapMsec
//Added Source Safe keywords
//
//---------------------------------------------------------------------------

#ifndef TpMapH
#include "TpMap.h"
#endif

#ifndef GpsTimeH
#include "GpsTime.h"
#endif

#ifndef TapBitH
#include "TapBit.h"
#endif

#ifndef TapMsecPfH
#include "TapMsecPf.h"
#endif

#ifndef VoyDefPfH
#include "VoyDefPf.h"
#endif

#define CHIP_STATUS_INIT ( 0x01 )
#define CHIP_STATUS_DONE ( 0x02 )
class THwChipStatus {
public:
   bool Init;
   bool Done;
public:
   THwChipStatus() : Init( false ), Done( false ) {}
};

class THwChipsStatus {
public:
   THwChipStatus x1;
   THwChipStatus x2;
   THwChipStatus x3;
};

//---------------------------------------------------------------------------
class TTpMapInterface {
private:
   HANDLE                    hTapPci;
   TPMAP                   * TpMap_;
   bool                      Valid_;
   bool                      TestMode_;
   bool                      BoardIntEnabled;
   bool                      UseInt;
   bool                      TestX1;
   bool                      TestX2;
   bool                      TestX3;
   bool                      TestInt;
   bool                      TestOcxo;
   bool                      TestPll;

   bool const                OpenInterface();
   int const                 GetIntCount() const;
   int const                 GetPPSCount() const;
   TPMAP*                    GetTpMap();
   bool const                IsTestMode() const { return( TestMode_ ); }
   bool const                IsValid() const { return( Valid_ ); }
   void                      ProgBoard();
   void                      GetHwChipBit(const unsigned char Status, TTapBitXChip  &TapBitXChip ) const;

   bool const                GetExtResetPulseRcvd();

//   bool const                GetArmExtResetPulse();
   void                      SetArmExtResetPulse( const bool InArmExtReset );

protected:
public:
   TTpMapInterface();
   virtual ~TTpMapInterface();

   bool const                WaitForInt();
   void                      CompensateTimeForSync( TGpsTime & Time, int RolloverCount, int PPSCount );
   void                      EnableInt( const bool Enable );
   void                      ResetCounters();
   TTapBitResults const      RunBit();

   __property int       IntCount            = { read = GetIntCount                                           };
   __property int       PPSCount            = { read = GetPPSCount                                           };
   __property TPMAP *   TpMap               = { read = GetTpMap                                              };
   __property bool      Valid               = { read = IsValid                                               };
   __property bool      TestMode            = { read = IsTestMode                                            };
   __property bool      ExtResetPulseRcvd   = { read = GetExtResetPulseRcvd                                  };
   __property bool      ArmExtResetPulse    = { /*read = GetArmExtResetPulse,*/ write = SetArmExtResetPulse  };

};

//---------------------------------------------------------------------------
#endif
