#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef GpibTimeoutH
#include "GpibTimeout.h"
#endif

#include "Decl-32.h"

//---------------------------------------------------------------------------
//
// $Workfile:: TapRciPf.cpp                                          $
//
// $Revision:: 5                                                     $
//
// $History:: TapRciPf.cpp                                           $
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 9/25/04    Time: 11:27p
//Updated in $/TapRci
//Additional com port params.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 4:41p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:01p
//Updated in $/TapRci
//Add various properties.
//
//
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
// Display Section [DISPLAY]
//
static const AnsiString DispSection("DISPLAY");

static const AnsiString DispRelativePowerKey( "DispRelativePower" );
static const int        DispRelativePowerDef( 1 );

//---------------------------------------------------------------------------
// Control Section [CONTROL]
//
static const AnsiString ControlSection("CONTROL");

static const AnsiString TapMsecPathKey( "TapMsecPath" );
static const AnsiString TapMsecPathDef( "c:\\voyager\\tapmsec\\tapmsec.exe" );
static const AnsiString WinVpgPathKey( "WinVpgPath" );
static const AnsiString WinVpgPathDef( "c:\\voyager\\WinVpg\\WinVpg.exe" );
static const AnsiString RemoteScnKey( "RemoteScn" );
static const AnsiString RemoteScnDef( "c:\\voyager\\runs\\TapRemote" );
static const AnsiString VerifyOperationAtStartKey( "VerifyOperationAtStart" );
static const int        VerifyOperationAtStartDef( 1 );
static const AnsiString WinVpgRequiredKey( "WinVpgRequired" );
static const int        WinVpgRequiredDef( 0 );

//---------------------------------------------------------------------------
// Interface Section [INTERFACE]
//
static const AnsiString InterfaceSection("INTERFACE");

static const AnsiString GpibKey( "Gpib" );
static const int        GpibDef( 0 );
static const AnsiString SerialKey( "Serial" );
static const int        SerialDef( 0 );
static const AnsiString EthernetKey( "Ethernet" );
static const int        EthernetDef( 0 );


//---------------------------------------------------------------------------
// GPIB Section [GPIB]
//
static const AnsiString GpibSection("GPIB");

static const AnsiString GpibPrimaryAddressKey( "GpibPrimaryAddress" );
static const int        GpibPrimaryAddressDef( 15 );
static const AnsiString GpibBoardIndexKey( "GpibBoardIndex" );
static const int        GpibBoardIndexDef( 0 );
static const AnsiString GpibTimeoutKey( "GpibTimeOut" );
static const int        GpibTimeoutIntDef( T100ms );
static const AnsiString GpibTimeoutDef( "T100ms" );
static const AnsiString GpibUseSRQKey( "UseSRQ" );
static const int        GpibUseSRQDef( 1 );

//---------------------------------------------------------------------------
// Serial Section [SERIAL]
//
static const AnsiString SerialSection("SERIAL");

static const AnsiString SerialComPortKey( "ComPort" );
static const int        SerialComPortDef( 1 );
static const AnsiString SerialBaudKey( "Baud" );
static const int        SerialBaudDef( 19200 );
static const AnsiString SerialStopBitsKey( "StopBits" );
static const int        SerialStopBitsDef( 1 );
static const AnsiString SerialDataBitsKey( "DataBits" );
static const int        SerialDataBitsDef( 8 );
static const AnsiString SerialParityKey( "Parity" );
static const AnsiString SerialParityDef( "None" );
static const AnsiString SerialHWFlowKey( "HWFlow" );
static const bool       SerialHWFlowDef( false );
static const AnsiString SerialSWFlowKey( "SWFlow" );
static const bool       SerialSWFlowDef( false );

//---------------------------------------------------------------------------
// Ethernet Section [ETHERNET]
//
static const AnsiString EthernetSection("ETHERNET");

static const AnsiString EthernetServerKey( "Server" );
static const bool       EthernetServerDef( 1 );
static const AnsiString EthernetHostAddressKey( "HostAddress" );
static const AnsiString EthernetHostAddressDef( "000.000.000.000" );
static const AnsiString EthernetPortNumKey( "PortNum" );
static const int        EthernetPortNumDef( 5000 );

//---------------------------------------------------------------------------
// Message Control (MSGCONTROL) Section
//
static const AnsiString MsgControlSection("MSGCONTROL");

static const AnsiString AckEveryKey( "AckEvery" );
static const int        AckEveryDef( 1 );
static const AnsiString ChanStatOnChangeKey( "ChanStatOnChange" );
static const int        ChanStatOnChangeDef( 0 );
static const AnsiString SimModeOnChangeKey( "SimModeOnChange" );
static const int        SimModeOnChangeDef( 1 );



TTapRciProfile::TTapRciProfile() : TIniFile("TapRci.ini")
{}

bool const
TTapRciProfile::GetDispRelativePower
   (

   )
{
   return( ReadInteger( DispSection, DispRelativePowerKey, DispRelativePowerDef ) );
}

void
TTapRciProfile::SetDispRelativePower
   (
   const bool DispRelativePower
   )
{
   WriteInteger( DispSection, DispRelativePowerKey, DispRelativePower );
}

AnsiString const
TTapRciProfile::GetTapMsecPath
   (
   )
{
   return( ReadString( ControlSection, TapMsecPathKey, TapMsecPathDef ) );
}

void
TTapRciProfile::SetTapMsecPath
   (
   const AnsiString        & InTapMsecPath
   )
{

   WriteString( ControlSection, TapMsecPathKey, InTapMsecPath );

}

AnsiString const
TTapRciProfile::GetWinVpgPath
   (
   )
{
   return( ReadString( ControlSection, WinVpgPathKey, WinVpgPathDef ) );
}

void
TTapRciProfile::SetWinVpgPath
   (
   const AnsiString        & InWinVpgPath
   )
{

   WriteString( ControlSection, WinVpgPathKey, InWinVpgPath );

}

AnsiString const
TTapRciProfile::GetRemoteScn
   (
   )
{
   return( ReadString( ControlSection, RemoteScnKey, RemoteScnDef ) );
}

void
TTapRciProfile::SetRemoteScn
   (
   const AnsiString &RemoteScn
   )
{

   WriteString( ControlSection, RemoteScnKey, RemoteScn );

}   

bool const
TTapRciProfile::GetGpib
   (

   )
{
   return( ReadInteger( InterfaceSection, GpibKey, GpibDef ) );
}

void
TTapRciProfile::SetGpib
   (
   const bool Gpib
   )
{
   WriteInteger( InterfaceSection, GpibKey, Gpib );
}

bool const
TTapRciProfile::GetSerial
   (

   )
{
   return( ReadInteger( InterfaceSection, SerialKey, SerialDef ) );
}

void
TTapRciProfile::SetSerial
   (
   const bool Serial
   )
{
   WriteInteger( InterfaceSection, SerialKey, Serial );
}

bool const
TTapRciProfile::GetEthernet
   (

   )
{
   return( ReadInteger( InterfaceSection, EthernetKey, EthernetDef ) );
}

void
TTapRciProfile::SetEthernet
   (
   const bool Ethernet
   )
{
   WriteInteger( InterfaceSection, EthernetKey, Ethernet );
}

int const
TTapRciProfile::GetGpibPrimaryAddress
   (

   )
{
   return( ReadInteger( GpibSection, GpibPrimaryAddressKey, GpibPrimaryAddressDef ) );
}

void
TTapRciProfile::SetGpibPrimaryAddress
   (
   const int GpibPrimaryAddress
   )
{
   WriteInteger( GpibSection, GpibPrimaryAddressKey, GpibPrimaryAddress );
}

int const
TTapRciProfile::GetGpibBoardIndex
   (

   )
{
   return( ReadInteger( GpibSection, GpibBoardIndexKey, GpibBoardIndexDef ) );
}

void
TTapRciProfile::SetGpibBoardIndex
   (
   const int GpibBoardIndex
   )
{
   WriteInteger( GpibSection, GpibBoardIndexKey, GpibBoardIndex );
}

int const
TTapRciProfile::GetGpibTimeout
   (
   )
{
   TGpibTimeout GpibTime( GpibTimeoutIntDef );
   AnsiString GpibTimeoutStr = ReadString( GpibSection, GpibTimeoutKey, GpibTimeoutDef );
   return( GpibTime.GetTimeout( GpibTimeoutStr ) );
}

void
TTapRciProfile::SetGpibTimeout
   (
   const int Timeout
   )
{
   TGpibTimeout GpibTime( GpibTimeoutIntDef );
   WriteString( GpibSection, GpibTimeoutKey, GpibTime.GetTimeoutStr( Timeout ) );
}

//---------------------------------------------------------------------------
//   Serial Port
//---------------------------------------------------------------------------

int const
TTapRciProfile::GetSerialComPort
   (
   )
{
   return( ReadInteger( SerialSection, SerialComPortKey, SerialComPortDef ) );
}

void
TTapRciProfile::SetSerialComPort
   (
   const int                 InSerialComPort
   )
{
   WriteInteger( SerialSection, SerialComPortKey, InSerialComPort );
}

int const
TTapRciProfile::GetSerialBaud
   (

   )
{
   return( ReadInteger( SerialSection, SerialBaudKey, SerialBaudDef ) );
}

void
TTapRciProfile::SetSerialBaud
   (
   const int                 InSerialBaud
   )
{
   WriteInteger( SerialSection, SerialBaudKey, InSerialBaud );
}

int const
TTapRciProfile::GetSerialStopBits
   (

   )
{
   const int Stop          = ReadInteger( SerialSection, SerialStopBitsKey, SerialStopBitsDef );
   int Ret                 = ONESTOPBIT;
   if ( Stop == 2 )
   {
      Ret                  = TWOSTOPBITS;
   }

   return( Ret );
   
}

void
TTapRciProfile::SetSerialStopBits
   (
   const int                 InSerialStopBits
   )
{
   int Value               = 1;
   if ( InSerialStopBits == TWOSTOPBITS )
   {
      Value                = 2;
   }
   WriteInteger( SerialSection, SerialStopBitsKey, Value );
}

int const
TTapRciProfile::GetSerialDataBits
   (

   )
{
   const int ReadByteSize  = ReadInteger( SerialSection, SerialDataBitsKey, SerialDataBitsDef );
   const int ByteSize      = ( ReadByteSize == 7 ) ? ( 7 ) : ( 8 );
   return( ByteSize );
}

void
TTapRciProfile::SetSerialDataBits
   (
   const int                 InSerialDataBits
   )
{
   WriteInteger( SerialSection, SerialDataBitsKey, InSerialDataBits );
}

int const
TTapRciProfile::GetSerialParity
   (

   )
{
   AnsiString ParityStr    = ReadString( SerialSection, SerialParityKey, SerialParityDef );
   AnsiString uParityStr   = ParityStr.UpperCase();
   const bool ParityEven   = ( uParityStr.Pos( "EVEN" ) != 0 );
   const bool ParityOdd    = ( uParityStr.Pos( "ODD" )  != 0 );

   int Ret                 = NOPARITY;
   if ( ParityEven )
   {
      Ret                  = EVENPARITY;
   }
   else if ( ParityOdd )
   {
      Ret                  = ODDPARITY;
   }

   return( Ret );

}

void
TTapRciProfile::SetSerialParity
   (
   const int                 InSerialParity
   )
{

   AnsiString ParityStr( "NONE" );

   if ( InSerialParity == EVENPARITY )
   {
      ParityStr            = AnsiString( "EVEN" );
   }
   else if ( InSerialParity == ODDPARITY )
   {
      ParityStr            = AnsiString( "ODD" );
   }

   WriteString( SerialSection, SerialParityKey, ParityStr );

}

bool const
TTapRciProfile::GetSerialHWFlow
   (

   )
{
   return( ReadBool( SerialSection, SerialHWFlowKey, SerialHWFlowDef ) );
}

void
TTapRciProfile::SetSerialHWFlow
   (
   const bool                InSerialHWFlow
   )
{
   WriteBool( SerialSection, SerialHWFlowKey, InSerialHWFlow );
}

bool const
TTapRciProfile::GetSerialSWFlow
   (

   )
{
   return( ReadBool( SerialSection, SerialSWFlowKey, SerialSWFlowDef ) );
}

void
TTapRciProfile::SetSerialSWFlow
   (
   const bool                InSerialSWFlow
   )
{
   WriteBool( SerialSection, SerialSWFlowKey, InSerialSWFlow );
}
//---------------------------------------------------------------------------
// Ethernet
//---------------------------------------------------------------------------

bool const
TTapRciProfile::GetEthernetServer
   (

   )
{
   return( ReadInteger( EthernetSection, EthernetServerKey, EthernetServerDef ) );
}

void
TTapRciProfile::SetEthernetServer
   (
   const bool IsEthernetServer
   )
{
   WriteInteger( EthernetSection, EthernetServerKey, IsEthernetServer );
}

AnsiString const
TTapRciProfile::GetEthernetHostAddress
   (

   )
{
   return( ReadString( EthernetSection, EthernetHostAddressKey, EthernetHostAddressDef ) );
}

void
TTapRciProfile::SetEthernetHostAddress
   (
   const AnsiString &EthernetHostAddress
   )
{
   WriteString( EthernetSection, EthernetHostAddressKey, EthernetHostAddress );
}

int const
TTapRciProfile::GetEthernetPortNum
   (

   )
{
   return( ReadInteger( EthernetSection, EthernetPortNumKey, EthernetPortNumDef ) );
}

void
TTapRciProfile::SetEthernetPortNum
   (
   const int EthernetPortNum
   )
{
   WriteInteger( EthernetSection, EthernetPortNumKey, EthernetPortNum );
}


bool const
TTapRciProfile::GetAckEvery
   (

   )
{
   return( ReadInteger( MsgControlSection, AckEveryKey, AckEveryDef ) );
}

void
TTapRciProfile::SetAckEvery
   (
   const bool AckEvery
   )
{
   WriteInteger( MsgControlSection, AckEveryKey, AckEvery );
}

bool const
TTapRciProfile::GetVerifyOperationAtStart
   (

   )
{
   return( ReadInteger( ControlSection, VerifyOperationAtStartKey, VerifyOperationAtStartDef ) );
}

void
TTapRciProfile::SetVerifyOperationAtStart
   (
   const bool VerifyOperationAtStart
   )
{
   WriteInteger( ControlSection, VerifyOperationAtStartKey, VerifyOperationAtStart );
}

bool const
TTapRciProfile::GetWinVpgRequired
   (

   )
{
   return( ReadInteger( ControlSection, WinVpgRequiredKey, WinVpgRequiredDef ) );
}

void
TTapRciProfile::SetWinVpgRequired
   (
   const bool WinVpgRequired
   )
{
   WriteInteger( ControlSection, WinVpgRequiredKey, WinVpgRequired );
}

bool const
TTapRciProfile::GetGpibUseSRQ
   (
   )
{
   return( ReadBool( GpibSection, GpibUseSRQKey, GpibUseSRQDef ) );
}

void
TTapRciProfile::SetGpibUseSRQ
   (
   const bool InUseSRQ
   )
{
   WriteBool( GpibSection, GpibUseSRQKey, InUseSRQ );
}

bool const
TTapRciProfile::GetChanStatOnChange
   (
   )
{
   return( ReadBool( MsgControlSection, ChanStatOnChangeKey, ChanStatOnChangeDef ) );
}

void
TTapRciProfile::SetChanStatOnChange
   (
   const bool                InChanStatOnChange
   )
{
   WriteBool( MsgControlSection, ChanStatOnChangeKey, InChanStatOnChange );
}

bool const
TTapRciProfile::GetSimModeOnChange
   (
   )
{
   return( ReadBool( MsgControlSection, SimModeOnChangeKey, SimModeOnChangeDef ) );
}

void
TTapRciProfile::SetSimModeOnChange
   (
   const bool                InSimModeOnChange
   )
{
   WriteBool( MsgControlSection, SimModeOnChangeKey, InSimModeOnChange );
}

eIntType const
TTapRciProfile::GetIntType
   (
   )
{
   eIntType RetIntType;

   if ( Gpib )
   {
      RetIntType = eIntGpib;
   }
   else if ( EthernetServer )
   {
      RetIntType = eIntEthernet;
   }
   else if ( Serial )
   {
      RetIntType = eIntSerial;
   }

   return( RetIntType );

}

void
TTapRciProfile::SetIntType
   (
   const eIntType InIntType
   )
{

   bool IntGpib           = false;
   bool IntEthernet       = false;
   bool IntSerial         = false;

   if ( InIntType == eIntGpib )
   {
      IntGpib           = true;
   }
   else if ( InIntType == eIntEthernet )
   {
      IntEthernet       = true;
   }
   else if ( InIntType == eIntSerial )
   {
      IntSerial         = true;
   }

   Gpib           = IntGpib;
   Ethernet       = IntEthernet;
   Serial         = IntSerial;

}


