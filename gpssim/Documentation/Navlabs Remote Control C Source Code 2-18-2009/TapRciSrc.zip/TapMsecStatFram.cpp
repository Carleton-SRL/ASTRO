#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: TapMsecStatFram.cpp                                   $
//
// $Revision:: 7                                                     $
//
// $History:: TapMsecStatFram.cpp                                    $
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:02p
//Updated in $/TapRci
//LED to standard text.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:29p
//Updated in $/TapRci
//Add TimeSetPulse for LM Garrett.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:16p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:21p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:59p
//Updated in $/TapRci
//Add TapMsecStat property.
//
//
//---------------------------------------------------------------------------


#ifndef TapMsecStatFramH
#include "TapMsecStatFram.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ovclabel"
#pragma link "RzLabel"
#pragma link "RzPanel"
#pragma link "RzSplit"
#pragma link "RzBorder"
#pragma link "RzBckgnd"
#pragma resource "*.dfm"
TTapMsecStatFrame *TapMsecStatFrame;
//---------------------------------------------------------------------------
__fastcall
TTapMsecStatFrame::TTapMsecStatFrame
   (
   TComponent* Owner
   ) :
   TFrame( Owner ),
   pGeoFormat( NULL )
{

   pGeoFormat        = new GeoFormat();
   DispRelativePower = IsDispRelativePower();

   SetNewDispRelativePower();

   // Setup Channel Status
   //
   for ( int i=0; i<NUM_CHANS_IN_STAT; ++i )
   {

      TChanStatFrame *ChanStatFrame = new TChanStatFrame( this, i, DispRelativePower );
      ChanStatFrame->Name           = Name + AnsiString( "ChanStatFrame" ) + AnsiString( i );
      ChanStatFrame->Parent         = ChanStatScrollBox;
      ChanStatFrame->Align          = alTop;
      ChanStatFrame->Visible        = true;

      ChanStatFrameArray.push_back( ChanStatFrame );

   }

   ClearDisplay();

}
__fastcall
TTapMsecStatFrame::~TTapMsecStatFrame()
{
   delete pGeoFormat;
}

bool const
TTapMsecStatFrame::IsDispRelativePower
   (
   ) const
{
   TTapRciProfile *TapRciProfile = new TTapRciProfile();
   bool           DispRelative   = TapRciProfile->DispRelativePower;
   delete TapRciProfile;

   return( DispRelative );

}

void
TTapMsecStatFrame::SetNewDispRelativePower
   (
   )
{

   DispRelativePower = IsDispRelativePower();

   for ( unsigned int i=0; i<ChanStatFrameArray.size(); ++i )
   {
      ChanStatFrameArray[i]->SetDispRelativePower( DispRelativePower );
   }

   if ( DispRelativePower )
   {
      L1PowerLbl->Caption = "L1 Attn";
      L2PowerLbl->Caption = "L2 Attn";
   }
   else
   {
      L1PowerLbl->Caption = "L1 Pwr";
      L2PowerLbl->Caption = "L2 Pwr";
   }

}

void
TTapMsecStatFrame::ClearDisplay()
{

   CurWeekVal->Caption   = "";
   CurSecsVal->Caption   = "";

   StartWeekVal->Caption = "";
   StartSecsVal->Caption = "";

   SecsIntoSimVal->Caption = "";
   SecsLeftVal->Caption    = "";

   LatVal->Caption         = "";
   LonVal->Caption         = "";
   AltVal->Caption         = "";

   VelNorthVal->Caption    = "";
   VelEastVal->Caption     = "";
   VelDownVal->Caption     = "";

   RFGainVal->Caption      = "";

}

void
TTapMsecStatFrame::SetTapMsecStat
   (
   const TTapMsecStat &InTapMsecStat
   )
{

   TapMsecStat_       = InTapMsecStat;

   TTapMsecStatDisp TapMsecStatDisp( TapMsecStat_ );

   int NumChansInLoop = std::min( NUM_CHANS_IN_STAT, (int) ChanStatFrameArray.size() );
   for ( int i=0; i<NumChansInLoop; ++i )
   {
      ChanStatFrameArray[i]->SetChanStat( TapMsecStat.ChanStat[i] );
   }

   for ( unsigned int i=NumChansInLoop; i<ChanStatFrameArray.size(); ++i )
   {
      TTapMsecStatChan TapMsecStatChan;
      ChanStatFrameArray[i]->SetChanStat( TapMsecStatChan );
   }

   ScenarioNameLbl->Caption    = TapMsecStatDisp.ScenarioName;
   SimModeLbl->Caption         = TapMsecStatDisp.RunModeString;
   SimModeLbl->Font->Color     = TapMsecStatDisp.RunModeLblColor;

   if ( IsRunModeRunning( TapMsecStat.eRunMode ) )
   {

      CurWeekVal->Caption      = AnsiString( TapMsecStat_.CurWeek );
      CurSecsVal->Caption      = AnsiString( NINT( TapMsecStat_.CurSeconds ) );

      StartWeekVal->Caption    = AnsiString( TapMsecStat.StartWeek );
      StartSecsVal->Caption    = AnsiString( NINT( TapMsecStat_.StartSeconds ) );

      SecsIntoSimVal->Caption  = AnsiString( NINT( TapMsecStat_.SecondsIntoSim ) );
      SecsLeftVal->Caption     = AnsiString( NINT( TapMsecStat_.SecondsRemaining ) );

      LatVal->Caption          = pGeoFormat->LattoStr( TapMsecStat_.Lat );
      LonVal->Caption          = pGeoFormat->LontoStr( TapMsecStat_.Lon );
      AltVal->Caption          = pGeoFormat->AlttoStr( TapMsecStat_.Alt );

      VelNorthVal->Caption     = pGeoFormat->VeltoStr( TapMsecStat_.VelNorth );
      VelEastVal->Caption      = pGeoFormat->VeltoStr( TapMsecStat_.VelEast );
      VelDownVal->Caption      = pGeoFormat->VeltoStr( TapMsecStat_.VelDown );

      RFGainVal->Caption       = AnsiString( NINT( TapMsecStat_.RFGain ) );

   }
   else
   {
      ClearDisplay();
   }

   ErrorLbl->Visible           = TapMsecStat_.Error;
   ErrorStrLbl->Visible        = TapMsecStat_.Error;
   ErrorStrLbl->Caption        = TapMsecStat_.Error ? AnsiString( TapMsecStat_.ErrorStr ) : AnsiString( "" );

}



//---------------------------------------------------------------------------
