//---------------------------------------------------------------------------


#ifndef TapMsecStatFramH
#define TapMsecStatFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: TapMsecStatFram.h                                     $
//
// $Revision:: 7                                                     $
//
// $History:: TapMsecStatFram.h                                      $
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:02p
//Updated in $/TapRci
//LED to standard text.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:29p
//Updated in $/TapRci
//Add TimeSetPulse for LM Garrett.  SimMode Color, label style.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 2/04/03    Time: 11:09a
//Updated in $/TapRci
//Added panels to seperate sim stat, veh stat, errors.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:21p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:59p
//Updated in $/TapRci
//Add TapMsecStat property.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include "RzLabel.hpp"
#include "RzPanel.hpp"
#include "RzSplit.hpp"
#include <ExtCtrls.hpp>
#include "RzBorder.hpp"
#include "RzBckgnd.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef ChanStatFramH
#include "ChanStatFram.h"
#endif

#ifndef GeoFrmtH
#include "GeoFrmt.h"
#endif

#ifndef TapMsecRciH
#include "TapMsecRci.h"
#endif

//---------------------------------------------------------------------------
      static const TColor RunModeLblClrs[4] = { clBlack, clBlue, clLime, clYellow };


class TTapMsecStatDisp {
private:

   TTapMsecStat              TapMsecStat_;

   AnsiString const          GetRunModeString() const
   {
      AnsiString RetRunModeString( "N/A" );

      if ( TapMsecStat_.eRunMode == eRUN_IDLE )
      {
         RetRunModeString = "Idle";
      }
      else if ( TapMsecStat_.eRunMode == eRUN_SCEN )
      {
         RetRunModeString = "Run Scen";
      }
      else if ( TapMsecStat_.eRunMode == eRUN_LOCAL )
      {
         RetRunModeString = AnsiString( "Run Local" );
      }
      else if ( TapMsecStat_.eRunMode == eRUN_WAITFORRESETPULSE )
      {
         RetRunModeString = AnsiString( "Wait for Reset Pulse" );
      }

      return( RetRunModeString );
   }

   AnsiString const          GetScenarioName() const
   {

      AnsiString ScenName = AnsiString( "" );

      try
      {

         if ( TapMsecStat_.eRunMode == eRUN_SCEN )
         {
            ScenName          = AnsiString( TapMsecStat_.ScenarioName );
         }

      }
      catch(...)
      {
         ScenName          = AnsiString( "" );
      }

      return( ScenName );
   }

   TColor const              GetRunModeLblColor() const
   {


      TColor RetColor      = ValidRunMode ? RunModeLblClrs[(int) TapMsecStat_.eRunMode] : clRed;

      return( RetColor );

   }

   bool const                GetValidRunMode() const
   {
      const bool ValMode =
         ( TapMsecStat_.eRunMode == eRUN_IDLE  ) || ( TapMsecStat_.eRunMode == eRUN_SCEN ) ||
         ( TapMsecStat_.eRunMode == eRUN_LOCAL ) || ( TapMsecStat_.eRunMode == eRUN_WAITFORRESETPULSE );

      return( ValMode );
   }

public:

   TTapMsecStatDisp( const TTapMsecStat & InTapMsecStat ) : TapMsecStat_( InTapMsecStat ) {}

   TTapMsecStatDisp( const TTapMsecStatDisp & Source )
   {
      ( *this ) = Source;
   }

   TTapMsecStatDisp & operator=( const TTapMsecStatDisp & Source )
   {
      if ( this == &Source ) return( *this );

      TapMsecStat_         = Source.TapMsecStat_;

      return( *this );
   }

   __property AnsiString   RunModeString   = { read = GetRunModeString                   };
   __property AnsiString   ScenarioName    = { read = GetScenarioName                    };
   __property TColor       RunModeLblColor = { read = GetRunModeLblColor                 };
   __property bool         ValidRunMode    = { read = GetValidRunMode                    };

};


class TTapMsecStatFrame : public TFrame
{
__published:
   TRzPanel *StatTopPnl;
   TOvcLabel *IntLbl;
   TOvcLabel *OvcLabel1;
   TRzSizePanel *RightMainSizePnl;
   TScrollBox *ChanStatScrollBox;
   TRzPanel *MainClientPnl;
   TOvcLabel *ScenarioNameLbl;
   TRzPanel *RzPanel1;
   TRzLabel *RzLabel2;
   TRzLabel *RzLabel3;
   TRzLabel *L1PowerLbl;
   TRzLabel *L2PowerLbl;
   TRzLabel *RzLabel4;
   TRzLabel *RzLabel5;
   TRzSeparator *RzSeparator1;
   TRzPanel *SimStatPnl;
   TOvcLabel *OvcLabel2;
   TRzPanel *VehStatePnl;
   TOvcLabel *OvcLabel11;
   TRzPanel *ErrorPnl;
   TOvcLabel *ErrorStrLbl;
   TOvcLabel *ErrorLbl;
   TRzLabel *SimModeLblRaize;
   TOvcLabel *SimModeLbl;
   TRzLabel *CurSecsLbl;
   TRzLabel *CurSecsVal;
   TRzLabel *CurWeekVal;
   TRzLabel *CurWeekLbl;
   TRzLabel *StartWeekLbl;
   TRzLabel *RzLabel6;
   TRzLabel *StartWeekVal;
   TRzLabel *StartSecsVal;
   TRzLabel *RfGainLbl;
   TRzLabel *RFGainVal;
   TRzLabel *AltVal;
   TRzLabel *AltLbl;
   TRzLabel *LonLbl;
   TRzLabel *LonVal;
   TRzLabel *LatVal;
   TRzLabel *LatLbl;
   TRzLabel *VelNorthLbl;
   TRzLabel *VelNorthVal;
   TRzLabel *VelEastLbl;
   TRzLabel *VelEastVal;
   TRzLabel *VelDownLbl;
   TRzLabel *VelDownVal;
   TRzLabel *SecsIntoSimLbl;
   TRzLabel *SecsLeftLbl;
   TRzLabel *SecsIntoSimVal;
   TRzLabel *SecsLeftVal;
private:

   bool                      DispRelativePower;
   bool const                IsDispRelativePower() const;
   TChanStatFrameArray       ChanStatFrameArray;
   TTapMsecStat              TapMsecStat_;
   GeoFormat               * pGeoFormat;
   void                      ClearDisplay();
   void                      SetTapMsecStat( const TTapMsecStat &InTapMsecStat );
   TTapMsecStat const        GetTapMsecStat() const { return( TapMsecStat_ ); }

public:
   __fastcall                TTapMsecStatFrame(TComponent* Owner);
   __fastcall virtual       ~TTapMsecStatFrame();
   void                      SetNewDispRelativePower();

   __property TTapMsecStat TapMsecStat = { read = GetTapMsecStat, write = SetTapMsecStat };

};
//---------------------------------------------------------------------------
extern PACKAGE TTapMsecStatFrame *TapMsecStatFrame;
//---------------------------------------------------------------------------
#endif
