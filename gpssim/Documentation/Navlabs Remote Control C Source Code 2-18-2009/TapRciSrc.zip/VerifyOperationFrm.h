//---------------------------------------------------------------------------

#ifndef VerifyOperationFrmH
#define VerifyOperationFrmH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: VerifyOperationFrm.h                                  $
//
// $Revision:: 4                                                     $
//
// $History:: VerifyOperationFrm.h                                   $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:20p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:05p
//Updated in $/TapRci
//Add interface types.
//Add WinVpg.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include "RzBorder.hpp"
#include "RzPanel.hpp"
#include "RzSplit.hpp"
#include <ExtCtrls.hpp>
#include "RzButton.hpp"
#include "RzDlgBtn.hpp"
#include "SsBase.hpp"
#include "StBrowsr.hpp"
#include "o32flxbn.hpp"
#include <Buttons.hpp>
#include "RzCmboBx.hpp"
#include "BitResultsFram.h"
#include "InterfaceAcceptFram.h"
#include "RzCommon.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef AcceptInterfaceOptionsH
#include "AcceptInterfaceOptions.h"
#endif

#ifndef BitResultsFramH
#include "BitResultsFram.h"
#endif

#ifndef GpibIntOptionsFramH
#include "GpibIntOptionsFram.h"
#endif

#ifndef InterfaceAcceptFramH
#include "InterfaceAcceptFram.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef VoyDefPfH
#include "VoyDefPf.h"
#endif

class TRciStatus {

public:

   bool   DriverValid;
   bool   TapMsecPathValid;
   bool   WinVpgPathValid;
   bool   RemoteScnValid;
   bool   BitResultsValid;

public:

   TRciStatus() : DriverValid( false ), TapMsecPathValid( false ), WinVpgPathValid( false ), RemoteScnValid( false ), BitResultsValid( false ) {}

};
//---------------------------------------------------------------------------
class TVerifyOperationForm : public TForm
{
__published:	// IDE-managed Components
   TRzSizePanel *LeftSizePnl;
   TRzPanel *LeftPnl;
   TRzPanel *MainClientPnl;
   TRzSizePanel *TopSizePnl;
   TRzPanel *InterfacePnl;
   TRzDialogButtons *RzDialogButtons1;
   TStBrowser *StBrowserRemoteDir;
   TRzPanel *RciParamsTitlePnl;
   TOvcLabel *RCIParametersTitle;
   TRzPanel *RciParametersValidPnl;
   TOvcLabel *SimDrvrValidDescLbl;
   TOvcLabel *SimDrvrValidLbl;
   TOvcLabel *TapMsecPathValidDescLbl;
   TOvcLabel *TapMsecPathValidLbl;
   TOvcLabel *WinVpgPathValidDescLbl;
   TOvcLabel *WinVpgPathValidLbl;
   TOvcLabel *RemoteScnValidDescLbl;
   TOvcLabel *RemoteScnValidLbl;
   TRzPanel *TapMsecPathPnl;
   TRzBitBtn *TapMsecPathBtn;
   TOvcLabel *TapMsecPathLbl;
   TRzPanel *RemoteScnPathPnl;
   TRzBitBtn *RemoteScnBtn;
   TOvcLabel *RemoteScnLbl;
   TRzPanel *WinVpgPathPnl;
   TRzBitBtn *WinVpgPathBtn;
   TOvcLabel *WinVpgPathLbl;
   TRzPanel *InterfaceTypePnl;
   TOvcLabel *InterfaceTypeTitleLbl;
   TRzComboBox *InterfaceSelectcbox;
   TInterfaceAcceptFrame *InterfaceAccept;
   TBitResultsFrame *BitResultsFrame;
   void __fastcall TapMsecPathBtnClick(TObject *Sender);
   void __fastcall WinVpgPathBtnClick(TObject *Sender);
   void __fastcall RemoteScnBtnClick(TObject *Sender);
   void __fastcall RzDialogButtons1ClickOk(TObject *Sender);
   void __fastcall InterfaceSelectcboxChange(TObject *Sender);
private:

   TTapRciProfile          * TapRciProfile;
   VoyDefProfile           * Vdp;
   bool                      OperationError_;
   TRciStatus                RciStatus;
   TTapBitResults            TapBitResults;
   eIntType                  IntType;
   TFrame                  * IntOptionsFrame;
   IAcceptInterfaceOptions * AcceptOptions;

   void                      CheckStatus( TRciStatus & CurRciStatus, TTapBitResults & CurTapBitResults );
   void                      SetDisp();
   void                      SetPassFail( const bool Passed, TOvcLabel  * Lbl );
   bool const                IsValidScenario( const AnsiString & ScenarioRoot );
   eIntType const            GetIntTypeFromItem( const int Item ) const;
   void                      SetIntType( const eIntType NewIntType );
   bool const                GetOperationError() const { return( OperationError_ ); }

public:

   __fastcall                TVerifyOperationForm( TComponent * Owner);
   virtual __fastcall       ~TVerifyOperationForm();

   __property bool           OperationError = { read = GetOperationError               };


};
//---------------------------------------------------------------------------
extern PACKAGE TVerifyOperationForm *VerifyOperationForm;
//---------------------------------------------------------------------------
#endif
