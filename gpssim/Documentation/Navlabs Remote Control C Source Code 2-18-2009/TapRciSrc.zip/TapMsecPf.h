#ifndef TapMsecPfH
#define TapMsecPfH

//---------------------------------------------------------------------------
//
// $Workfile:: TapMsecPf.h                                           $
//
// $Revision:: 3                                                     $
//
// $History:: TapMsecPf.h                                            $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:58p
//Updated in $/TapRci
//Default BIT to not test.
//
//
//---------------------------------------------------------------------------


using namespace std;


//---------------------------------------------------------------------------
class TTapMsecProfile : public TIniFile  {
private:
protected:
public:
   TTapMsecProfile();
   bool const IsCreateRcvrAsDialog();
   void WriteCreateRcvrAsDialog(const bool CreateRcvrAsDialog);
   bool const IsUseGpsTimeForXAxis();
   void WriteUseGpsTimeForXAxis(const bool UseXAxis);
   bool const IsResetErrPlotOnTimeReset();
   void WriteResetErrPlotOnTimeReset(const bool Reset);
   double const GetAttenIncrement();
   void WriteAttenIncrement(const double AttenIncrement);


   void GetPos(double &Lat,double &Lon,double &Alt);
   TDateTime const GetDate();
   TDateTime const GetTime();
   bool const GetInitFromClock();
   void SetPos(double Lat, double Lon, double Alt);
   void SetDate(const TDateTime &Date);
   void SetTime(const TDateTime &Time);
   void SetInitFromClock(bool InitFromClock);
   bool const GetRefLocalTime();
   bool const IsShowDebug();
   void SetRefLocalTime(const bool RefLocalTime);
   bool const IsLogMissedInts();
   bool const IsDispRelativePower();
   void WriteDispRelativePower( const bool DispRelativePower );
   bool const IsPPSAlwaysOn();
   int  const GetPPSWidth();
   void WritePPSAlwaysOn( const bool PPSAlwaysOn );
   void WritePPSWidth( const int PPSWidth );
   bool const IsBitTestX1();
   bool const IsBitTestX2();
   bool const IsBitTestX3();
   void WriteBitTestX1( const bool TestX1 );
   void WriteBitTestX2( const bool TestX2 );
   void WriteBitTestX3( const bool TestX3 );
   bool const IsBitTestInt();
   void WriteBitTestInt( const bool TestInt );
   bool const IsBitTestOcxo();
   void WriteBitTestOcxo( const bool TestOcxo );
   bool const IsBitTestPll();
   void WriteBitTestPll( const bool TestPll );

};

//---------------------------------------------------------------------------
#endif
