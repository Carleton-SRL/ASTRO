//---------------------------------------------------------------------------

#ifndef PowerDispFrmH
#define PowerDispFrmH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: PowerDispFrm.h                                        $
//
// $Revision:: 2                                                     $
//
// $History:: PowerDispFrm.h                                         $
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:50p
//Updated in $/TapRci
//Minor cleanup.
//
//
//---------------------------------------------------------------------------



//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "RzPanel.hpp"
#include "RzRadGrp.hpp"
#include <ExtCtrls.hpp>
#include "ovclabel.hpp"
#include "RzDlgBtn.hpp"
#include <Classes.hpp>
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

//---------------------------------------------------------------------------
class TPowerDispForm : public TForm
{
__published:
   TRzRadioGroup *PowerDispGrp;
   TOvcLabel *OvcLabel5;
   TRzDialogButtons *DlgBtns;
   void __fastcall DlgBtnsClickOk(TObject *Sender);
   void __fastcall DlgBtnsClickCancel(TObject *Sender);
private:

public:

   __fastcall TPowerDispForm( TComponent * Owner );

};
//---------------------------------------------------------------------------
extern PACKAGE TPowerDispForm *PowerDispForm;
//---------------------------------------------------------------------------
#endif
