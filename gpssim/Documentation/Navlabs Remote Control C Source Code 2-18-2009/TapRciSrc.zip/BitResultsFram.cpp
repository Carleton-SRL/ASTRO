#include "pch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: BitResultsFram.cpp                                    $
//
// $Revision:: 4                                                     $
//
// $History:: BitResultsFram.cpp                                     $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:18p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 9:52p
//Updated in $/TapRci
//Add Source Safe keywords.
//Add include file guards.
//Add #ifndef for OS/ VCL includes.
//Minor display changes.
//Minor code cleanup.
//
//
//---------------------------------------------------------------------------

#ifndef BitResultsFramH
#include "BitResultsFram.h"
#endif

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ovclabel"
#pragma link "RzBorder"
#pragma link "RzPanel"
#pragma link "RzCommon"
#pragma resource "*.dfm"
TBitResultsFrame *BitResultsFrame;
//---------------------------------------------------------------------------

__fastcall
TBitResultsFrame::TBitResultsFrame
   (
   TComponent* Owner
   ) :
   TFrame(Owner)
{

   TTapBitResults DefTapBitResults;
   SetBitResults( DefTapBitResults );
   
}
//---------------------------------------------------------------------------

void
TBitResultsFrame::DispBitResults
   (
   const TTapBitResults & BitResults
   )
{

   TChipLblStruct ChipLbls[3] =
   {
      { X1Lbl, X1Init, X1Done },
      { X2Lbl, X2Init, X2Done },
      { X3Lbl, X3Init, X3Done }
   };

   if ( BitResults.Valid )
   {
      DateLbl->Caption = BitResults.DateTime.DateString();
      TimeLbl->Caption = BitResults.DateTime.TimeString();

      DispChip( BitResults.x1, ChipLbls[0] );
      DispChip( BitResults.x2, ChipLbls[1] );
      DispChip( BitResults.x3, ChipLbls[2] );

      DispBitBase( BitResults.Interrupt, IntLbl, IntResultsLbl );
      DispBitBase( BitResults.Ocxo, OcxoLbl, OcxoResultsLbl );
      DispBitBase( BitResults.Pll, PllLbl, PllResultsLbl );


   }
   else
   {
      DateLbl->Caption = "INVALID";
      TimeLbl->Caption = "";
   }
}

void
TBitResultsFrame::DispBitBase
   (
   const TTapBitBase &TapBitBase,
   TOvcLabel         *Lbl,
   TOvcLabel         *ResultsLbl
   )
{

   SetRequiredLbl( TapBitBase.IsRequired(), Lbl );
   SetResultsVisible( TapBitBase.IsRequired(), ResultsLbl );
   SetResultsLbl( TapBitBase.IsPassed(), ResultsLbl );

}

void
TBitResultsFrame::DispChip
   (
   const TTapBitXChip &TapBitXChip,
   TChipLblStruct     &ChipLbls
   )
{

   SetRequiredLbl( TapBitXChip.IsRequired(), ChipLbls.XLbl );
   SetResultsVisible( TapBitXChip.IsRequired(), ChipLbls.InitLbl  );
   SetResultsVisible( TapBitXChip.IsRequired(), ChipLbls.DoneLbl  );
   SetResultsLbl( TapBitXChip.IsInit(), ChipLbls.InitLbl  );
   SetResultsLbl( TapBitXChip.IsDone(), ChipLbls.DoneLbl  );

}

void
TBitResultsFrame::SetResultsLbl
   (
   const bool Passed,
   TOvcLabel *Lbl
   )
{

   if ( Passed )
   {
      Lbl->Caption     = "Passed";
      Lbl->Font->Color = clGreen;
   }
   else
   {
      Lbl->Caption     = "Failed";
      Lbl->Font->Color = clRed;
   }

}

void
TBitResultsFrame::SetResultsVisible
   (
   const bool                Required,
   TOvcLabel               * Lbl
   )
{
   Lbl->Visible = Required;
}

void
TBitResultsFrame::SetRequiredLbl
   (
   const bool                Required,
   TOvcLabel               * Lbl
   )
{

   Lbl->Enabled = Required;

}


void
TBitResultsFrame::SetBitResults
   (
   const TTapBitResults & BitResults
   )
{

   TapBitResults = BitResults;

   DispBitResults( TapBitResults );

}   

