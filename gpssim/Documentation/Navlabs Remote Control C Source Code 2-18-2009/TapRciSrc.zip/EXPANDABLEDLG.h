//---------------------------------------------------------------------------

#ifndef ExpandableDlgH
#define ExpandableDlgH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: EXPANDABLEDLG.h                                       $
//
// $Revision:: 1                                                     $
//
// $History:: EXPANDABLEDLG.h                                        $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 2/01/03    Time: 1:46p
//Created in $/TapRci
//Initial checkin.
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "RzButton.hpp"
#include <ImgList.hpp>
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------
//---------------------------------------------------------------------------
class TExpandableDialog : public TForm
{
__published:
   TPanel *TopPanel;
   TPanel *BottomPanel;
   TPanel *LeftPanel;
   TPanel *RightPanel;
   TRzBitBtn *OKBtn;
   TRzBitBtn *DetailsBtn;
   TImageList *DetailsBtnImageList;
   void __fastcall DetailsBtnClick(TObject *Sender);
private:

   bool                      expanded;
   int                       TopPanelWidth;
   int                       DoorPanelWidth;
   int                       BottomPanelHeight;

   void __fastcall           SetExpanded( bool expand );

public:

   __fastcall                TExpandableDialog( TComponent * Owner );

   __property bool Expanded = { read = expanded, write = SetExpanded };

};
//---------------------------------------------------------------------------
extern PACKAGE TExpandableDialog *ExpandableDialog;
//---------------------------------------------------------------------------
#endif
