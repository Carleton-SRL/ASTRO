#ifndef EthernetInterfaceStatusFramH
#define EthernetInterfaceStatusFramH
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// $Workfile:: EthernetInterfaceStatusFram.h                         $
//
// $Revision:: 3                                                     $
//
// $History:: EthernetInterfaceStatusFram.h                          $
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:18p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:31p
//Updated in $/TapRci
//Initial release.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/04/02   Time: 10:25a
//Created in $/RciDriver
//Add ethernet
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/02/02   Time: 9:48a
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------


//------------------------------------------------------------------------------
#ifndef BUILDERINCLUDES
//------------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ovclabel.hpp"
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include "RzButton.hpp"
#include "RzRadChk.hpp"
//------------------------------------------------------------------------------
#endif
//------------------------------------------------------------------------------

#ifndef InterfaceStatusFrameH
#include "InterfaceStatusFrame.h"
#endif


class TEthernetServer;
class TEthernetClient;

//---------------------------------------------------------------------------
class TEthernetInterfaceStatusFrame : public TFrame, public IInterfaceStatusFrame
{
__published:
   TOvcLabel *PortDescLbl;
   TOvcLabel *PortLbl;
   TImage *EthernetImage;
   TRzRadioButton *Connectedrb;
private:

   const TEthernetServer * const EthernetServer;
   const TEthernetClient * const EthernetClient;
   AnsiString                    Title_;

   bool const                GetServer() const { return( EthernetServer != NULL ); }
   bool const                GetClient() const { return( EthernetClient != NULL ); }

   TFrame                  * GetFrame() const { return( (TFrame *) this ); }
   AnsiString const          GetTitle() const { return( Title_ ); }
   void                      SetTitle( const AnsiString & InTitle ) { Title_ = InTitle; }

public:

   __fastcall TEthernetInterfaceStatusFrame( TComponent* Owner, const TEthernetServer * const InEthernetServer );
   __fastcall TEthernetInterfaceStatusFrame( TComponent* Owner, const TEthernetClient * const InEthernetClient );

   void                      UpdateDisplay();

   __property TFrame *     Frame       = { read = GetFrame                       };
   __property AnsiString   Title       = { read = GetTitle,   write = SetTitle   };
   __property bool         Server      = { read = GetServer                      };
   __property bool         Client      = { read = GetClient                      };

};
//---------------------------------------------------------------------------
extern PACKAGE TEthernetInterfaceStatusFrame *EthernetInterfaceStatusFrame;
//---------------------------------------------------------------------------
#endif
