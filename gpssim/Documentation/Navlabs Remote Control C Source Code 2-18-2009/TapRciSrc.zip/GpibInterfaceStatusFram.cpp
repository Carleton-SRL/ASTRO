#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: GpibInterfaceStatusFram.cpp                           $
//
// $Revision:: 4                                                     $
//
// $History:: GpibInterfaceStatusFram.cpp                            $
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 2:41p
//Updated in $/TapRci
//Add TapRciPch.h after pch.h making pch.h project independent.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:19p
//Updated in $/TapRci
//Change style to XP.
//
//*****************  Version 2  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:36p
//Updated in $/TapRci
//Update display.
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 10/02/02   Time: 10:27a
//Created in $/TapRci
//Initial check in
//
//
//---------------------------------------------------------------------------


#ifndef GpibInterfaceStatusFramH
#include "GpibInterfaceStatusFram.h"
#endif

#ifndef GpibH
#include "Gpib.h"
#endif

#include "Decl-32.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ovclabel"
#pragma link "RzEdit"
#pragma link "RzButton"
#pragma link "RzRadChk"
#pragma resource "*.dfm"
TGpibInterfaceStatusFrame *GpibInterfaceStatusFrame;
//---------------------------------------------------------------------------
__fastcall
TGpibInterfaceStatusFrame::TGpibInterfaceStatusFrame
   (
   TComponent              * Owner,
   const TGpib * const       InGpib
   ) :
   TFrame( Owner ),
   Gpib( InGpib ),
   Title_( AnsiString( "GPIB Interface Status" ) ),
   GpibTime( T100ms )
{
}
//---------------------------------------------------------------------------
void
TGpibInterfaceStatusFrame::UpdateDisplay
   (
   )
{


   ValidInterfacerb->Checked  = Gpib->ValidInterface;
   PrimaryAddressLbl->Caption = Gpib->PrimaryAddress;
   BoardIndexLbl->Caption     = Gpib->BoardIndex;
   TimeoutLbl->Caption        = GpibTime.GetTimeoutStr( Gpib->Timeout );

   AnsiString Str             = Gpib->StatusStr;
   while ( Str.Length() )
   {
      DebugRichEdit->Lines->Add( Str );
      Str = Gpib->StatusStr;
   }


}

