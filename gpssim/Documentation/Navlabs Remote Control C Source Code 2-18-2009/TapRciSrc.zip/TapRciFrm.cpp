#include "pch.h"
#include "TapRciPch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: TapRciFrm.cpp                                         $
//
// $Revision:: 9                                                     $
//
// $History:: TapRciFrm.cpp                                          $
//
//*****************  Version 9  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:13p
//Updated in $/TapRci
//Remove CodeSite 3.
//
//*****************  Version 8  *****************
//User: Michael Wade Date: 6/07/05    Time: 2:02p
//Updated in $/TapRci
//TapMsecStatFrame LED to standard text.
//
//*****************  Version 7  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:32p
//Updated in $/TapRci
//Add Time Pulse Reset for LM Garrett.
//
//*****************  Version 6  *****************
//User: Michael Wade Date: 2/04/03    Time: 11:01a
//Updated in $/TapRci
//Add popup to tray icon.
//Add images to menus.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 2/01/03    Time: 4:41p
//Updated in $/TapRci
//Make application tray.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 2/01/03    Time: 12:24p
//Updated in $/TapRci
//Change to XP style.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 11:00p
//Updated in $/TapRci
//Add OperationError.
//
//
//---------------------------------------------------------------------------


#ifndef TapRciFrmH
#include "TapRciFrm.h"
#endif

#ifndef PowerDispFrmH
#include "PowerDispFrm.h"
#endif

#ifndef TapRciPfH
#include "TapRciPf.h"
#endif

#ifndef VoyDefPfH
#include "VoyDefPf.h"
#endif

#ifndef VerifyOperationFrmH
#include "VerifyOperationFrm.h"
#endif

#ifndef OperationErrorFrmH
#include "OperationErrorFrm.h"
#endif

#ifndef ThreadInfH
#include "ThreadInf.h"
#endif

#ifndef AboutDlgH
#include "AboutDlg.h"
#endif


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "MsgListFram"
#pragma link "ovclabel"
#pragma link "RzPanel"
#pragma link "RzSplit"
#pragma link "TapMsecStatFram"
#pragma link "SsBase"
#pragma link "StBrowsr"
#pragma link "RzLabel"
#pragma link "CSIntf"
#pragma link "MsgListFram"
#pragma link "TapMsecStatFram"
#pragma link "MsgListFram"
#pragma link "TapMsecStatFram"
#pragma link "RzStatus"
#pragma link "RzTabs"
#pragma link "RzTray"
#pragma link "RzButton"
#pragma link "RzRadChk"
#pragma resource "*.dfm"

#define MAX_MSG_LIST ( 300 )
TTapRciForm *TapRciForm;
//---------------------------------------------------------------------------
__fastcall
TTapRciForm::TTapRciForm
   (
   TComponent* Owner
   ) :
   TForm( Owner ),
   InTimer( false ),
   SimMode( eSimIdle ),
   RciControl( NULL ),
   OperationError( false ),
   Stopped( false ),
   TapRciProfile( NULL ),
   InterfaceStatusFrame( NULL ),
   CurPPSCount_( 0 ),
   CurIntCount_( 0 ),
   PrevPPSCount_( 0 ),
   PrevIntCount_( 0 )
{

   TapRciProfile                     = new TTapRciProfile();
   OperationErrorLbl->Visible        = false;
   const bool VerifyOperationAtStart = TapRciProfile->VerifyOperationAtStart;

   if ( VerifyOperationAtStart )
   {

      OperationError                 = VerifyOperation();

      if ( OperationError )
      {
         DispOperationError();
      }

   }

   MsgListFrame->MsgListBox->Items->Clear();

   RciControl                          = new TRciControl( this );
   InterfaceStatusFrame                = RciControl->InterfaceStatusFrame;
   InterfaceStatusFrame->Frame->Parent = InterfaceStatusPnl;
   InterfaceStatusFrame->Frame->Align  = alClient;
   InterfaceStatusTitleLbl->Caption    = InterfaceStatusFrame->Title;

   if ( RciControl->Valid )
   {
      RciTimer->Enabled = true;
      RciControl->Resume();
   }
   else
   {
      CodeSite->SendMsg( csmError, "RciControl not Valid" );
      Application->MessageBox( " RciControl Not valid.", "Fatal Error", MB_OK );
      Application->Terminate();
      Application->ProcessMessages();
   }


   SetTapRciStatusLbls();

   RciStatusPageCtrl->TabIndex = 0;

   TThreadInf TThreadInf( "TapRciMainVcl" );


}
__fastcall
TTapRciForm::~TTapRciForm
   (
   )
{
   delete RciControl;
   delete TapRciProfile;
}
//---------------------------------------------------------------------------
void __fastcall
TTapRciForm::RciTimerTimer
   (
   TObject                 * Sender
   )
{
   if ( InTimer ) return;
   InTimer = true;

   if ( RciControl && RciControl->Valid )
   {

      TapMsecStatusFrame->TapMsecStat = RciControl->CurrentTapMsecStat;

      MsgTrafficArray                 = RciControl->MsgTrafficArray;

      ProcessMsgTrafficArray( MsgTrafficArray );

      SetDisplay();

      // DEBUG


   }

   InTimer = false;

}
//---------------------------------------------------------------------------

void
TTapRciForm::SetDisplay
   (
   )
{

   if ( RciControl && RciControl->Valid )
   {

      if ( InterfaceStatusFrame )
      {
         InterfaceStatusFrame->UpdateDisplay();
      }

      TapRciStatusVal->Caption     = GetSimModeString( RciControl->CurSimMode );
      TapRciStatusVal->Font->Color = GetSimModeColor( RciControl->CurSimMode );

      SetRciStatusDisplay( RciControl );

   }

}   

void
TTapRciForm::SetRciStatusDisplay
   (
   TRciControl             * RciCtl
   )
{

   SetRciStatusResetPulseDisplay( RciCtl );

   SetRciStatusCountersDisplay( RciCtl );

}

void
TTapRciForm::SetRciStatusResetPulseDisplay
   (
   TRciControl             * RciCtl
   )
{

   CancelExtResetBtn->Enabled                       = RciCtl->WaitForExtResetPulseArmed;
   ExtResetSheetSimCountersWaitForResetLbl->Visible = RciCtl->WaitForExtResetPulseArmed;

}

void
TTapRciForm::SetRciStatusCountersDisplay
   (
   TRciControl             * RciCtl
   )
{

   if ( RciCtl )
   {

      CurPPSCount_                                      = RciCtl->PPSCount;
      CurIntCount_                                      = RciCtl->IntCount;

      PPSCounterVal->Caption                            = CurPPSCount_;
      MsCounterVal->Caption                             = CurIntCount_*2;

      CounterStoppedcb->Checked                         = ( CurPPSCount_ == PrevPPSCount_ ) && ( CurIntCount_ == PrevIntCount_ );
      SimHWCountersSimCountersWaitForResetLbl->Caption  = RciCtl->WaitForExtResetPulseArmed ? AnsiString( "Waiting for external reset pulse..." ) : AnsiString( "External pulse reset not armed." );
      SimHWCountersSimCountersWaitForResetLbl->Blinking = RciCtl->WaitForExtResetPulseArmed;

      PrevPPSCount_                                     = CurPPSCount_;
      PrevIntCount_                                     = CurIntCount_;

   }

}

// VerifyOperation
//   This function is crucial to TapRci.  It checks the system, verifies that TapMsec
// is loadable, that the Remote Scenario exists and various other parameters.
// If at any point a failure occurs, the user is notified, and if possible, the
// user is given the option to correct the error.  For example, if TapMsec is
// not found in the path from the ini file, the user is prompted.
//---------------------------------------------------------------------------


bool const
TTapRciForm::VerifyOperation
   (

   )
{

   TVerifyOperationForm *VerifyOperationForm = new TVerifyOperationForm( this );

   const bool CurOperationError              = VerifyOperationForm->OperationError;

   OperationErrorLbl->Visible                = CurOperationError;

   delete VerifyOperationForm;

   return( CurOperationError );

}



void
TTapRciForm::DispOperationError
   (

   )
{

   TOperationErrorForm *OperationErrorForm   = new TOperationErrorForm( this );

   OperationErrorForm->ShowModal();

   delete OperationErrorForm;

   TVerifyOperationForm *VerifyOperationForm = new TVerifyOperationForm( this );

   VerifyOperationForm->ShowModal();

   delete VerifyOperationForm;

}

void
TTapRciForm::ProcessMsgTrafficArray
   (
   TMsgTrafficArray &Msgs
   )
{

   for ( unsigned int i=0; i<Msgs.size(); ++i )
   {
      TMsgTraffic &Msg = Msgs[i];
      AnsiString Str;
      Str.sprintf("%6.2lf", Msg.GetTimeMillisec()*0.001 );
      if ( Msg.GetSource() == eMSG_SOURCE_SIM )
      {
         Str += AnsiString( "\tSIM\t" );
      }
      else
      {
         Str += AnsiString( "\tCTLR\t" );
      }
      AnsiString MsgStr = Msg.GetMsgStr();
      MsgStr.Delete( MsgStr.Pos( '\r' ), MsgStr.Length() );
      MsgStr.Delete( MsgStr.Pos( '\n' ), MsgStr.Length() );
      Str += MsgStr;
      MsgListFrame->MsgListBox->Items->Add( Str );
      if ( MsgListFrame->MsgListBox->Items->Count >= MAX_MSG_LIST )
      {
         MsgListFrame->MsgListBox->Items->Clear();
      }

   }

}

void __fastcall
TTapRciForm::FormClose
   (
   TObject                 * Sender,
   TCloseAction            & Action
   )
{
   StopRci();
}

void
TTapRciForm::StopRci()
{
   if ( Stopped ) return;

   if ( RciControl )
   {

      RciControl->Terminate();
      RciControl->WaitFor();
      delete RciControl;
      RciControl = NULL;
      Stopped    = true;

   }

}
//---------------------------------------------------------------------------


void __fastcall
TTapRciForm::AboutActionExecute
   (
   TObject                 * Sender
   )
{

   TAboutDialog * AboutDlg = new TAboutDialog( this );
   AboutDlg->ShowModal();
   delete AboutDlg;

}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::RestoreActionExecute
   (
   TObject                 * Sender
   )
{
   TrayIcon->RestoreApp();
}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::ExitActionExecute
   (
   TObject                 * Sender
   )
{
   Close();
}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::PowerDispActionExecute
   (
   TObject                 * Sender
   )
{

   TPowerDispForm *PowerDisp = new TPowerDispForm( this );
   PowerDisp->ShowModal();
   if ( PowerDisp->ModalResult == mrOk )
   {

      TapMsecStatFrame->SetNewDispRelativePower();

   }

   delete PowerDisp;

}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::TapMsecPathActionExecute
   (
   TObject                 * Sender
   )
{

   TOpenDialog * pFileOpen          = new TOpenDialog(this);
   pFileOpen->Options               << ofFileMustExist;
   pFileOpen->Filter                = "Exe files (*.exe)|*.EXE";
   pFileOpen->Title                 = "Select TapMsec Executable";

   if ( pFileOpen->Execute() )
   {
      TapRciProfile->TapMsecPath    = pFileOpen->FileName;
   }

   delete pFileOpen;


}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::RemoteScenActionExecute
   (
   TObject                 * Sender
   )
{

   VoyDefProfile * Vdp              = new VoyDefProfile();
   StBrowserRemoteDir->RootFolder   = Vdp->GetRunsDir();
   delete Vdp;

   if ( StBrowserRemoteDir->Execute() )
   {

      TapRciProfile->RemoteScn      = StBrowserRemoteDir->Path;

   }

}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::VerifyOperationActionExecute
   (
   TObject                 * Sender
   )
{

   TVerifyOperationForm *VerifyOperationForm = new TVerifyOperationForm( this );

   VerifyOperationForm->ShowModal();

   OperationError                            = VerifyOperationForm->OperationError;

   OperationErrorLbl->Visible                = OperationError;

   delete VerifyOperationForm;

}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::MinimizeActionExecute
   (
   TObject                 * Sender
   )
{
   TrayIcon->MinimizeApp();
}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::TapRciStatusPnlResize
   (
   TObject                 * Sender
   )
{
   SetTapRciStatusLbls();
}

void
TTapRciForm::SetTapRciStatusLbls
   (
   )
{
   TapRciStatusLbl->Width = TapRciStatusPnl->Width/2;
}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::ResetCountersActionExecute
   (
   TObject                 * Sender
   )
{
   if ( RciControl )
   {
      RciControl->TpMapInterface->ResetCounters();
   }

}
//---------------------------------------------------------------------------

void __fastcall TTapRciForm::ResetCountersActionUpdate(TObject *Sender)
{

   ResetCountersAction->Enabled = !( RciControl->WaitForExtResetPulseArmed );

}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::CancelArmExternalPulseResetActionExecute
   (
   TObject                 * Sender
   )
{

      RciControl->CancelExtResetPulse();

}
//---------------------------------------------------------------------------

void __fastcall
TTapRciForm::CancelArmExternalPulseResetActionUpdate
   (
   TObject                 * Sender
   )
{

   CancelExtResetBtn->Enabled = RciControl->WaitForExtResetPulseArmed;

}
//---------------------------------------------------------------------------

