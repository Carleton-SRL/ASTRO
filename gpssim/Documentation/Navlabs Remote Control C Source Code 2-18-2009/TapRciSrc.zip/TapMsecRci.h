#ifndef TapMsecRciH
#define TapMsecRciH
//---------------------------------------------------------------------------
//
// $Workfile:: TapMsecRci.h                                          $
//
// $Revision:: 5                                                     $
//
// $History:: TapMsecRci.h                                           $
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 1/16/04    Time: 10:42p
//Updated in $/TapRci
//Add "SetL2Atten" message.
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 4/29/03    Time: 8:28p
//Updated in $/TapRci
//Add Time Set Pulse for LM Garrett.
//
//*****************  Version 3  *****************
//User: Michael Wade Date: 1/31/03    Time: 10:28p
//Updated in $/TapRci
//Add RFAtten.
//
//*****************  Version 5  *****************
//User: Michael Wade Date: 7/29/02    Time: 12:10a
//Updated in $/TapMsec
//Added include file guards
//
//*****************  Version 4  *****************
//User: Michael Wade Date: 7/23/02    Time: 8:05p
//Updated in $/TapMsec
//Added Source Safe keywords
//
//---------------------------------------------------------------------------

#ifndef TapBitH
#include "TapBit.h"
#endif

#ifndef WhichH
#include "Which.h"
#endif

#define NUM_CHANS_IN_STAT    (14)
#define NUM_CHANS_IN_COMMAND ( NUM_CHANS_IN_STAT )

extern const char *TAPMSECSTAT_FNAME;
extern const char *TAPMSECBITRESULTS_FNAME;
extern const char *TAPMSECCMMND_FNAME;

#pragma pack(push,1)

class TTapMsecStatChan {
public:

   int                       Chan;        // ChannelID, starting with 0, -1 means invalid
   int                       Svid;        // SVID
   double                    L1Atten;
   double                    L1Power;
   double                    L2Atten;
   double                    L2Power;
   double                    El;
   double                    Az;

public:

   TTapMsecStatChan
      (
      const int InChan = -1, const int InSvid = 0, const double InL1Atten = 0,
      const double InL1Power = 0, const double InL2Atten=0, const double InL2Power = 0
      ) :
      Chan( InChan ), Svid( InSvid ), L1Atten( InL1Atten ), L1Power( InL1Power ),
      L2Atten( InL2Atten ), L2Power( InL2Power ), El( 0 ), Az( 0 ) {}

};


typedef enum { eRUN_IDLE=0, eRUN_SCEN=1, eRUN_LOCAL=2, eRUN_WAITFORRESETPULSE=3 } eRUNMODE;

bool const IsRunModeRunning( const eRUNMODE InRunMode ) { return( ( InRunMode == eRUN_SCEN ) || ( InRunMode == eRUN_LOCAL ) ); }

class TTapMsecStat {
public:

   int                       Valid;
   int                       StartWeek;
   double                    StartSeconds;
   double                    SecondsIntoSim;
   double                    SecondsRemaining;
   int                       CurWeek;
   double                    CurSeconds;
   double                    Lat;                        // deg
   double                    Lon;                        // deg
   double                    Alt;                        // m
   double                    VelNorth;                   // m/s
   double                    VelEast;                    // m/s
   double                    VelDown;                    // m/s
   eRUNMODE                  eRunMode;
   TTapMsecStatChan          ChanStat[NUM_CHANS_IN_STAT];
   double                    RFGain;
   int                       Error;
   char                      ErrorStr[100];
   char                      ScenarioName[MAX_PATH];

   bool const                GetRunModeRunning() const { return( IsRunModeRunning( eRunMode ) ); }

public:

   TTapMsecStat() : Valid(0), StartWeek(0), StartSeconds(0), SecondsIntoSim(0),
      SecondsRemaining(0), CurWeek(0), CurSeconds(0), Lat(0), Lon(0), Alt(0),
      VelNorth(0), VelEast(0), VelDown(0), eRunMode( eRUN_IDLE ), Error(0),
      RFGain(0)
      {
         ErrorStr[0] = ('\0');
         ScenarioName[0] = ('\0');
      }

   __property bool       RunModeRunning    = { read = GetRunModeRunning                             };   
};

typedef TWhich<TTapMsecStat> TTapMsecStatWhich;



//-----------------------------------------------------------------------------
// Remote Commands
//
// Remote commands are sent from the TapRci program to TapMsec.  However, unlike
// the TapMsec status, there is room for only one command at a time.  TapRci is
// responsible for not writing a new command until TapMsec has read the current
// one.
//
class TTapMsecCommandSvid {
public:

   int                       Chan;
   int                       Svid;

public:

   TTapMsecCommandSvid( const int InChan = -1, const int InSvid = -1 ) : Chan( InChan ), Svid( InSvid ) {}

};

class TTapMsecCommandPower {
public:

   int                       Chan;
   double                    L1Power;
   double                    L2Power;

public:

   TTapMsecCommandPower( const int InChan = -1, const double InL1Power = 0, const double InL2Power = 0 )
      : Chan( InChan ), L1Power( InL1Power ), L2Power( InL2Power ) {}

};

class TTapMsecCommandL1Atten {
public:

   int                       Chan;
   double                    L1Atten;

public:

   TTapMsecCommandL1Atten( const int InChan = -1, const double InL1Atten = 0 )
      : Chan( InChan ), L1Atten( InL1Atten ){}

};

class TTapMsecCommandL2Atten {
public:

   int                       Chan;
   double                    L2Atten;

public:

   TTapMsecCommandL2Atten( const int InChan = -1, const double InL2Atten = 0 )
      : Chan( InChan ), L2Atten( InL2Atten ){}

};

class TTapMsecCommandSetRfAtten {
public:

   double                    RfAtten;

public:

   TTapMsecCommandSetRfAtten( const double InRfAtten = 0.0 ) : RfAtten( InRfAtten ) {}

};

class TTapMsecCommandAdjustRfAtten {
public:

   double                    AdjustRfAtten;

public:

   TTapMsecCommandAdjustRfAtten( const double InAdjustRfAtten = 0.0 ) : AdjustRfAtten( InAdjustRfAtten ) {}

};

class TTapMsecCommandAtten {
public:

   int                       Chan;
   double                    L1Atten;
   double                    L2Atten;

public:

   TTapMsecCommandAtten( const int InChan = -1, const double InL1Atten = 0, const double InL2Atten = 0 ) :
      Chan( InChan ), L1Atten( InL2Atten ), L2Atten( InL2Atten ) {}

};

class TTapMsecCommand {
public:

typedef enum { eCommandNone = 0, eCommandSvid, eCommandPower, eCommandAtten, eCommandStop, eCommandSetRfAtten, eCommandAdjustRfAtten, eCommandL1Atten, eCommandL2Atten } eTapMsecCommand;

   TTapMsecCommandSvid                 CommandSvid[NUM_CHANS_IN_COMMAND];
   TTapMsecCommandPower                CommandPower[NUM_CHANS_IN_COMMAND];
   TTapMsecCommandAtten                CommandAtten[NUM_CHANS_IN_COMMAND];
   TTapMsecCommandL1Atten              CommandL1Atten[NUM_CHANS_IN_COMMAND];
   TTapMsecCommandL2Atten              CommandL2Atten[NUM_CHANS_IN_COMMAND];
   TTapMsecCommandSetRfAtten           CommandSetRfAtten;
   TTapMsecCommandAdjustRfAtten        CommandAdjustRfAtten;

   eTapMsecCommand                     Command;

public:

   TTapMsecCommand() : Command( eCommandNone ) {}

};

typedef TWhichSingle<TTapMsecCommand> TTapMsecCommandWhich;



template<class TMemWhich, class TMem, char *FileName>
class TTapMsecMem {
private:

   HANDLE                    MemStatHandle;
   TMemWhich               * MemWhich;
   int                       VehNum;

public:

   TTapMsecMem( const int InVehNum = 0 ) : MemWhich( NULL ), MemStatHandle( NULL ), VehNum( InVehNum )
   {
      char Str[100];
      sprintf( Str, "%s%d", FileName, VehNum );
      MemStatHandle = CreateFileMapping
         (
         (HANDLE)0xFFFFFFFF,     // to create a temp file
         NULL,                   // no security
         PAGE_READWRITE,         // to allow read & write access
         0,
         sizeof(TMemWhich),      // file size
         Str                     // object name
         );

      if ( MemStatHandle )
      {
         MemWhich = (TMemWhich *) MapViewOfFile( MemStatHandle, FILE_MAP_WRITE, 0, 0, 0 );
      }

   }
   ~TTapMsecMem()
   {
      if ( MemWhich )
      {
         UnmapViewOfFile( MemWhich );
      }
      CloseHandle( MemStatHandle );
   }

   bool const                IsValid() const { return( MemWhich != NULL ); }
   TMem const                GetCurrent() const { return( MemWhich->GetCurrent() ); }
   void                      SetCurrent( const TMem &Mem ) { MemWhich->SetCurrent( Mem ); }
   bool const                IsSet() const { return( MemWhich->IsSet() ); }

};

typedef TTapMsecMem<TTapMsecStatWhich,TTapMsecStat,TAPMSECSTAT_FNAME> TTapMsecStatMem;

typedef TTapMsecMem<TTapMsecCommandWhich,TTapMsecCommand,TAPMSECCMMND_FNAME> TTapMsecCommandMem;

#pragma pack(pop)



#endif

