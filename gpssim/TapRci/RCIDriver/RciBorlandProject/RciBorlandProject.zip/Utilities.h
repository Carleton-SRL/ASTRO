#ifndef UTILITIES_H
#define UTILITIES_H


bool const
IsValidScenario
   (
   const AnsiString &ScenarioRoot
   );

#endif   

 