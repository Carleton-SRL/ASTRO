#include "pch.h"
#pragma hdrstop

#include "ScenTime.h"

int     TScenTime::TimeMillisec_( 0 );

