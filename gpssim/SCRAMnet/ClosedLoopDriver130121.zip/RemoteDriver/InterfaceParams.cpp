#include "pch.h"
#pragma hdrstop

//---------------------------------------------------------------------------
//
// $Workfile:: InterfaceParams.cpp                                   $
//
// $Revision:: 1                                                     $
//
// $History:: InterfaceParams.cpp                                    $
//
//*****************  Version 1  *****************
//User: Michael Wade Date: 11/09/02   Time: 8:51p
//Created in $/RemoteDriver
//
//
//---------------------------------------------------------------------------

#ifndef InterfaceParamsH
#include "InterfaceParams.h"
#endif

